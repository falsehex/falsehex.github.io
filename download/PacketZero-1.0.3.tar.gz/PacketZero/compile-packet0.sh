#!/bin/sh
KERNEL=`uname`
if [ $KERNEL = "Darwin" ]
then
  FWKS="-F/Library/Frameworks"
  LIBS="-framework Cocoa -framework OpenGL $FWKS -framework SDL2"
else
  FWKS=""
  LIBS="-lpthread -lGL -lSDL2"
fi
g++ -O2 -c -o obj/misc.o source/misc.cpp
g++ -O2 -c -o obj/glob.o source/glob.cpp
g++ -O2 -c -o obj/llist-m.o source/llist-m.cpp
g++ -O2 -c -o obj/glue.o source/glue.cpp
g++ -O2 -c -o obj/record.o source/record.cpp
g++ -O2 -c -o obj/objects.o source/objects.cpp
g++ -O2 -c -o obj/packet0.o source/packet0.cpp $FWKS
g++ -O2 -o packet0 obj/misc.o obj/glob.o obj/llist-m.o obj/glue.o obj/record.o obj/objects.o obj/packet0.o $LIBS
rm obj/*
