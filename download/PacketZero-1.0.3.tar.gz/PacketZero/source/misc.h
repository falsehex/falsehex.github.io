/* misc.h - 01 Sep 15
   PacketZero - 3D Network Monitor
   Copyright 2006-2015 Del Castle  */

#include <dirent.h>
#include <netinet/in.h>

#define	IPPROTO_ARP   249  //protocol 249 unassigned used to identify ARP packet
#define	IPPROTO_FRAG  250  //protocol 250 unassigned used to identify fragmented IP packet

const unsigned char clrWhite[3] =      {255, 255, 255},  //white
                    clrRedBright[3] =  {255,  50,  50},  //bright red
                    clrRed[3] =        {200,  50,  50},  //red
                    clrRedCross[3] =   {150,  50,  50},  //cross red
                    clrOrange[3] =     {220, 170,  50},  //orange
                    clrYellow[3] =     {200, 200,  50},  //yellow
                    clrFluro[3] =      {170, 220,  50},  //fluro
                    clrGreen[3] =      { 50, 200,  50},  //green
                    clrGreenCross[3] = { 50, 150,  50},  //cross green
                    clrMint[3] =       { 50, 220, 170},  //mint
                    clrAqua[3] =       { 50, 200, 200},  //aqua
                    clrSky[3] =        { 50, 170, 220},  //sky
                    clrBlue[3] =       { 50,  50, 200},  //blue
                    clrBlueCross[3] =  { 50,  50, 150},  //cross blue
                    clrPurple[3] =     {170,  50, 220},  //purple
                    clrViolet[3] =     {200,  50, 200},  //violet
                    clrGreyBright[3] = {200, 200, 200},  //bright grey
                    clrGrey[3] =       {150, 150, 150},  //grey
                    clrGreyDull[3] =   {100, 100, 100},  //dull grey
                    clrBlack[3] =      {  0,   0,   0};  //black

//add extension to file
void addExtension(char *filename, const char *ext);

//create directory file list
void createFileList(const char *filename, const char *path, const char *ext);

//protocol number to text
char *decodeProtocol(int protocol, char *buffer);

//escape quotes in CSV strings
void escapeQuotes(const char *text, char *buffer);

//format bytes using prefix
char *formatBytes(unsigned long long bytes, char *buffer);

//get data directory
char *getPath(const char *filename, char *buffer);

//check if an IP address is in a CIDR net
bool inNet(const char *net, in_addr ip);

//convert string to lowercase
char *lowerStr(const char *text, char *buffer);

//check for regular file
int regularFile(const dirent *entry);

//square function
double sqr(double val);

//check for controls file, create it & data directory
void checkControls(char *buffer);
