<?php

include "plugins/cred/snort.cred.php";

$link = mysqli_connect($snort_db_host, $snort_db_user, $snort_db_pass, $snort_db_name);
if (!$link) die("Error: mysql db {$snort_db_name} connect failed");

if (!isset($shape)) $shape = (isset($_POST["shape"]) ? $_POST["shape"] : "");
if (!isset($show_vals)) $show_vals = (isset($_POST["show_vals"]) ? $_POST["show_vals"] : "");

$table = "<table id='snort_alerts_{$shape}_table' class='chart'><tr><th class='chart'></th><th class='chart'>Alert</th><th class='chart'>Events</th></tr>";
$count = 0;
$extra = ($start_time ? " WHERE timestamp >= '{$start_time}'" : "");
if ($finish_time) $extra .= ($extra ? " AND" : " WHERE") . " timestamp <= '{$finish_time}'";
$result = mysqli_query($link, "SELECT signature, COUNT(1) FROM event{$extra} GROUP BY signature ORDER BY COUNT(1) DESC LIMIT {$limit}");
while ($row = mysqli_fetch_row($result))
{
  $sig = $row[0];
  $row[0] = db_result($link, "SELECT sig_name FROM signature WHERE sig_id = {$sig}") . " (";
  $row[0] .= db_result($link, "SELECT sig_gid FROM signature WHERE sig_id = {$sig}") . ":";
  $row[0] .= db_result($link, "SELECT sig_sid FROM signature WHERE sig_id = {$sig}") . ")";
  $table .= "<tr><td class='chart'>" . ++$count . "</td>";
  foreach ($row as &$cell) $table .= "<td class='chart'>{$cell}</td>";
  $table .= "</tr>";
}
mysqli_free_result($result);
$table .= "</table>";
if ($count)
{
  if (empty($nohdr)) echo "<h4>SNORT TOP {$limit} ALERTS<br />" . ($start_time ? date("d-m-Y H:i:s", strtotime($start_time)) . " -" : "") . ($finish_time ? "- " . date("d-m-Y H:i:s", strtotime($finish_time)) : "") . "</h4>";
  if (empty($nogfx)) echo "<canvas id='snort_alerts_{$shape}_canvas' width='640' height='320' ondblclick='window.open(this.toDataURL());'></canvas>";
  echo $table;

  if (empty($nogfx)) echo "<script type='text/javascript'>{$shape}Chart(\"snort_alerts_{$shape}\", 0, 2" . ($shape == "vbar" ? ", \"{$show_vals}\"" : "") . ");</script>";
}
else echo "<h5>NO EVENTS FOUND!</h5>";

mysqli_close($link);

?>
