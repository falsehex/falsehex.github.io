<?php
/* Copyright 2012-2016 Del Castle */

echo "<pre>SID:\n----\n{$_GET["sid"]}\n\nRULE:\n-----\n" . shell_exec("grep -Fis \"sid:{$_GET["sid"]};\" /etc/snort/rules/*") . "</pre>";

?>
