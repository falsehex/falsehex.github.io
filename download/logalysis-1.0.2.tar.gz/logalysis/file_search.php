<html>
<head>
<meta name='copyright' content='2012-2016 Del Castle' />
<meta charset='UTF-8' />
<meta http-equiv='content-type' content='text/html' />
<link rel='stylesheet' type='text/css' href='fx/css/logalysis.css' />

<script type='text/javascript' src='fx/js/edate.js'></script>

<script type='text/javascript' src='fx/js/logalysis.js'></script>

</head>
<body>

<div class='menu'>
  <a class='menu' href='#' onclick='document.forms[0].submit();'>GENERATE FILE</a>
</div><br />

<?php

include "common.php";
session_start();
/*if (isset($_SESSION["las_last_activity"]) && ((time() - $_SESSION["las_last_activity"]) > 3600))
{
  session_unset();
  session_destroy();
} 
$_SESSION["las_last_activity"] = time();*/
if (empty($_SESSION["las_login_user_name"])) exit($login_bounce);
date_default_timezone_set("UTC");

$job_id = (isset($_POST["job_id"]) ? $_POST["job_id"] : $_GET["job_id"]);
$ref_no = (isset($_POST["ref_no"]) ? $_POST["ref_no"] : $_GET["ref_no"]);
$file_id = (isset($_POST["file_id"]) ? $_POST["file_id"] : (isset($_GET["file_id"]) ? $_GET["file_id"] : ""));

if (strstr($ref_no, "../")) exit(0);
$now_time = date("Y-m-d H:i:s");
if (isset($_POST["job_id"])) $search = array($_POST["plugin"], (isset($_POST["start_time"]) ? $_POST["start_time"] : ""), (isset($_POST["finish_time"]) ? $_POST["finish_time"] : ""), (isset($_POST["search_3"]) ? $_POST["search_3"] : ""), (isset($_POST["search_4"]) ? $_POST["search_4"] : ""), (isset($_POST["search_5"]) ? $_POST["search_5"] : ""), (isset($_POST["search_6"]) ? $_POST["search_6"] : ""));
else if (isset($_GET["search"])) $search = explode(";", $_GET["search"]);
else $search = array("", $now_time, $now_time, "", "", "", "");
if ($file_id)
{
  $login_user_name = $_SESSION["las_login_user_name"];
  $dest_dir = "files/{$ref_no}";
  if ($ref_no == "SCRATCHPAD") $dest_dir .= "/{$login_user_name}...dir";
  if (!file_exists($dest_dir))
  {
    if ($ref_no == "SCRATCHPAD") mkdir("files/{$ref_no}/{$login_user_name}", 0755, TRUE);
    mkdir($dest_dir, 0755);
  }
  $file_name = "{$dest_dir}/" . strtr($now_time, " ", "_") . "_{$login_user_name}";

  include "plugins/file/{$search[0]}.generate_file.php";

  if (file_exists($file_name) && (substr($file_name, strlen($file_name) - 5, 5) == ".pcap"))
  {
    $file_info = fopen("{$file_name}...info", "w");
    fwrite($file_info, "CREATOR:  {$login_user_name}\n");
    fwrite($file_info, "CREATED:  {$now_time}\n");
    fwrite($file_info, "SOURCE:   {$search[0]}\n");
    if ($file_id != "generate")
    {
      fwrite($file_info, "EVENT:    {$search[1]}\n");
      fwrite($file_info, "ID:       {$file_id}\n");
    }
    else
    {
      fwrite($file_info, "START:    {$search[1]}\n");
      fwrite($file_info, "FINISH:   {$search[2]}\n");
    }
    if ($search[3]) fwrite($file_info, "IP 1:     {$search[3]}\n");
    if ($search[4]) fwrite($file_info, "PORT 1:   {$search[4]}\n");
    if ($search[5]) fwrite($file_info, "IP 2:     {$search[5]}\n");
    if ($search[6]) fwrite($file_info, "PORT 2:   {$search[6]}\n");
    fwrite($file_info, "\n");
    fclose($file_info);

    echo "<script type='text/javascript'>parent.frame_file_show.location.href = \"file_show.php?job_id={$job_id}&ref_no={$ref_no}&file_name=" . urlencode($file_name) . "\";</script>";
  }

  echo "<script type='text/javascript'>parent.frame_file_list.location.href = \"file_list.php?job_id={$job_id}&ref_no={$ref_no}\";</script>";
}

echo "<form action='file_search.php' method='POST'>";
echo "<input type='hidden' name='job_id' value='{$job_id}' />";
echo "<input type='hidden' name='ref_no' value='{$ref_no}' />";
echo "<input type='hidden' name='file_id' value='generate' />";
echo "<select name='plugin' onchange='location.href = \"file_search.php?job_id={$job_id}&ref_no={$ref_no}&search=\" + escape(this.value + \";\" + (typeof(start_time) === \"undefined\" ? \"{$search[1]}\" : start_time.value) + \";\" + (typeof(finish_time) === \"undefined\" ? \"{$search[2]}\" : finish_time.value) + \";\" + (typeof(search_3) === \"undefined\" ? \"{$search[3]}\" : search_3.value) + \";\" + (typeof(search_4) === \"undefined\" ? \"{$search[4]}\" : search_4.value) + \";\" + (typeof(search_5) === \"undefined\" ? \"{$search[5]}\" : search_5.value) + \";\" + (typeof(search_6) === \"undefined\" ? \"{$search[6]}\" : search_6.value));'>";
$first = "";
$file_plugins = scandir("plugins/file");
foreach ($file_plugins as &$row)
{
  if (strstr($row, ".search_file.php"))
  {
    $row = preg_replace("/^(.+)\.search_file\.php$/", "$1", $row);
    if (!$first) $first = $row;
    echo "<option value='{$row}'";
    if ($row == $search[0]) echo " selected";
    echo ">" . strtr($row, "_", " ") . "</option>";
  }
  else unset($row);
}
if (!in_array($search[0], $file_plugins)) $search[0] = $first;
echo "</select><br />";

include "plugins/file/{$search[0]}.search_file.php";

echo "</form>";

?>

</body>
</html>
