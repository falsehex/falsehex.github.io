<?php
/* Copyright 2012-2016 Del Castle */

$system = "IDS";
$lbl_report = "Reported";
$ref_pad = 3;
$show_files = array(".gif", ".jpg", ".png", ".txt");

$login_bounce = "<script type='text/javascript'>top.location.href = \"index.php\";</script></body></html>";

function logalysis_db_connect()
{
  $logalysis_db_host = "localhost";
  $logalysis_db_user = "logalysis";
  $logalysis_db_pass = "P@55w0rd";
  $logalysis_db_name = "logalysis";

  $link = mysqli_connect($logalysis_db_host, $logalysis_db_user, $logalysis_db_pass, $logalysis_db_name);
  if (!$link) die("Error: mysql db {$logalysis_db_name} connect failed");
  return $link;
}

function db_fetch_row($link, $sql)
{
  if ($result = mysqli_query($link, $sql))
  {
    $row = mysqli_fetch_row($result);
    mysqli_free_result($result);
    if ($row) return $row;
  }
  return 0;
}

function db_result($link, $sql)
{
  $row = db_fetch_row($link, $sql);
  if ($row) return $row[0];
  return 0;
}

function get_state_name($link, $state_id)
{
  return ($state_id ? db_result($link, "SELECT name FROM states WHERE state_id = {$state_id}") : "");
}

function get_user_name($link, $user_id)
{
  global $system;

  return ($user_id ? ($user_id == -1 ? $system : db_result($link, "SELECT name FROM users WHERE user_id = {$user_id}")) : "");
}

function write_audit($link, $job_id, $user_id, $action_id, $details)
{
  switch ($action_id)
  {
    case 1: $action = "Login Successful"; break;
    case 2: $action = "Login Failed"; break;
    case 3: $action = "Logout"; break;
    case 4: $action = "User Created"; break;
    case 5: $action = "User Details Changed"; break;
    case 6: $action = "State Created"; break;
    case 7: $action = "State Details Changed"; break;
    case 8: $action = "Job Created"; break;
    case 9: $action = "Job Status Changed"; break;
    case 10: $action = "Job Assignee Changed"; break;
    case 11: $action = "Job Details Changed"; break;
    case 12: $action = "Change Flow"; break;
  }
  mysqli_query($link, "INSERT INTO trail VALUES(0, {$job_id}, UTC_TIMESTAMP(), {$user_id}, '{$action}', '" . addslashes($details) . "')");
}

function search_time($start_time, $finish_time)
{
  echo "<p>Start Time<br /><input class='edate' type='text' name='start_time' size='21' maxlength='19' value='{$start_time}' /><br />";
  echo "<input type='button' value='∨' title='Copy To Finish' onclick='finish_time.value = start_time.value;' />";
  echo "<input type='button' value='@' title='Now' onclick='start_time.value = nowUTC(false);' />";
  echo "<input type='button' value='0' title='Zero' onclick='start_time.value = (start_time.value.search(/00$/) == -1 ? start_time.value.replace(/\d+$/, \"00\") : (start_time.value.search(/00:00$/) == -1 ? start_time.value.replace(/\d+:\d+$/, \"00:00\") : start_time.value.replace(/\d+:\d+:\d+$/, \"00:00:00\")));' />";
  echo "<input type='button' value=' ' title='Clear' onclick='start_time.value = \"\";' /><br />";
  echo "Finish Time<br /><input class='edate' type='text' name='finish_time' size='21' maxlength='19' value='{$finish_time}' /><br />";
  echo "<input type='button' value='∧' title='Copy To Start' onclick='start_time.value = finish_time.value;' />";
  echo "<input type='button' value='@' title='Now' onclick='finish_time.value = nowUTC(false);' />";
  echo "<input type='button' value='0' title='Zero' onclick='finish_time.value = (finish_time.value.search(/00$/) == -1 ? finish_time.value.replace(/\d+$/, \"00\") : (finish_time.value.search(/00:00$/) == -1 ? finish_time.value.replace(/\d+:\d+$/, \"00:00\") : finish_time.value.replace(/\d+:\d+:\d+$/, \"00:00:00\")));' />";
  echo "<input type='button' value=' ' title='Clear' onclick='finish_time.value = \"\";' /></p>";
}

function protocol_name($val)
{
  switch ($val)
  {
    case 1: return "ICMP";
    case 2: return "IGMP";
    case 6: return "TCP";
    case 17: return "UDP";
    default: return $val;
  }
}

function priority_color($val)
{
  switch ($val)
  {
    case "1 H": return "red";
    case "2 M": return "orange";
    case "3 L": return "gold";
    default: return "limegreen";
  }
}

function format_bytes($bytes)
{
  $units = array("B", "kB", "MB", "GB");
  for ($cnt = 0; ($bytes > 999) && ($cnt < 3); $cnt++) $bytes /= 1000;
  return round($bytes, 2, PHP_ROUND_HALF_DOWN) . " {$units[$cnt]}";
}

?>
