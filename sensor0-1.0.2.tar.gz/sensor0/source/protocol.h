/* protocol.h - 01 Sep 15
   PacketZero - 3D Network Monitor
   Copyright 2006-2015 Del Castle  */

#define ETHERTYPE_IP    0x0800
#define ETHERTYPE_ARP   0x0806
#define ETHERTYPE_VLAN  0x8100  //802.1Q VLAN

#define	IPPROTO_ARP   249  //protocol 249 unassigned used to identify ARP packet
#define	IPPROTO_FRAG  250  //protocol 250 unassigned used to identify fragmented IP packet
#ifdef _MSC_VER
#define IPPROTO_GRE   47
#define PCAP_NETMASK_UNKNOWN  0xffffffff
#endif

const int PACKET_MAX = 357;  //max packet size ETH 14 VLAN 4 IP 20 GRE 4 IP 20 UDP 8 DNS HEAD 12 DNS NAME 255 DNS TAIL 20

//ethernet header
#pragma pack(1)
struct ether_header
{
  unsigned char ether_dhost[6], ether_shost[6];
  unsigned short ether_type;
};

//ARP header
struct ether_arp
{
  unsigned short ar_hrd, ar_pro;
  unsigned char ar_hln, ar_pln;
  unsigned short ar_op;
  unsigned char arp_sha[6], arp_spa[4], arp_tha[6], arp_tpa[4];
};

//fake link-layer header
struct sll_header
{
  unsigned short sll_pkttype, sll_hatype, sll_halen;
  unsigned char sll_addr[8];
  unsigned short sll_protocol;
};

//PPP header
struct ppp_header
{
  unsigned char ppp_addr, ppp_ctrl;
  unsigned short ppp_protocol;
};

//IPv4 header
struct iphdr
{
  unsigned char ihl:4, version:4, tos;
  unsigned short tot_len, id, frag_off;
  unsigned char ttl, protocol;
  unsigned short check;
  unsigned int saddr, daddr;
};

//GRE header
#pragma pack(1)
struct gre_hdr
{
  unsigned char crks:4, srec:4, fgvr;
  unsigned short type;
};

//TCP header
struct tcphdr
{
  unsigned short source, dest;
  unsigned int seq, ack_seq;
  unsigned short res1:4, doff:4, fin:1, syn:1, rst:1, psh:1, ack:1, urg:1, res2:2, window, check, urg_ptr;
};

//UDP header
struct udphdr
{
  unsigned short source, dest, len, check;
};

//DNS header
struct HEADER
{
  unsigned int id:16, rd:1, tc:1, aa:1, opcode:4, qr:1, rcode:4, cd:1, ad:1, unused:1, ra:1, qdcount:16, ancount:16, nscount:16, arcount:16;
};

//DNS response tail
#pragma pack(1)
struct dns_tail
{
  unsigned short qtype, qclas, name, type, clas;
  unsigned int ttl;
  unsigned short len;
  in_addr addr;
};

const size_t ETHER_HDR_SIZE = sizeof(ether_header), ARP_HDR_SIZE = ETHER_HDR_SIZE + sizeof(ether_arp), SLL_HDR_SIZE = sizeof(sll_header), PPP_HDR_SIZE = sizeof(ppp_header)
  , IP_HDR_SIZE = sizeof(iphdr), GRE_HDR_SIZE = IP_HDR_SIZE + sizeof(gre_hdr), GRE_TAIL_SIZE = GRE_HDR_SIZE + IP_HDR_SIZE, TCP_HDR_SIZE = IP_HDR_SIZE + sizeof(tcphdr)
  , UDP_HDR_SIZE = IP_HDR_SIZE + sizeof(udphdr), DNS_HDR_SIZE = UDP_HDR_SIZE + sizeof(HEADER), DNS_TAIL_SIZE = DNS_HDR_SIZE + sizeof(dns_tail), SOCK_ADDR_SIZE = sizeof(sockaddr_in);
