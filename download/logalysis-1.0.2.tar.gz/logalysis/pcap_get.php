<?php
/* Copyright 2012-2016 Del Castle */

include "common.php";
session_start();
/*if (isset($_SESSION["las_last_activity"]) && ((time() - $_SESSION["las_last_activity"]) > 3600))
{
  session_unset();
  session_destroy();
} 
$_SESSION["las_last_activity"] = time();*/
if (empty($_SESSION["las_login_user_name"])) exit($login_bounce);

$file_id = (isset($_GET["file_id"]) ? $_GET["file_id"] : 0);
$file_name = "files/{$_SESSION["las_login_user_name"]}";

include "plugins/file/{$_GET["plugin"]}.generate_file.php";

if (file_exists($file_name))
{
  header("Content-Type: application/vnd.tcpdump.pcap");
  header("Content-Disposition: filename=\"" . basename($file_name) . "\"");
  header("Content-Transfer-Encoding: binary");
  header("Expires: 0");
  header("Cache-Control: must-revalidate");
  header("Content-Length: " . filesize($file_name));
  echo file_get_contents($file_name);
  unlink($file_name);
}
else echo "<html><body><script type='text/javascript'>alert(\"No PCAP Data!\"); history.back();</script></body></html>";

?>
