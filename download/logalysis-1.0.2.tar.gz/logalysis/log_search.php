<html>
<head>
<meta name='copyright' content='2012-2016 Del Castle' />
<meta charset='UTF-8' />
<meta http-equiv='content-type' content='text/html' />
<link rel='stylesheet' type='text/css' href='fx/css/logalysis.css' />

<script type='text/javascript' src='fx/js/edate.js'></script>

<script type='text/javascript' src='fx/js/logalysis.js'></script>

</head>
<body>

<div class='menu'>
  <a class='menu' href='#' onclick='document.forms[0].submit();'>SEARCH</a>
</div><br />

<?php

include "common.php";
session_start();
/*if (isset($_SESSION["las_last_activity"]) && ((time() - $_SESSION["las_last_activity"]) > 3600))
{
  session_unset();
  session_destroy();
} 
$_SESSION["las_last_activity"] = time();*/
if (empty($_SESSION["las_login_user_name"])) exit($login_bounce);
date_default_timezone_set("UTC");

$job_id = $_GET["job_id"];
$ref_no = $_GET["ref_no"];
$log_id = (isset($_GET["log_id"]) && is_numeric($_GET["log_id"]) ? $_GET["log_id"] : 0);
$limit = (isset($_GET["limit"]) ? $_GET["limit"] : 100);

$now_time = date("Y-m-d H:i:00");
if (isset($_GET["search"])) $search = explode(";", $_GET["search"]);
else if ($log_id)
{
  $link = logalysis_db_connect();

  $search = db_fetch_row($link, "SELECT log_type, start_time, finish_time, num_1, num_2, num_3, num_4, num_5, char_1_64, char_2_64, char_3_255, char_4_255, char_5_255, char_6_255, protocol, source_ip, source_port, target_ip, target_port FROM logs WHERE log_id = {$log_id}");

  if ($search) echo "<script type='text/javascript'>parent.frame_log_show.location.href = \"log_show.php?job_id={$job_id}&ref_no={$ref_no}&log_id={$log_id}&plugin={$search[0]}\";</script>";
  else echo "<script type='text/javascript'>parent.location.href = \"log_layout.php?job_id={$job_id}&ref_no={$ref_no}\";</script>";

  mysqli_close($link);
}
if (empty($search)) $search = array("", $now_time, $now_time, "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "");

echo "<form action='log_show.php' method='GET' target='frame_log_show'>";
echo "<input type='hidden' name='job_id' value='{$job_id}' />";
echo "<input type='hidden' name='ref_no' value='{$ref_no}' />";
echo "<select name='plugin' onchange='location.href = \"log_search.php?job_id={$job_id}&ref_no={$ref_no}&limit=\" + (typeof(limit) === \"undefined\" ? \"{$limit}\" : limit.value) + \"&search=\" + escape(this.value + \";\" + (typeof(start_time) === \"undefined\" ? \"{$search[1]}\" : start_time.value) + \";\" + (typeof(finish_time) === \"undefined\" ? \"{$search[2]}\" : finish_time.value) + \";;;;;;;;;;;;;\" + (typeof(source_ip) === \"undefined\" ? \"{$search[15]}\" : source_ip.value) + \";\" + (typeof(source_port) === \"undefined\" ? \"{$search[16]}\" : source_port.value) + \";\" + (typeof(target_ip) === \"undefined\" ? \"{$search[17]}\" : target_ip.value) + \";\" + (typeof(target_port) === \"undefined\" ? \"{$search[18]}\" : target_port.value));'>";
$log_plugins = scandir("plugins/log");
foreach ($log_plugins as &$row)
{
  if (strstr($row, ".search_log.php"))
  {
    $row = preg_replace("/^(.+)\.search_log\.php$/", "$1", $row);
    if (!$search[0]) $search[0] = $row;
    echo "<option value='{$row}'";
    if ($row == $search[0]) echo " selected";
    echo ">" . strtr($row, "_", " ") . "</option>";
  }
}
echo "</select><br />";

include "plugins/log/{$search[0]}.search_log.php";

echo "</form>";

?>

</body>
</html>
