<?php

include "plugins/misc/sourcefire.php";
include "plugins/cred/sourcefire.cred.php";

$link = logalysis_db_connect();

echo "<script type='text/javascript'>";
echo "function textLog() { var aryTd, aryTr = document.getElementsByTagName(\"tr\"), winTl = popUp(\"\"); winTl.document.write(\"<pre>\"); for (var cnt = 0; cnt < aryTr.length; cnt++) { aryTd = aryTr[cnt].getElementsByTagName(\"td\"); if (aryTd[0]) winTl.document.write(aryTd[1].textContent + \"\\t\" + aryTd[5].textContent + \" (\" + aryTd[6].textContent + \")\\t\" + aryTd[7].textContent + \"\\t\" + aryTd[8].textContent + \"\\t\" + aryTd[9].textContent + \"\\t\" + aryTd[10].textContent + \"\\t\" + aryTd[11].textContent + \"\\n\"); } winTl.document.write(\"</pre>\"); }";
echo "function sflJob(objTr) { aryTd = objTr.getElementsByTagName(\"td\"); parent.location.href = \"details_show.php?details=\" + escape(\"0;0;1;4;{$login_user_id};\" + aryTd[4].textContent + \";Sourcefire Alert: \" + aryTd[5].textContent.replace(/'/g, \"\\\"\") + \";GID/SID: \" + aryTd[6].textContent + \"\\nClassification: \" + aryTd[12].textContent + \"\\nBlocked: \" + aryTd[3].textContent + \";;;;;\" + aryTd[1].textContent + \";\" + aryTd[7].textContent + \";\" + aryTd[8].textContent + \";\" + aryTd[9].textContent + \";\" + aryTd[10].textContent + \";\" + aryTd[11].textContent); }";
echo "</script>";

if (empty($nohdr)) echo "<h4>SOURCEFIRE</h4>";
echo "<table class='esort'>";
echo "<tr><th></th><th>Time</th><th>Priority</th><th>Blocked</th><th>Sensor</th><th>Alert</th><th>GID/SID</th><th>Protocol</th><th>Source IP</th><th>Port</th><th>Target IP</th><th>Port</th><th>Classification</th><th>Impact</th><th>EID</th><th>Actions</th></tr>";
$count = 0;
$result = mysqli_query($link, "SELECT time_1, num_1, char_1_64, char_3_255, char_4_255, num_2, num_3, protocol, source_ip, source_port, target_ip, target_port, char_5_255, char_2_64, num_4, data FROM events WHERE log_id = {$log_id} ORDER BY time_1");
while ($row = mysqli_fetch_row($result))
{
  $sensor_id = preg_replace("/^(\d+):[^!]+$/", "$1", $row[3]);
  echo "<tr onclick='txtBold(this.style);'><td>" . ++$count . "</td>";
  $row[1] = sourcefire_priority($row[1], FALSE, FALSE);
  $row[5] = ($row[5] > 3 ? "{$row[5]}:{$row[6]}" : "<a class='action' href='javascript:popUp(\"{$sourcefire_www_host}/external_rule.cgi?sid={$row[6]}\");'>{$row[5]}:{$row[6]}</a>");
  unset($row[6]);
  $row[7] = protocol_name($row[7]);
  $row[15] = ($row[15] ? "<a class='action' href='pcap_get.php?plugin=Sourcefire&file_id={$sensor_id};{$row[14]};" . strtotime($row[0]) . "'>PCAP</a> <a class='action' href='file_layout.php?job_id={$job_id}&ref_no={$ref_no}&search=Sourcefire;{$row[0]};{$row[0]};{$row[8]};{$row[9]};{$row[10]};{$row[11]}&file_id={$sensor_id};{$row[14]};" . strtotime($row[0]) . "' target='frame_show'>FILE</a> " : "") . "<a class='action' href='javascript:void(0);' onclick='sflJob(this.parentNode.parentNode);'>JOB</a>";
  $row[8] = "<a class='action' href='javascript:popUp(\"host_show.php?host_ip={$row[8]}\");'>{$row[8]}</a>";
  $row[10] = "<a class='action' href='javascript:popUp(\"host_show.php?host_ip={$row[10]}\");'>{$row[10]}</a>";
  foreach ($row as &$cell) echo "<td>{$cell}</td>";
  echo "</tr>";
}
mysqli_free_result($result);
echo "</table>";

mysqli_close($link);

?>
