<html>
<head>
<meta name='copyright' content='2012-2016 Del Castle' />
<meta charset='UTF-8' />
<meta http-equiv='content-type' content='text/html' />
<link rel='stylesheet' type='text/css' href='fx/css/logalysis.css' />

<script type='text/javascript' src='fx/js/logalysis.js'></script>

</head>
<body>

<?php

include "common.php";
session_start();
/*if (isset($_SESSION["las_last_activity"]) && ((time() - $_SESSION["las_last_activity"]) > 3600))
{
  session_unset();
  session_destroy();
} 
$_SESSION["las_last_activity"] = time();*/
if (empty($_SESSION["las_login_user_id"])) exit($login_bounce);

$login_user_id = $_SESSION["las_login_user_id"];
$user_id = (isset($_POST["user_id"]) && is_numeric($_POST["user_id"]) ? $_POST["user_id"] : (isset($_GET["user_id"]) && is_numeric($_GET["user_id"]) ? $_GET["user_id"] : 0));
$action = (isset($_POST["action"]) ? $_POST["action"] : (isset($_GET["action"]) ? $_GET["action"] : ""));

if (($user_id != $login_user_id) && !$_SESSION["las_login_user_admin"]) exit($login_bounce);

$link = logalysis_db_connect();

if (isset($_POST["user_id"]))
{
  $user_name = $_POST["user_name"];
  $actual = $_POST["actual"];
  $roles = $_POST["roles"];
  $password = $_POST["password"];
  $expired = (isset($_POST["expired"]) ? $_POST["expired"] : "");
  $old_expired = (isset($_POST["old_expired"]) ? $_POST["old_expired"] : "");
  $locked = (isset($_POST["locked"]) ? $_POST["locked"] : "");
  $old_locked = (isset($_POST["old_locked"]) ? $_POST["old_locked"] : "");
  $is_admin = (isset($_POST["is_admin"]) ? $_POST["is_admin"] : "");
  $old_is_admin = (isset($_POST["old_is_admin"]) ? $_POST["old_is_admin"] : "");
  $is_disabled = (isset($_POST["is_disabled"]) ? $_POST["is_disabled"] : "");
  $old_is_disabled = (isset($_POST["old_is_disabled"]) ? $_POST["old_is_disabled"] : "");
  if ($password == $_POST["again_password"])
  {
    if (($user_id && !$password) || preg_match("/.*^(?=.{8,20})(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9\W]).*$/", $password))
    {
      if ($user_name)
      {
        $extra = "";
        $hash = ($password ? sha1($password . strrev($user_name)) : "");
        $old_hash = ($user_id ? db_result($link, "SELECT hash FROM users WHERE name = '" . addslashes($user_name) . "'") : "");
        if ($hash == $old_hash) $error = "CANNOT REUSE OLD PASSWORD";
        else if ($user_name != $_POST["old_user_name"])
        {
          $count = db_result($link, "SELECT COUNT(1) FROM users WHERE name = '" . addslashes($user_name) . "'");
          if ($count) $error = "USERNAME ALREADY EXISTS";
          else if (!$hash) $error = "ENTER A NEW PASSWORD WHEN CHANGING USERNAME";
          else if ($user_id)
          {
            $extra = " name = '" . addslashes($user_name) . "'";
            if (!$action && ($user_id == $login_user_id))
            {
              $_SESSION["las_login_user_name"] = $user_name;

              echo "<script type='text/javascript'>top.frame_header.document.getElementById(\"ancLu\").textContent = \"LOGOUT {$user_name}\";</script>";
            }
          }
        }
        if ($user_id)
        {
          if ($actual != $_POST["old_actual"]) $extra .= ($extra ? "," : "") . " actual = '" . addslashes($actual) . "'";
          if ($roles != $_POST["old_roles"])
          {
            $extra .= ($extra ? "," : "") . " roles = '" . addslashes($roles) . "'";
            if (!$action && ($user_id == $login_user_id)) $_SESSION["las_login_user_roles"] = $roles;
          }
          if ($hash && !isset($error))
          {
            $extra .= ($extra ? "," : "") . " hash = '{$hash}', hash_time = " . ($expired ? 0 : "UTC_TIMESTAMP()");
            if ($action) echo "<script type='text/javascript'>location.href = \"header.php?action=logout\";</script>";
          }
          else if ($expired != $old_expired) $extra .= ($extra ? "," : "") . " hash_time = " . ($expired ? 0 : "UTC_TIMESTAMP()");
          if ($locked != $old_locked) $extra .= ($extra ? "," : "") . " attempts = " . ($locked ? 10 : 0);
          if ($is_admin != $old_is_admin)
          {
            $extra .= ($extra ? "," : "") . " is_admin = " . ($is_admin ? "TRUE" : "FALSE");
            if ($user_id == $login_user_id) $_SESSION["las_login_user_admin"] = ($is_admin ? 1 : 0);
          }
          if ($is_disabled != $old_is_disabled)
          {
            $extra .= ($extra ? "," : "") . " is_disabled = " . ($is_disabled ? "TRUE" : "FALSE");
            if (($user_id == $login_user_id) && $is_disabled) echo "<script type='text/javascript'>location.href = \"header.php?action=logout\";</script>";
          }
          if ($extra)
          {
            $sql = "UPDATE users SET{$extra} WHERE user_id = {$user_id}";
            mysqli_query($link, $sql);
            write_audit($link, 0, $login_user_id, 5, $sql);
          }
        }
        else if (!isset($error))
        {
          $sql = "INSERT INTO users VALUES(0, '" . addslashes($user_name) . "', '" . addslashes($actual) . "', '" . addslashes($roles) . "', '{$hash}', " . ($expired ? 0 : "UTC_TIMESTAMP()") . ", " . ($locked ? 10 : 0) . ", " . ($is_admin ? "TRUE" : "FALSE") . ", " . ($is_disabled ? "TRUE" : "FALSE") . ")";
          mysqli_query($link, $sql);
          $user_id = mysqli_insert_id($link);
          write_audit($link, 0, $login_user_id, 4, $sql);
        }

        if (!$action && $user_id) echo "<script type='text/javascript'>parent.frame_settings_list.location.reload();</script>";
      }
      else $error = "ENTER USERNAME";
    }
    else $error = "PASSWORD TOO SIMPLE - LENGTH 8-20, MUST HAVE A LOWER, UPPER & DIGIT/SPECIAL";
  }
  else $error = "PASSWORDS DO NOT MATCH";
}

echo "<div class='menu'>";
echo "<a class='menu' href='#' onclick='this.style.display = \"none\"; visState(\"ancPw\", 1); document.forms[0].submit();'>SAVE" . ($user_id ? "" : " NEW") . "</a>";
echo "<a id='ancPw' class='menu' style='color:#FF9999; visibility:hidden'>PLEASE WAIT...</a>";
echo "</div><br />";

if ($action) echo "<h5>PASSWORD EXPIRED!</h5>";
if (isset($error)) echo "<h5>ERROR - {$error}!</h5>";

echo "<form action='user_show.php' method='POST'>";
echo "<input type='hidden' name='user_id' value='{$user_id}' />";
echo "<input type='hidden' name='action' value='{$action}' />";
echo "<table>";
$user = db_fetch_row($link, "SELECT name, actual, roles, hash_time, attempts, is_admin, is_disabled FROM users WHERE user_id = {$user_id}");
echo "<tr><td>Username</td><td><input type='text' name='user_name' size='42' maxlength='32' value='" . (!$user_id && isset($_POST["user_name"]) ? $_POST["user_name"] : $user[0]) . "' /></td></tr>";
echo "<input type='hidden' name='old_user_name' value='{$user[0]}' />";
echo "<tr><td>Actual Name</td><td><input type='text' name='actual' size='42' maxlength='40' value='" . htmlspecialchars((!$user_id && isset($_POST["actual"]) ? $_POST["actual"] : $user[1]), ENT_QUOTES) . "' /></td></tr>";
echo "<input type='hidden' name='old_actual' value='{$user[1]}' />";
echo "<tr><td>Roles</td><td><input type='text' name='roles' size='42' maxlength='64' value='" . (!$user_id && isset($_POST["roles"]) ? $_POST["roles"] : $user[2]) . "' /></td></tr>";
echo "<input type='hidden' name='old_roles' value='{$user[2]}' />";
echo "<tr><td>Password</td><td><input type='password' name='password' size='42' maxlength='20' /></td></tr>";
echo "<tr><td>Password Again</td><td><input type='password' name='again_password' size='42' maxlength='20' /></td></tr>";
if (!$action)
{
  if ($_SESSION["las_login_user_admin"])
  {
    echo "<tr><td>Expired</td><td><input type='checkbox' name='expired' value='on'" . ((time() - strtotime($user[3])) > 7776000 ? " checked='checked'" : "") . " /></td></tr>";
    echo "<input type='hidden' name='old_expired' value='" . ((time() - strtotime($user[3])) > 7776000 ? "on" : "") . "' />";
    echo "<tr><td>Locked</td><td><input type='checkbox' name='locked' value='on'" . ($user[4] > 9 ? " checked='checked'" : "") . " /></td></tr>";
    echo "<input type='hidden' name='old_locked' value='" . ($user[4] > 9 ? "on" : "") . "' />";
    echo "<tr><td>Administrator</td><td><input type='checkbox' name='is_admin' value='on'" . ($user[5] ? " checked='checked'" : "") . " /></td></tr>";
    echo "<input type='hidden' name='old_is_admin' value='" . ($user[5] ? "on" : "") . "' />";
    echo "<tr><td>Disabled</td><td><input type='checkbox' name='is_disabled' value='on'" . ($user[6] ? " checked='checked'" : "") . " /></td></tr>";
    echo "<input type='hidden' name='old_is_disabled' value='" . ($user[6] ? "on" : "") . "' />";
  }
}
echo "</table>";
echo "</form>";

mysqli_close($link);

?>

</body>
</html>
