<html>
<head>
<meta name='copyright' content='2012-2016 Del Castle' />
<meta charset='UTF-8' />
<meta http-equiv='content-type' content='text/html' />
<link rel='stylesheet' type='text/css' href='fx/css/logalysis.css' />

<script type='text/javascript' src='fx/js/edate.js'></script>

<script type='text/javascript' src='fx/js/logalysis.js'></script>

</head>
<body>

<div class='menu'>
  <a class='menu' href='#' onclick='document.forms[0].submit();'>GENERATE CHART</a>
</div><br />

<?php

include "common.php";
session_start();
/*if (isset($_SESSION["las_last_activity"]) && ((time() - $_SESSION["las_last_activity"]) > 3600))
{
  session_unset();
  session_destroy();
} 
$_SESSION["las_last_activity"] = time();*/
if (empty($_SESSION["las_login_user_name"])) exit($login_bounce);
date_default_timezone_set("UTC");

$limit = (isset($_GET["limit"]) ? $_GET["limit"] : 10);
$plugin = (isset($_GET["plugin"]) ? $_GET["plugin"] : "");
$start_time = (isset($_GET["start_time"]) ? $_GET["start_time"] : date("Y-m-d 00:00:00", strtotime("-1 month")));
$finish_time = (isset($_GET["finish_time"]) ? $_GET["finish_time"] : date("Y-m-d 00:00:00", strtotime("+1 day")));

echo "<form action='chart_show.php' method='POST' target='frame_chart_show'>";
echo "<select name='plugin' onchange='location.href = \"chart_search.php?limit=\" + (typeof(limit) === \"undefined\" ? \"{$limit}\" : limit.value) + \"&plugin=\" + escape(this.value) + \"&start_time=\" + escape(typeof(start_time) === \"undefined\" ? \"{$start_time}\" : start_time.value) + \"&finish_time=\" + escape(typeof(finish_time) === \"undefined\" ? \"{$finish_time}\" : finish_time.value);'>";
$chart_plugins = scandir("plugins/chart");
foreach ($chart_plugins as &$row)
{
  if (strstr($row, ".search_chart.php"))
  {
    $row = preg_replace("/^(.+)\.search_chart\.php$/", "$1", $row);
    if (!$plugin) $plugin = $row;
    echo "<option value='{$row}'";
    if ($row == $plugin) echo " selected";
    echo ">" . strtr($row, "_", " ") . "</option>";
  }
}
echo "</select><br />";

include "plugins/chart/{$plugin}.search_chart.php";

echo "</form>";

?>

</body>
</html>
