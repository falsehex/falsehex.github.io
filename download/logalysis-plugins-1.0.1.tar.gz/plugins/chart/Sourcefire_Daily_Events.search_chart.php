<?php

echo "<p><select name='shape' onchange='visState(\"objSv\", (this.value == \"vbar\"));'>";
echo "<option value='vbar'>Vertical Bar</option>";
echo "<option value='line'>Line</option>";
echo "</select></p>";
search_time($start_time, $finish_time);
echo "<p>Blocked <select name='blocked'>";
echo "<option value='0'>N/A</option>";
echo "<option value='yes'>Yes</option>";
echo "<option value='no'>No</option>";
echo "</select></p>";
echo "<p id='objSv'><input type='checkbox' name='show_vals' />Show Value on Bar</p>";

?>
