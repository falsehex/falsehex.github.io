<?php

include "plugins/misc/sourcefire.php";
include "plugins/cred/sourcefire.cred.php";

$link = mysqli_connect($sourcefire_db_host, $sourcefire_db_user, $sourcefire_db_pass, $sourcefire_db_name);
if (!$link) die("Error: mysql db {$sourcefire_db_name} connect failed");

if (!isset($ip_or)) $ip_or = (isset($_GET["ip_or"]) ? $_GET["ip_or"] : "");

echo "<script type='text/javascript'>";
echo "function textLog() { var aryTd, aryTr = document.getElementsByTagName(\"tr\"), winTl = popUp(\"\"); winTl.document.write(\"<pre>\"); for (var cnt = 0; cnt < aryTr.length; cnt++) { aryTd = aryTr[cnt].getElementsByTagName(\"td\"); if (aryTd[0]) winTl.document.write(aryTd[1].textContent + \"\\t\" + aryTd[5].textContent + \" (\" + aryTd[6].textContent + \")\\t\" + aryTd[7].textContent + \"\\t\" + aryTd[8].textContent + \"\\t\" + aryTd[9].textContent + \"\\t\" + aryTd[10].textContent + \"\\t\" + aryTd[11].textContent + \"\\n\"); } winTl.document.write(\"</pre>\"); }";
echo "function sfgJob(objTr) { aryTd = objTr.getElementsByTagName(\"td\"); parent.location.href = \"details_show.php?details=\" + escape(\"0;0;1;4;{$login_user_id};\" + aryTd[4].textContent + \";Sourcefire Alert: \" + aryTd[5].textContent.replace(/'/g, \"\\\"\") + \";GID/SID: \" + aryTd[6].textContent + \"\\nClassification: \" + aryTd[12].textContent + \"\\nBlocked: \" + aryTd[3].textContent + \";;;;;\" + aryTd[1].textContent + \";\" + aryTd[7].textContent + \";\" + aryTd[8].textContent + \";\" + aryTd[9].textContent + \";\" + aryTd[10].textContent + \";\" + aryTd[11].textContent); }";
echo "</script>";

if (empty($nohdr)) echo "<h4>SOURCEFIRE</h4>";
echo "<table class='esort'>";
echo "<tr><th></th><th>Time</th><th>Priority</th><th>Blocked</th><th>Sensor</th><th>Alert</th><th>GID/SID</th><th>Protocol</th><th>Source IP</th><th>Port</th><th>Target IP</th><th>Port</th><th>Classification</th><th>Impact</th><th>EID</th><th>Actions</th></tr>";
$count = 0;
$extra = ($start_time ? " WHERE tv_sec >= UNIX_TIMESTAMP('{$start_time}')" : "");
if ($finish_time) $extra .= ($extra ? " AND" : " WHERE") . " tv_sec <= UNIX_TIMESTAMP('{$finish_time}')";
if ($source_ip)
{
  if ($ip_or)
  {
    if (substr_count($source_ip, ".") == 3) $extra .= ($extra ? " AND" : " WHERE") . " (INET_NTOA(ip_src) = '{$source_ip}' OR INET_NTOA(ip_dst) = '{$source_ip}')";
    else $extra .= ($extra ? " AND" : " WHERE") . " (INET_NTOA(ip_src) LIKE '{$source_ip}%' OR INET_NTOA(ip_dst) LIKE '{$source_ip}%')";
  }
  else
  {
    if (substr_count($source_ip, ".") == 3) $extra .= ($extra ? " AND" : " WHERE") . " INET_NTOA(ip_src) = '{$source_ip}'";
    else $extra .= ($extra ? " AND" : " WHERE") . " INET_NTOA(ip_src) LIKE '{$source_ip}%'";
  }
}
if ($source_port) $extra .= ($extra ? " AND" : " WHERE") . " sport_itype = {$source_port}";
if ($target_ip)
{
  if (substr_count($target_ip, ".") == 3) $extra .= ($extra ? " AND" : " WHERE") . " INET_NTOA(ip_dst) = '{$target_ip}'";
  else $extra .= ($extra ? " AND" : " WHERE") . " INET_NTOA(ip_dst) LIKE '{$target_ip}%'";
}
if ($target_port) $extra .= ($extra ? " AND" : " WHERE") . " dport_icode = {$target_port}";
if ($num_2) $extra .= ($extra ? " AND" : " WHERE") . " sig_gen = {$num_2}";
if ($num_3) $extra .= ($extra ? " AND" : " WHERE") . " sig_id = {$num_3}";
if ($num_4) $extra .= ($extra ? " AND" : " WHERE") . " event_id = {$num_4}";
$result = mysqli_query($link, "SELECT FROM_UNIXTIME(tv_sec), priority, blocked, sensor_id, sig_gen, sig_id, protocol, INET_NTOA(ip_src), sport_itype, INET_NTOA(ip_dst), dport_icode, classification, impact, event_id, tv_sec FROM event{$extra} ORDER BY tv_sec LIMIT {$limit}");
while ($row = mysqli_fetch_row($result))
{
  $sensor_id = $row[3];
  $sig_gen = $row[4];
  $row[2] = $sourcefire_result[$row[2]];
  $row[3] .= ":" . db_result($link, "SELECT name FROM de_cache_de_config WHERE id = {$row[3]}");
  $row[4] = preg_replace("/^\"(.*)\"$/", "$1", db_result($link, "SELECT msg FROM ids_event_msg_map WHERE " . ($row[4] > 3 ? "gid = {$row[4]} AND " : "") . "local_sid = {$row[5]} ORDER BY rev DESC LIMIT 1"));
  $row[11] = $sourcefire_classification[$row[11]];
  //$row[11] = db_result($link, "SELECT description FROM ids_event_class_map WHERE local_id = {$row[11]}");
  $row[12] = $sourcefire_impact[$row[12]];
  //$row[12] = db_result($link, "SELECT impact_name FROM ids_impact_str WHERE impact = {$row[12]}");
  $data = db_result($link, "SELECT COUNT(1) FROM packet_log WHERE sensor_id = {$sensor_id} AND event_id = {$row[13]} AND event_sec = {$row[14]}");
  if ($action) $save[] = array($row[0], NULL, $row[1], $sig_gen, $row[5], $row[13], NULL, $row[2], $row[12], $row[3], $row[4], $row[11], NULL, $row[6], $row[7], $row[8], $row[9], $row[10], $data);
  echo "<tr onclick='txtBold(this.style);'><td>" . ++$count . "</td>";
  $row[1] = sourcefire_priority($row[1], FALSE, FALSE);
  $row[5] = ($sig_gen > 3 ? "{$sig_gen}:{$row[5]}" : "<a class='action' href='javascript:popUp(\"{$sourcefire_www_host}/external_rule.cgi?sid={$row[5]}\");'>{$sig_gen}:{$row[5]}</a>");
  $row[6] = protocol_name($row[6]);
  $row[14] = ($data ? "<a class='action' href='pcap_get.php?plugin=Sourcefire&file_id={$sensor_id};{$row[13]};{$row[14]}'>PCAP</a> <a class='action' href='file_layout.php?job_id={$job_id}&ref_no={$ref_no}&search=Sourcefire;{$row[0]};{$row[0]};{$row[7]};{$row[8]};{$row[9]};{$row[10]}&file_id={$sensor_id};{$row[13]};{$row[14]}' target='frame_show'>FILE</a> " : "") . "<a class='action' href='javascript:void(0);' onclick='sfgJob(this.parentNode.parentNode);'>JOB</a>";
  $row[7] = "<a class='action' href='javascript:popUp(\"host_show.php?host_ip={$row[7]}\");'>{$row[7]}</a>";
  $row[9] = "<a class='action' href='javascript:popUp(\"host_show.php?host_ip={$row[9]}\");'>{$row[9]}</a>";
  foreach ($row as &$cell) echo "<td>{$cell}</td>";
  echo "</tr>";
}
mysqli_free_result($result);
echo "</table>";

mysqli_close($link);

?>
