/* llist-s.cpp - 01 Sep 15
   Linked List Single
   Copyright 2006-2015 Del Castle  */

#include <stdlib.h>
#include <string.h>

#include "llist-s.h"

LinkedList::Item::Item(void *data, size_t num, Item *prev)
{
  Data = malloc(num);
  memcpy(Data, data, num);
  Next = 0;
  Prev = prev;
}

LinkedList::Item::~Item()
{
  free(Data);
}

LinkedList::LinkedList()
{
  pFront = 0;
  pBack = 0;
  pItem = 0;
  cntItems = 0;
}

unsigned int LinkedList::Items()
{
  return cntItems;
}

void *LinkedList::Write(void *data, size_t num)
{
  pItem = new Item(data, num, pBack);
  if (pBack) pBack->Next = pItem;
  else pFront = pItem;
  pBack = pItem;
  cntItems++;
  return pItem->Data;
}

void LinkedList::Start()
{
  pItem = pFront;
}

void *LinkedList::Read()
{
  if (pItem) return pItem->Data;
  return 0;
}

void LinkedList::Next()
{
  if (pItem) pItem = pItem->Next;
}

void LinkedList::Delete()
{
  cntItems--;
  Item *pTemp = pItem;
  pItem = pItem->Next;
  if (pTemp->Prev) pTemp->Prev->Next = pTemp->Next;
  else pFront = pTemp->Next;
  if (pTemp->Next) pTemp->Next->Prev = pTemp->Prev;
  else pBack = pTemp->Prev;
  delete pTemp;
}
