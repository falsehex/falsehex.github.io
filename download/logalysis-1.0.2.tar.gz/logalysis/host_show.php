<html>
<head>
<meta name='copyright' content='2012-2016 Del Castle' />
<meta charset='UTF-8' />
<meta http-equiv='content-type' content='text/html' />
<link rel='stylesheet' type='text/css' href='fx/css/logalysis.css' />

<script type='text/javascript' src='fx/js/esort.js'></script>

<script type='text/javascript' src='fx/js/logalysis.js'></script>

</head>
<body>

<?php

include "common.php";
session_start();
/*if (isset($_SESSION["las_last_activity"]) && ((time() - $_SESSION["las_last_activity"]) > 3600))
{
  session_unset();
  session_destroy();
} 
$_SESSION["las_last_activity"] = time();*/
if (empty($_SESSION["las_login_user_name"])) exit($login_bounce);

include "plugins/geoip/geoip.php";

$host_ip = (isset($_POST["host_ip"]) ? $_POST["host_ip"] : (isset($_GET["host_ip"]) ? $_GET["host_ip"] : ""));
$host_name = (isset($_POST["host_name"]) ? $_POST["host_name"] : (isset($_GET["host_name"]) ? $_GET["host_name"] : ""));
$category = (isset($_POST["category"]) ? $_POST["category"] : (isset($_GET["category"]) ? $_GET["category"] : ""));
$location = (isset($_POST["location"]) ? $_POST["location"] : (isset($_GET["location"]) ? $_GET["location"] : ""));
$details = (isset($_POST["details"]) ? $_POST["details"] : (isset($_GET["details"]) ? $_GET["details"] : ""));

$link = logalysis_db_connect();

if (isset($_GET["action"])) mysqli_query($link, "DELETE FROM hosts WHERE host_ip = '" . addslashes($host_ip) . "'"); 
else if (isset($_POST["host_ip"])) mysqli_query($link, "INSERT INTO hosts VALUES('" . addslashes($host_ip) . "', '" . addslashes($host_name) . "', '" . addslashes($category) . "', '" . addslashes($location) . "', '" . addslashes($details) . "', UTC_TIMESTAMP()) ON DUPLICATE KEY UPDATE name = '" . addslashes($host_name) . "', category = '" . addslashes($category) . "', location = '" . addslashes($location) . "', details = '" . addslashes($details) . "', mod_time = UTC_TIMESTAMP()");

echo "<div class='menu'>";
echo "<a class='menu' href='#' onclick='document.forms[0].submit();'>SEARCH</a>";
echo "<a class='menu' href='#' onclick='this.style.display = \"none\"; visState(\"ancPw\", 1); document.forms[0].method = \"POST\"; document.forms[0].submit();'>SAVE</a>";
echo "<a class='menu' href='log_layout.php?job_id=1&ref_no=SCRATCHPAD&search=" . urlencode(";;;;;;;;;;;;;;;{$host_ip};;;") . "' target='frame_show'>SEARCH LOGS</a>";
echo "<a id='ancPw' class='menu' style='color:#FF9999; visibility:hidden'>PLEASE WAIT...</a>";
echo "</div><br />";

echo "<form action='host_show.php' method='GET'>";
echo "<table>";
echo "<tr><td>Host IP</td><td><input type='text' name='host_ip' size='20' maxlength='18' value='{$host_ip}' onkeypress='if (event.keyCode == 13) submit();' /></td></tr>";
$host = db_fetch_row($link, "SELECT * FROM hosts WHERE host_ip = '" . addslashes($host_ip) . "'");
echo "<tr><td>Hostname</td><td><input type='text' name='host_name' size='82' maxlength='64' value='" . ($host ? $host[1] : $host_name) . "' onkeypress='if (event.keyCode == 13) submit();' /></td></tr>";
echo "<tr><td>Category</td><td><input type='text' name='category' style='text-transform:uppercase' size='20' maxlength='16' value='" . ($host ? $host[2] : $category) . "' onkeypress='if (event.keyCode == 13) submit();' />";
echo "<select onchange='category.value = this.value;'><option></option>";
$result = mysqli_query($link, "SELECT category FROM hosts GROUP BY category");
while ($row = mysqli_fetch_row($result)) echo "<option value='{$row[0]}'>{$row[0]}</option>";
mysqli_free_result($result);
echo "</select></td></tr>";
echo "<tr><td>Location</td><td><input type='text' name='location' size='" . ($host_ip ? 72 : 82) . "' maxlength='64' value='" . ($host ? $host[3] : $location) . "' onkeypress='if (event.keyCode == 13) submit();' />";
if ($host_ip) echo "<input type='button' value='Lookup' onclick='location.value += \"" . geo_lookup($host_ip, FALSE) . "\";' />";
echo "</td></tr>";
echo "<tr><td>Details</td><td><input type='text' name='details' size='82' maxlength='255' value='" . ($host ? $host[4] : $details) . "' onkeypress='if (event.keyCode == 13) submit();' /></td></tr>";
echo "</table>";
echo "</form>";

echo "<table id='tblHt' class='esort'>";
echo "<tr><th></th><th>Host IP</th><th>Hostname</th><th>Category</th><th>Location</th><th>Details</th><th>Modified</th><th>Delete</th></tr>";
$count = 0;
$extra = ($host_ip ? " WHERE host_ip LIKE '" . addslashes($host_ip) . "%'" : "");
if ($host_name) $extra .= ($extra ? " AND" : " WHERE") . " LOWER(name) LIKE LOWER('%" . addslashes($host_name) . "%')";
if ($category) $extra .= ($extra ? " AND" : " WHERE") . " category = '" . addslashes($category) . "'";
if ($location) $extra .= ($extra ? " AND" : " WHERE") . " LOWER(location) LIKE LOWER('%" . addslashes($location) . "%')";
if ($details) $extra .= ($extra ? " AND" : " WHERE") . " LOWER(details) LIKE LOWER('%" . addslashes($details) . "%')";
$result = mysqli_query($link, "SELECT * FROM hosts{$extra} ORDER BY host_ip");
while ($row = mysqli_fetch_row($result))
{
  echo "<tr onclick='txtBold(this.style);'><td>" . ++$count . "</td>";
  $row[6] = "<a class='action' href='javascript:void(0);' ondblclick='location.href =\"host_show.php?host_ip={$row[0]}&action=delete\";'>DEL</a>";
  $row[0] = "<a class='action' href='host_show.php?host_ip={$row[0]}'>{$row[0]}</a>";
  foreach ($row as &$cell) echo "<td>{$cell}</td>";
  echo "</tr>";
}
mysqli_free_result($result);
echo "</table>";
if (!$count)
{
  echo "<h5>NOT FOUND!</h5>";

  echo "<script type='text/javascript'>visState(\"tblHt\", 0);</script>";
}

mysqli_close($link);

?>

</body>
</html>
