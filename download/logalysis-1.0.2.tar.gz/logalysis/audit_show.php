<html>
<head>
<meta name='copyright' content='2012-2016 Del Castle' />
<meta charset='UTF-8' />
<meta http-equiv='content-type' content='text/html' />
<link rel='stylesheet' type='text/css' href='fx/css/logalysis.css' />

<script type='text/javascript' src='fx/js/esort.js'></script>

</head>
<body>

<?php

include "common.php";
session_start();
/*if (isset($_SESSION["las_last_activity"]) && ((time() - $_SESSION["las_last_activity"]) > 3600))
{
  session_unset();
  session_destroy();
} 
$_SESSION["las_last_activity"] = time();*/
if (empty($_SESSION["las_login_user_name"])) exit($login_bounce);
$_SESSION["las_menu_tab"] = 0;

$job_id = (is_numeric($_GET["job_id"]) ? $_GET["job_id"] : 0);

$link = logalysis_db_connect();

echo "<table class='esort'>";
echo "<tr><th>Time</th><th>User</th><th>Action</th><th>Details</th></tr>";
$result = mysqli_query($link, "SELECT save_time, save_user_id, action, details FROM trail WHERE job_id = {$job_id} ORDER BY save_time");
while ($audit = mysqli_fetch_row($result))
{
  if (preg_match("/user_id = (\d+)/", $audit[3], $matches)) $audit[3] = preg_replace("/user_id = \d+/", "user_id = " . get_user_name($link, $matches[1]), $audit[3]);
  if (preg_match("/state_id = (\d+)/", $audit[3], $matches)) $audit[3] = preg_replace("/state_id = \d+/", "state_id = " . get_state_name($link, $matches[1]), $audit[3]);
  echo "<tr><td>{$audit[0]}</td><td>" . get_user_name($link, $audit[1]) . "</td><td>{$audit[2]}</td><td>{$audit[3]}</td></tr>";
}
mysqli_free_result($result);
echo "</table>";

mysqli_close($link);

?>

</body>
</html>
