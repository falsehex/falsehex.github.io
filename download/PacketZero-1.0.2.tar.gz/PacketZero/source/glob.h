/* glob.h - 01 Sep 15
   PacketZero - 3D Network Monitor
   Copyright 2006-2015 Del Castle  */

#include <string.h>

//view position/direction
struct view_spot
{
  double X, Y, Z, AngleX, AngleY;
};

class GLob
{
  private:
    struct glob_vertex  //vertex
    {
      float X, Y, Z;
    };
    struct glob_color  //colour
    {
      unsigned char Red, Green, Blue;
    };
    struct glob_tri  //triangle
    {
      unsigned char A, B, C;
    };
    struct glob_quad  //square
    {
      unsigned char A, B, C, D;
    };
    struct glob_cross  //cross object
    {
      glob_vertex Vertex[28];
      glob_color Color[28];
      glob_quad Quad[8];
    } oCross;
    struct glob_host  //host object
    {
      glob_vertex Vertex[10];
      glob_color Color[10];
      glob_color ColorOrange[10];
      glob_color ColorYellow[10];
      glob_color ColorFluro[10];
      glob_color ColorGreen[10];
      glob_color ColorMint[10];
      glob_color ColorAqua[10];
      glob_color ColorSky[10];
      glob_color ColorPurple[10];
      glob_color ColorViolet[10];
      glob_color ColorRedBright[10];
      glob_color ColorRed[10];
      glob_tri Tri[16];
    } oHost;
    struct glob_cluster  //cluster object
    {
      glob_vertex Vertex[11];
      glob_color Color[11];
      glob_color ColorRed[11];
      glob_tri Tri[16];
    } oCluster;
    struct glob_packet  //packet object
    {
      glob_vertex Vertex[8];
      glob_tri Tri[12];
    } oPacket;
    struct glob_active  //active alert object
    {
      glob_vertex Vertex[8];
      glob_tri Tri[6];
    } oActive;
    struct glob_anomaly  //anomaly alert object
    {
      glob_vertex Vertex[12];
    } oAnomaly;
    size_t szCrossVertex, szHostVertex, szHostColor, szClusterVertex, szClusterColor;
    unsigned int vboId[11];  //GL compiled font, vertex buffer objects
  public:
    GLob();
    ~GLob();
    void DrawCross();
    void DrawHost(unsigned char color, unsigned char green, unsigned char blue, bool render);
    void DrawCluster(bool selected);
    void DrawPacket(unsigned char red, unsigned char green, unsigned char blue);
    void DrawAlert(bool active);
    void DrawLink(int x1, int y1, int z1, int x2, int y2, int z2);
};
