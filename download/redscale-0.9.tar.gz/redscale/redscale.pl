#!/usr/bin/perl

#  redscale.pl - Version 0.9  22 Dec 16
#  Redscale
#  Copyright 2016 Del Castle

#  Redscale is a Indicator Of Compromise (IOC) Manager.

#  Usage: sudo perl redscale.pl

use strict;
use warnings;
use threads;
use Digest::MD5 qw(md5_hex);
use File::Path qw(make_path);
use IO::Socket::INET;
use POSIX;
use Time::Local qw(timelocal);


my $portListen = 80;  #web server port, root required port < 1024
my $rootDir = "/home/neo/Downloads/redscale";  #web server root directory
my @blockPrompt = ("Enter Authorisation Number", "");  #authorisation for insert/remove block


die "redscale error: start as root\n" if ($> != 0);  #root user

my $sockListen = IO::Socket::INET->new(LocalPort => $portListen,  #create web server listening socket
                                       Proto => 'tcp',
                                       Listen => 100,
                                       ReuseAddr => 1) or die "listen socket error\n";

$SIG{INT} = sub { close($sockListen); };  #catch ctrl-c
$SIG{TERM} = sub { close($sockListen); };  #catch kill

chroot($rootDir);  #change root directory, root required
chdir("/");
my @runAs = (1, 1);  #daemon user with no shell access
POSIX::setgid($runAs[1]);  #drop priviledges
POSIX::setuid($runAs[0]);  #gid must be set before uid

my $verRedscale = "0.9";  #version
my $cntID = time();  #unique id for each client connection

#escape javascript chars
sub escapeJS
{
  my $strJS = shift;
  $strJS =~ s/\\/&#92;/g;
  return $strJS;
}

#escape xml chars
sub escapeXML
{
  my $strXML = shift;
  $strXML =~ s/&/&amp;/g;
  $strXML =~ s/'/&apos;/g;
  $strXML =~ s/"/&quot;/g;
  $strXML =~ s/</&lt;/g;
  $strXML =~ s/>/&gt;/g;
  return $strXML;
}

#decode http post
sub decodeHTTP
{
  my $strHTTP = shift;
  $strHTTP =~ s/\+/ /g;
  $strHTTP =~ s/%([A-Fa-f\d]{2})/chr hex $1/eg;
  return $strHTTP;
}

#generate ioc id
sub idIOC
{
  my $md5Hex = md5_hex("$_[0]-$_[1]" . int(rand(1000000)));
  $md5Hex =~ s/(\w{8})(\w{4})(\w{4})(\w{4})(\w{12})/$1-$2-$3-$4-$5/;
  return $md5Hex;
}

#return formatted time now or minus days
sub nowTime
{
  my $nTime = time();
  $nTime -= ($_[0] * 86400);  #minus days
  my ($vYear, $vMon, $vMday, $vHour, $vMin) = (localtime($nTime))[5, 4, 3, 2, 1];
  return sprintf("20%02d-%02d-%02d$_[1]%02d:%02d:00", $vYear - 100, $vMon + 1, $vMday, $vHour, $vMin);
}

#return formatted time in seconds
sub secTime
{
  my ($vYear, $vMon, $vMday, $vHour, $vMin, $vSec) = split(/[- :]+/, $_[0]);
  return timelocal($vSec, $vMin, $vHour, $vMday, $vMon - 1, $vYear);
}

#return date fields
sub getDate
{
  return split(/[-T]+/, $_[0]);
}

sub processHTTP
{
  my $sockClient = shift;
  my $idSock = shift;
  my $strLine;
  my $filePath;
  my ($valYear, $valMon, $valMday);

  my $ioc_id = idIOC($idSock, 0);
  my %ioc_details = ("short_description" => "", "description" => "", "keywords" => "", "authored_by" => "", "authored_date" => nowTime(0, " "));
  my $array_val;
  my $item_cnt = 0;
  my @ioc_links;
  my @item_parent = -1;
  my @ioc_items;
  my $ioc_file;
  my @ioc_list;

  while ($strLine = <$sockClient>)
  {
    if ($strLine =~ /\/(.+\.)(css|js|png|txt) HTTP\//)
    {
      if (-s "$1$2")
      {
        my %connType = ("css" => "text/css", "js" => "text/javascript", "png" => "image/png", "txt" => "application/octet-stream");
        print $sockClient "HTTP/1.1 200 OK\r\nServer: Redscale/$verRedscale\r\nContent-Type: " . $connType{$2} . "\r\nConnection: close\r\n\r\n";
        open(INBIN, "<", "$1$2");
        binmode(INBIN);
        print $sockClient <INBIN>;
        close(INBIN);
        unlink("$1$2") if ($2 eq "txt");
      }
      last;
    }

    elsif ($strLine =~ /\/import_iocs HTTP\//)
    {
      print $sockClient "HTTP/1.1 204 No Content\r\nServer: Redscale/$verRedscale\r\nConnection: close\r\n\r\n";
      while ($strLine = <$sockClient>)
      {
        if ($strLine =~ /^\r\n/)
        {
          $strLine = decodeHTTP(<$sockClient>);
          $strLine =~ s/^iocs=//;
          while ($strLine =~ /(<ioc .+?id="([\w-]+?)".+?<authored_date>(.+?)<\/authored_date>.+?<\/ioc>)/gs)
          {
            ($valYear, $valMon, $valMday) = (getDate($3))[0, 1, 2];
            $filePath = sprintf("%04d/%02d/%02d", $valYear, $valMon, $valMday);
            make_path($filePath, { mode => 0755 });
            $ioc_file = "$filePath/$2.ioc";
            open(OUTIOC, ">", $ioc_file);
            print OUTIOC "<?xml version=\"1.0\" encoding=\"us-ascii\"?>\r\n";
            print OUTIOC $1;
            close(OUTIOC);
          }
          last;
        }
      }
      last;
    }

    elsif ($strLine =~ /\/export_iocs\?id=(\d+) HTTP\//)
    {
      print $sockClient "HTTP/1.1 204 No Content\r\nServer: Redscale/$verRedscale\r\nConnection: close\r\n\r\n";
      my $strID = $1;
      while ($strLine = <$sockClient>)
      {
        if ($strLine =~ /^\r\n/)
        {
          $strLine = decodeHTTP(<$sockClient>);
          $strLine =~ s/^args=\*//;
          @ioc_list = split(/\*/, $strLine);
          last;
        }
      }
      open(OUTIOC, ">", "export_iocs_$strID.txt");
      foreach $ioc_file (@ioc_list)
      {
        open(INIOC, "<", $ioc_file);
        while ($strLine = <INIOC>)
        {
          print OUTIOC "$strLine";
          print OUTIOC "\r\n" if ($strLine !~ /\n$/);
        }
        close(INIOC);
      }
      close(OUTIOC);
      last;
    }

    elsif ($strLine =~ /\/(block_insert|block_remove) HTTP\//)
    {
      print $sockClient "HTTP/1.1 204 No Content\r\nServer: Redscale/$verRedscale\r\nConnection: close\r\n\r\n";
      my $strAction = $1;
      while ($strLine = <$sockClient>)
      {
        if ($strLine =~ /^\r\n/)
        {
          $strLine = decodeHTTP(<$sockClient>);
          $strLine =~ s/^args=//;
          $strLine =~ s/(^"|"$)//g;
          $strLine =~ s/" "/\n/g;
          print "$strAction\n$strLine\n";
          last;
        }
      }
      last;
    }

    elsif ($strLine =~ /\/save_ioc HTTP\//)
    {
      print $sockClient "HTTP/1.1 204 No Content\r\nServer: Redscale/$verRedscale\r\nConnection: close\r\n\r\n";
      while ($strLine = <$sockClient>)
      {
        if ($strLine =~ /^\r\n/)
        {
          ($strLine = <$sockClient>) =~ s/&/``&/g;
          $strLine = decodeHTTP($strLine);
          ($ioc_file, $ioc_id, $ioc_details{"short_description"}, $ioc_details{"description"}, $ioc_details{"keywords"}, $ioc_details{"authored_by"}, $ioc_details{"authored_date"}) = ($strLine =~ /ioc_file=(.+)``&ioc_id=(.+)``&short_description=(.*)``&description=(.*)``&keywords=(.*)``&authored_by=(.*)``&authored_date=(.+?)``&/);
          $ioc_details{"authored_date"} =~ s/ /T/;
          push(@ioc_links, [$1, $2]) while ($strLine =~ /rel=(.*?)``&link=(.+?)``&/g);
          push(@ioc_items, [$1, $2, $3, $4, $5, $6, $7, $8, $9]) while ($strLine =~ /node=(.+?)``&parent=(.+?)``&inid=(.+?)``&item=(.+?)``&item=(.*?)``&item=(.*?)``&item=(.*?)``&item=(.*?)``&item=(.*?)``&/g);
          last;
        }
      }
      open(OUTIOC, ">", $ioc_file);
      print OUTIOC "<?xml version=\"1.0\" encoding=\"us-ascii\"?>\r\n";
      print OUTIOC "<ioc xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" id=\"$ioc_id\" last-modified=\"" . nowTime(0, "T") . "\" xmlns=\"http://schemas.mandiant.com/2010/ioc\">\r\n";
      foreach $array_val ("short_description", "description", "keywords", "authored_by", "authored_date")
      {
        if ($ioc_details{$array_val})
        {
          print OUTIOC "  <$array_val>" . escapeXML($ioc_details{$array_val}) . "</$array_val>\r\n";
        }
        else
        {
          print OUTIOC "  <$array_val />\r\n";
        }
      }
      if (@ioc_links)
      {
        print OUTIOC "  <links>\r\n";
        for $item_cnt (0 .. $#ioc_links)
        {
          print OUTIOC "    <link rel=\"" . escapeXML($ioc_links[$item_cnt][0]) . "\">" . escapeXML($ioc_links[$item_cnt][1]) . "</link>\r\n";
        }
        print OUTIOC "  </links>\r\n";
      }
      else
      {
        print OUTIOC "  <links />\r\n";
      }
      if (@ioc_items)
      {
        my $item_ident = "    ";
        print OUTIOC "  <definition>\r\n";
        for $item_cnt (0 .. $#ioc_items)
        {
          while ((@item_parent > 1) && ($ioc_items[$item_cnt][1] != $item_parent[-1]))
          {
            $item_ident =~ s/  //;
            print OUTIOC "$item_ident</Indicator>\r\n";
            pop(@item_parent);
          }
          if ($ioc_items[$item_cnt][3] =~ /(AND|OR)/)
          {
            push(@item_parent, $ioc_items[$item_cnt][0]);
            print OUTIOC "$item_ident<Indicator operator=\"$ioc_items[$item_cnt][3]\" id=\"$ioc_items[$item_cnt][2]\">\r\n";
            $item_ident .= "  ";
          }
          else
          {
            print OUTIOC "$item_ident<IndicatorItem id=\"$ioc_items[$item_cnt][2]\" condition=\"$ioc_items[$item_cnt][5]\">\r\n";
            print OUTIOC "$item_ident  <Context document=\"$ioc_items[$item_cnt][3]\" search=\"$ioc_items[$item_cnt][3]/$ioc_items[$item_cnt][4]\" type=\"mir\" />\r\n";
            print OUTIOC "$item_ident  <Content type=\"$ioc_items[$item_cnt][6]\">" . escapeXML($ioc_items[$item_cnt][7]) . "</Content>\r\n";
            print OUTIOC "$item_ident  <Comment>" . escapeXML($ioc_items[$item_cnt][8]) . "</Comment>\r\n" if ($ioc_items[$item_cnt][8]);
            print OUTIOC "$item_ident</IndicatorItem>\r\n";
          }
        }
        while (@item_parent > 1)
        {
          $item_ident =~ s/  //;
          print OUTIOC "$item_ident</Indicator>\r\n";
          pop(@item_parent);
        }
        print OUTIOC "  </definition>\r\n";
      }
      else
      {
        print OUTIOC "  <definition />\r\n";
      }
      print OUTIOC "</ioc>";
      close(OUTIOC);
      last;
    }

    elsif ($strLine =~ /\/\?ioc=(.*) HTTP\//)
    {
      if (-s "$1")
      {
        $ioc_file = $1;
        open(INIOC, "<", $ioc_file);
        while ($strLine = <INIOC>)
        {
          if ($strLine =~ /<ioc .+id="([\w-]+)"/)
          {
            $ioc_id = $1;
          }
          elsif ($strLine =~ /<([\w_]+)>(.+)<\/[\w_]+>/)
          {
            $ioc_details{$1} = $2;
          }
          elsif ($strLine =~ /<links>/)
          {
            while ($strLine = <INIOC>)
            {
              last if ($strLine !~ /<link rel="(.*)">(.+)<\/link>/);
              push(@ioc_links, [$1, $2]);
            }
          }
          elsif ($strLine =~ /<Indicator operator="(AND|OR)" id="([\w-]+)">/)
          {
            push(@{ $ioc_items[$item_cnt] }, ($item_parent[-1], $2, $1));
            push(@item_parent, $item_cnt);
            $item_cnt++;
          }
          elsif ($strLine =~ /<\/Indicator>/)
          {
            pop(@item_parent);
          }
          elsif ($strLine =~ /<IndicatorItem id="([\w-]+)" condition="(\w+)">/)
          {
            push(@{ $ioc_items[$item_cnt] }, ($item_parent[-1], $1, $2, "", "", "", "", ""));
            $strLine = <INIOC>;
            if ($strLine =~ /<Context document="\w+" search="(\w+)\/([\w\/]+)" type="\w+" \/>/)
            {
              ($ioc_items[$item_cnt][3], $ioc_items[$item_cnt][4]) = ($1, $2);
              $strLine = <INIOC>;
              if ($strLine =~ /<Content type="(\w+)">(.*)<\/Content>/)
              {
                ($ioc_items[$item_cnt][5], $ioc_items[$item_cnt][6]) = ($1, $2);
                $strLine = <INIOC>;
                $ioc_items[$item_cnt][7] = $1 if ($strLine =~ /<Comment>(.*)<\/Comment>/);
              }
            }
            $item_cnt++;
          }
        }
        $ioc_details{"authored_date"} =~ s/T/ /;
        close(INIOC);
      }
      else
      {
        ($valYear, $valMon, $valMday) = (localtime())[5, 4, 3];
        $filePath = sprintf("20%02d/%02d/%02d", $valYear - 100, $valMon + 1, $valMday);
        make_path($filePath, { mode => 0755 });
        $ioc_file = "$filePath/$ioc_id.ioc";
      }
      print $sockClient "HTTP/1.1 200 OK\r\nServer: Redscale/$verRedscale\r\nContent-Type: text/html\r\nConnection: close\r\n\r\n";
      print $sockClient "<html><head><meta http-equiv='content-type' content='text/html; charset=utf-8' /><link rel='icon' type='image/png' href='img/redscale.png' /><link rel='stylesheet' type='text/css' href='css/redscale.css' /><link rel='stylesheet' type='text/css' href='css/etree-mod.css' /><title>Redscale</title><script type='text/javascript' src='js/iocterms.js'></script><script type='text/javascript' src='js/redscale.js'></script><script type='text/javascript' src='js/etree-mod.js'></script></head><body>";
      print $sockClient "<div class='menu'><a class='menu' href='#' onclick='document.forms[0].submit();'>SAVE</a>";
      print $sockClient "<a class='menu' href='#' onclick='addLink(\"\", \"\");'>ADD LINK</a>";
      print $sockClient "<a class='menu' href='#' onclick='var strId = \"" . substr(idIOC($idSock, 1), 0, 25) . "\"; strId += Date.now().toString(16); addTree(0, false, \"folder\", strId, \"AND\", \"\", \"\", \"\", \"\", \"\"); reloadTree();'>ADD AND/OR</a>";
      print $sockClient "<a class='menu' href='#' onclick='var strId = \"" . substr(idIOC($idSock, 2), 0, 25) . "\"; strId += Date.now().toString(16); addTree(0, false, \"item\", strId, \"\", \"\", \"\", \"\", \"\", \"\"); reloadTree();'>ADD INDICATOR</a>";
      print $sockClient "<a class='menu' href='#' onclick='document.getElementById(\"import_list\").style.display = \"block\";'>IMPORT LIST</a>";
      print $sockClient "<a class='menu' style='color:#BBFFBB; margin-left:80px'>REDSCALE &nbsp; &nbsp; &nbsp; &copy; 2016 Del Castle</a></div><br />";
      print $sockClient "<form action='save_ioc' method='post'>";
      print $sockClient "<input type='hidden' name='ioc_file' value='$ioc_file' />";
      print $sockClient "<input type='hidden' name='ioc_id' value='$ioc_id' />";
      print $sockClient "<table><tr><td class='header'>SUMMARY</th><td><input type='text' name='short_description' size='80' value='" . $ioc_details{"short_description"} . "' /></td></tr>";
      print $sockClient "<tr><td class='header'>DESCRIPTION</th><td><textarea name='description' cols='79' rows='10'>" . $ioc_details{"description"} . "</textarea></td></tr>";
      print $sockClient "<tr><td class='header'>KEYWORDS</th><td><input type='text' name='keywords' size='80' value='" . $ioc_details{"keywords"} . "' /></td></tr>";
      print $sockClient "<tr><td class='header'>AUTHORED BY</th><td><input type='text' name='authored_by' size='80' value='" . $ioc_details{"authored_by"} . "' /></td></tr>";
      print $sockClient "<tr><td class='header'>AUTHORED DATE</th><td><input type='text' name='authored_date' size='80' value='" . $ioc_details{"authored_date"} . "' readonly /></td></tr></table>";
      print $sockClient "<table id='links' style='display:none'><tr><th>RELATIONSHIP</th><th>LINK</th><th></th></tr></table><script>";
      for $item_cnt (0 .. $#ioc_links)
      {
        print $sockClient "addLink(\"" . escapeJS($ioc_links[$item_cnt][0]) . "\", \"" . escapeJS($ioc_links[$item_cnt][1]) . "\");";
      }
      print $sockClient "</script><table id='import_list' style='display:none'><tr><th>LIST</th><th></th></tr>";
      print $sockClient "<tr><td><textarea id='list' cols='83' rows='10'></textarea></td><td><input type='button' value='IMPORT' onclick='importList(\"". substr(idIOC($idSock, 3), 0, 25) . "\");' /><br /><br /><br /><input type='button' value='HIDE' onclick='document.getElementById(\"import_list\").style.display = \"none\";' /></td></tr></table><script>";
      if (@ioc_items)
      {
        for $item_cnt (0 .. $#ioc_items)
        {
          if ($ioc_items[$item_cnt][2] =~ /(AND|OR)/)
          {
            print $sockClient "addTree($ioc_items[$item_cnt][0], true, \"folder\", \"$ioc_items[$item_cnt][1]\", \"$ioc_items[$item_cnt][2]\", \"\", \"\", \"\", \"\", \"\");";
          }
          else
          {
            print $sockClient "addTree($ioc_items[$item_cnt][0], false, \"item\", \"$ioc_items[$item_cnt][1]\", \"$ioc_items[$item_cnt][2]\", \"$ioc_items[$item_cnt][3]\", \"$ioc_items[$item_cnt][4]\", \"$ioc_items[$item_cnt][5]\", \"" . escapeJS($ioc_items[$item_cnt][6]) . "\", \"" . escapeJS($ioc_items[$item_cnt][7]) . "\");";
          }
        }
      }
      else
      {
        print $sockClient "addTree(-1, false, \"folder\", \"" . idIOC($idSock, 4) . "\", \"OR\", \"\", \"\", \"\", \"\", \"\");";
      }
      print $sockClient "writeTree();</script><input type='hidden' name='end' /></form></body></html>";
      last;
    }

    else
    {
      my @search_time = (nowTime(1, " "), "");
      my @search_item = ("All", "");
      my $search_text = "";
      my $found_text;
      my %ioc_vals;
      $strLine = decodeHTTP($strLine);
      @search_time = ($1, $2) if ($strLine =~ /search_time=([- :\d]*),([- :\d]*)&/);
      @search_item = ($1, $2) if ($strLine =~ /search_item=(\w+)\/([\w\/]*)&/);
      $search_text = escapeXML($1) if ($strLine =~ /search_text=(.*) HTTP\//);
      print $sockClient "HTTP/1.1 200 OK\r\nServer: Redscale/$verRedscale\r\nContent-Type: text/html\r\nConnection: close\r\n\r\n";
      print $sockClient "<html><head><meta http-equiv='content-type' content='text/html; charset=utf-8' /><link rel='icon' type='image/png' href='img/redscale.png' /><link rel='stylesheet' type='text/css' href='css/redscale.css' /><title>Redscale</title><script type='text/javascript' src='js/iocterms.js'></script><script type='text/javascript' src='js/redscale.js'></script><script type='text/javascript' src='js/esort.js'></script></head><body>";
      print $sockClient "<div class='menu'><a class='menu' href='?ioc=' target='_blank'>ADD NEW</a>";
      print $sockClient "<a class='menu' href='#' onclick='document.getElementById(\"import_iocs\").style.display = \"block\";'>IMPORT</a>";
      print $sockClient "<a class='menu' href='#' onclick='exportIOCs(" . $idSock . ");'>EXPORT</a>";
      print $sockClient "<a class='menu' href='#' onclick='actionBlock(1, \"$blockPrompt[0]\", \"$blockPrompt[1]\");'>INSERT BLOCK</a>";
      print $sockClient "<a class='menu' href='#' onclick='actionBlock(0, \"$blockPrompt[0]\", \"$blockPrompt[1]\");'>REMOVE BLOCK</a>";
      print $sockClient "<a class='menu' style='color:#BBFFBB; margin-left:80px'>REDSCALE &nbsp; &nbsp; &nbsp; &copy; 2016 Del Castle</a></div><br />";
      print $sockClient "<table><tr><th>START: <input type='text' id='start_time' size='21' maxlength='19' value='$search_time[0]' /><input type='button' value='>' title='Copy To Finish' onclick='document.getElementById(\"finish_time\").value = document.getElementById(\"start_time\").value;' /><input type='button' value='\@' title='Now' onclick='document.getElementById(\"start_time\").value = nowTime(0, false);' /><input type='button' value='0' title='Zero' onclick='document.getElementById(\"start_time\").value = (document.getElementById(\"start_time\").value.search(/00\$/) == -1 ? document.getElementById(\"start_time\").value.replace(/\\d+\$/, \"00\") : (document.getElementById(\"start_time\").value.search(/00:00\$/) == -1 ? document.getElementById(\"start_time\").value.replace(/\\d+:\\d+\$/, \"00:00\") : document.getElementById(\"start_time\").value.replace(/\\d+:\\d+:\\d+\$/, \"00:00:00\")));' /><input type='button' value=' ' title='Clear' onclick='document.getElementById(\"start_time\").value = \"\";' /></th>";
      print $sockClient "<th>FINISH: <input type='text' id='finish_time' size='21' maxlength='19' value='$search_time[1]' /><input type='button' value='<' title='Copy To Start' onclick='document.getElementById(\"start_time\").value = document.getElementById(\"finish_time\").value;' /><input type='button' value='\@' title='Now' onclick='document.getElementById(\"finish_time\").value = nowTime(0, false);' /><input type='button' value='0' title='Zero' onclick='document.getElementById(\"finish_time\").value = (document.getElementById(\"finish_time\").value.search(/00\$/) == -1 ? document.getElementById(\"finish_time\").value.replace(/\\d+\$/, \"00\") : (document.getElementById(\"finish_time\").value.search(/00:00\$/) == -1 ? document.getElementById(\"finish_time\").value.replace(/\\d+:\\d+\$/, \"00:00\") : document.getElementById(\"finish_time\").value.replace(/\\d+:\\d+:\\d+\$/, \"00:00:00\")));' /><input type='button' value=' ' title='Clear' onclick='document.getElementById(\"finish_time\").value = \"\";' /></th></tr>";
      print $sockClient "<tr><th colspan='2'>ITEM: <script>showItems(\"" . $search_item[0] . "\", \"" . $search_item[1] . "\");</script></th></tr>";
      print $sockClient "<tr><th>FIND: <input type='text' id='find_text' size='40' value='$search_text' /></th>";
      print $sockClient "<th><input type='button' value='Search' onclick='location.href = \"?search_time=\" + document.getElementById(\"start_time\").value + \",\" + document.getElementById(\"finish_time\").value + \"&search_item=\" + valOption(\"types\") + \"/\" + valOption(\"fields\") + \"&search_text=\" + encodeURIComponent(document.getElementById(\"find_text\").value);' />&nbsp;&nbsp;&nbsp;";
      print $sockClient "<input type='button' value='Reset' onclick='location.href = \"?\";' /></th></tr></table>";
      print $sockClient "<form action='import_iocs' method='post'>";
      print $sockClient "<table id='import_iocs' style='display:none'><tr><th>IOCS</th><th></th></tr>";
      print $sockClient "<tr><td><textarea name='iocs' cols='83' rows='10'></textarea></td><td><input type='button' value='IMPORT' onclick='document.forms[0].submit(); iocs.value=\"\"; document.getElementById(\"import_iocs\").style.display = \"none\";' /><br /><br /><br /><input type='button' value='HIDE' onclick='document.getElementById(\"import_iocs\").style.display = \"none\";' /></td></tr></table></form>";
      print $sockClient "<table id='iocs' class='esort'><tr><th><input type='checkbox' onchange='setCheck(this.checked);' /></th><th>SUMMARY</th><th>INDICATORS</th><th>KEYWORDS</th><th>AUTHOR</th><th>DATE</th><th></th></tr>";
      @ioc_list = <"*/*/*/*.ioc">;
      foreach $ioc_file (@ioc_list)
      {
        $found_text = 0;
        undef %ioc_details;
        %ioc_details = ("short_description" => "", "description" => "", "keywords" => "", "authored_by" => "", "authored_date" => "");
        undef %ioc_vals;
        open(INIOC, "<", $ioc_file);
        while ($strLine = <INIOC>)
        {
          $found_text = 1 if (index(lc($strLine), lc($search_text)) != -1);
          if ($strLine =~ /<([\w_]+)>(.+)<\/[\w_]+>/)
          {
            $ioc_details{$1} = $2;
          }
          elsif ($strLine =~ /search="([\w\/]+)"/)
          {
            $array_val = $1;
            $strLine = <INIOC>;
            $found_text = 1 if (index(lc($strLine), lc($search_text)) != -1);
            if ($strLine =~ /<Content type="\w+">(.+)<\/Content>/)
            {
              push(@{ $ioc_vals{$array_val} }, "\n$1") if (($search_item[0] eq "All") || ($array_val eq join("/", @search_item)));
            }
          }
        }
        $ioc_details{"authored_date"} =~ s/T/ /;
        close(INIOC);
        if ((($search_time[0] eq "") or (secTime($search_time[0]) <= secTime($ioc_details{"authored_date"}))) and (($search_time[1] eq "") or (secTime($search_time[1]) >= secTime($ioc_details{"authored_date"}))) and (($search_item[0] eq "All") or (exists $ioc_vals{join("/", @search_item)})) and (($search_text eq "") or $found_text))
        {
          print $sockClient "<tr onclick='rowDark(this.style);'><td><input type='checkbox' /><input type='hidden' value='$ioc_file' /></td><td title='" . $ioc_details{"description"} . "'>" . $ioc_details{"short_description"} . "</td><td>";
          foreach $array_val (sort keys %ioc_vals)
          {
            print $sockClient "<div title='$array_val:@{ $ioc_vals{$array_val} }'>$array_val</div>";
          }
          print $sockClient "</td><td>" . $ioc_details{"keywords"} . "</td><td>" . $ioc_details{"authored_by"} . "</td><td>" . $ioc_details{"authored_date"} . "</td><td><a class='action' href='?ioc=$ioc_file' target='_blank'>SHOW</a></td></tr>";
        }
      }
      print $sockClient "</table><script>if (document.getElementById(\"iocs\").rows.length == 1) { document.getElementById(\"iocs\").style.display = \"none\"; document.write(\"<p>NOTHING FOUND!</p>\"); }</script></body></html>";
      last;
    }

  }
  close($sockClient);
}

umask(0);

while (my $sockAccept = $sockListen->accept)
{
  async(\&processHTTP, $sockAccept, ++$cntID)->detach;
}
