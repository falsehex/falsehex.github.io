<?php

include "plugins/cred/sourcefire.cred.php";

$part = explode(";", $file_id);
$file_name .= ".pcap";
exec("wget --no-check-certificate -t 1 -O \"{$file_name}\" \"{$sourcefire_www_host}/external_pcap.cgi?sensor_id={$part[0]}&event_id={$part[1]}&event_sec={$part[2]}\"");

?>
