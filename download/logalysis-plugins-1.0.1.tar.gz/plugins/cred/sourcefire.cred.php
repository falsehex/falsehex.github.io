<?php

$sourcefire_db_host = "127.0.0.1";
$sourcefire_db_user = "logalysis";
$sourcefire_db_pass = "P@55w0rd";
$sourcefire_db_name = "sfsnort";

$sourcefire_www_host = "https://127.0.0.1";

?>
