<html>
<head>
<meta name='copyright' content='2012-2016 Del Castle' />
<meta charset='UTF-8' />
<meta http-equiv='content-type' content='text/html' />
<link rel='stylesheet' type='text/css' href='fx/css/logalysis.css' />

<script type='text/javascript' src='fx/js/logalysis.js'></script>

</head>
<body>

<?php

include "common.php";
session_start();
/*if (isset($_SESSION["las_last_activity"]) && ((time() - $_SESSION["las_last_activity"]) > 3600))
{
  session_unset();
  session_destroy();
} 
$_SESSION["las_last_activity"] = time();*/
if (empty($_SESSION["las_login_user_name"]) || !$_SESSION["las_login_user_admin"]) exit($login_bounce);

$state_id = (isset($_POST["state_id"]) && is_numeric($_POST["state_id"]) ? $_POST["state_id"] : (isset($_GET["state_id"]) && is_numeric($_GET["state_id"]) ? $_GET["state_id"] : 0));

$link = logalysis_db_connect();

if (isset($_POST["state_id"]))
{
  $state_name = $_POST["state_name"];
  $position = $_POST["position"];
  $is_disabled = (isset($_POST["is_disabled"]) ? $_POST["is_disabled"] : "");
  if (is_numeric($position))
  {
    if ($state_name)
    {
      $extra = "";
      if ($state_name != $_POST["old_state_name"])
      {
        $count = db_result($link, "SELECT COUNT(1) FROM states WHERE name = '" . addslashes($state_name) . "'");
        if ($count) $error = "STATE ALREADY EXISTS";
        else if ($state_id) $extra = " name = '" . addslashes($state_name) . "'";
      }      
      if ($state_id)
      {
        if ($position != $_POST["old_position"]) $extra .= ($extra ? "," : "") . " position = {$position}";
        if ($is_disabled != $_POST["old_is_disabled"]) $extra .= ($extra ? "," : "") . " is_disabled = " . ($is_disabled ? "TRUE" : "FALSE");
        if ($extra)
        {
          $sql = "UPDATE states SET{$extra} WHERE state_id = {$state_id}";
          mysqli_query($link, $sql);
          write_audit($link, 0, $_SESSION["las_login_user_id"], 7, $sql);
        }
      }
      else if (!isset($error))
      {
        $sql = "INSERT INTO states VALUES(0, '" . addslashes($state_name) . "', {$position}, " . ($is_disabled ? "TRUE" : "FALSE") . ")";
        mysqli_query($link, $sql);
        $state_id = mysqli_insert_id($link);
        write_audit($link, 0, $_SESSION["las_login_user_id"], 6, $sql);
      }

      if ($state_id) echo "<script type='text/javascript'>parent.frame_settings_list.location.reload();</script>";
    }
    else $error = "ENTER STATE NAME";
  }
  else $error = "ENTER NUMERIC POSITION";
}

echo "<div class='menu'>";
echo "<a class='menu' href='#' onclick='this.style.display = \"none\"; visState(\"ancPw\", 1); document.forms[0].submit();'>SAVE" . ($state_id ? "" : " NEW") . "</a>";
echo "<a id='ancPw' class='menu' style='color:#FF9999; visibility:hidden'>PLEASE WAIT...</a>";
echo "</div><br />";

if (isset($error)) echo "<h5>ERROR - {$error}!</h5>";

echo "<form action='state_show.php' method='POST'>";
echo "<input type='hidden' name='state_id' value='{$state_id}' />";
echo "<table>";
$state = db_fetch_row($link, "SELECT name, position, is_disabled FROM states WHERE state_id = {$state_id}");
echo "<tr><td>Name</td><td><input type='text' name='state_name' size='34' maxlength='32' value='" . (!$state_id && isset($_POST["state_name"]) ? $_POST["state_name"] : $state[0]) . "' /></td></tr>";
echo "<input type='hidden' name='old_state_name' value='{$state[0]}' />";
echo "<tr><td>Position</td><td><input type='text' name='position' size='34' maxlength='10' value='{$state[1]}' /></td></tr>";
echo "<input type='hidden' name='old_position' value='{$state[1]}' />";
echo "<tr><td>Disabled</td><td><input type='checkbox' name='is_disabled' value='on'" . ($state[2] ? " checked='checked'" : "") . " /></td></tr>";
echo "<input type='hidden' name='old_is_disabled' value='" . ($state[2] ? "on" : "") . "' />";
echo "</table>";
echo "</form>";

mysqli_close($link);

?>

</body>
</html>
