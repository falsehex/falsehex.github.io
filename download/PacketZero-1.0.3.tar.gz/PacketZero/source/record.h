/* record.h - 01 Sep 15
   PacketZero - 3D Network Monitor
   Copyright 2006-2015 Del Castle  */

#include <sys/time.h>

#include "common.h"

enum packet_traffic { Traffic_Stop, Traffic_Halt, Traffic_Record, Traffic_Replay };  //packet traffic state

//packet traffic record
struct packet_time
{
  timeval Time;  //time of packet
  packet_info PacketInfo;
};

const size_t PKT_TIME_SIZE = sizeof(packet_time);

//copy packet traffic file from/to
void copyTraffic(const char *ifilename, const char *ofilename);
