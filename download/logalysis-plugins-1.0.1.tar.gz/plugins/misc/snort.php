<?php

function snort_priority($val, $short, $tick)
{
  if (!$val) $val = 3;
  if ($tick) $val += 3;
  switch ($val)
  {
    case 1: case 4: return ($short ? "{$val} H" : "High");
    case 2: case 5: return ($short ? "{$val} M" : "Medium");
    case 3: case 6: return ($short ? "{$val} L" : "Low");
    default: return $val;
  }
}

?>
