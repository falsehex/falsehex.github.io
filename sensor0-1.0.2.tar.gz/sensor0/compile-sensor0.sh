#!/bin/sh
g++ -O2 -c -o obj/llist-s.o source/llist-s.cpp
g++ -O2 -c -o obj/udptrack.o source/udptrack.cpp
g++ -O2 -c -o obj/sensor0.o source/sensor0.cpp
g++ -O2 -o sensor0 obj/llist-s.o obj/udptrack.o obj/sensor0.o -lpcap
rm obj/*
