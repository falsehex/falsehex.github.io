<html>
<head>
<meta name='copyright' content='2012-2016 Del Castle' />
<meta charset='UTF-8' />
<meta http-equiv='content-type' content='text/html' />
<link rel='stylesheet' type='text/css' href='fx/css/logalysis.css' />

<script type='text/javascript' src='fx/js/logalysis.js'></script>

</head>
<body>

<?php

include "common.php";
session_start();
/*if (isset($_SESSION["las_last_activity"]) && ((time() - $_SESSION["las_last_activity"]) > 3600))
{
  session_unset();
  session_destroy();
} 
$_SESSION["las_last_activity"] = time();*/
if (empty($_SESSION["las_login_user_name"])) exit($login_bounce);

$file_name = (isset($_POST["file_name"]) ? $_POST["file_name"] : $_GET["file_name"]);

if (strstr($file_name, "../")) exit(0);
if (isset($_POST["file_name"])) file_put_contents("plugins/edit/{$file_name}", $_POST["contents"]);

echo "<div class='menu'>";
echo "<a class='menu' href='#' onclick='this.style.display = \"none\"; visState(\"ancPw\", 1); document.forms[0].submit();'>SAVE</a>";
echo "<a id='ancPw' class='menu' style='color:#FF9999; visibility:hidden'>PLEASE WAIT...</a>";
echo "</div><br />";

echo "<form action='file_edit.php' method='POST'>";
echo "<input type='hidden' name='file_name' value='{$file_name}' />";
echo "<textarea name='contents' style='height:95%; width:100%'>";
echo file_get_contents("plugins/edit/{$file_name}");
echo "</textarea>";
echo "</form>";

?>

</body>
</html>
