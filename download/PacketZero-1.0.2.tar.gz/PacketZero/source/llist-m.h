/* llist-m.h - 01 Sep 15
   Linked List Multi
   Copyright 2006-2015 Del Castle  */

#ifndef LLIST_H
#define LLIST_H

class LinkedList
{
  private:
    struct Item
    {
      void *Data;
      Item *Next, *Prev;
      Item(void *data, size_t num, Item *prev);
      ~Item();
    } *pFront, *pBack, *pItem[4];
    unsigned int cntItems;
  public:
    LinkedList();
    ~LinkedList();
    unsigned int Items();
    void *Write(unsigned char ptr, void *data, size_t num);
    void Start(unsigned char ptr);
    void End(unsigned char ptr);
    void *Read(unsigned char ptr);
    void Next(unsigned char ptr);
    void Prev(unsigned char ptr);
    void *Find(unsigned int item);
    void Free(unsigned char ptr);
    void Delete(unsigned char ptr);
};

#endif
