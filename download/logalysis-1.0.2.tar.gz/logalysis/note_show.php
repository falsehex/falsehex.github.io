<html>
<head>
<meta name='copyright' content='2012-2016 Del Castle' />
<meta charset='UTF-8' />
<meta http-equiv='content-type' content='text/html' />
<link rel='stylesheet' type='text/css' href='fx/css/logalysis.css' />

<script type='text/javascript' src='fx/js/logalysis.js'></script>

</head>
<body>

<?php

include "common.php";
session_start();
/*if (isset($_SESSION["las_last_activity"]) && ((time() - $_SESSION["las_last_activity"]) > 3600))
{
  session_unset();
  session_destroy();
} 
$_SESSION["las_last_activity"] = time();*/
if (empty($_SESSION["las_login_user_name"])) exit($login_bounce);

$job_id = (isset($_POST["job_id"]) && is_numeric($_POST["job_id"]) ? $_POST["job_id"] : (isset($_GET["job_id"]) && is_numeric($_GET["job_id"]) ? $_GET["job_id"] : 0));
$note_txt = explode(".", (isset($_GET["note_txt"]) ? $_GET["note_txt"] : "."));

if (strstr($note_txt[0], "../") || strstr($note_txt[1], "../")) exit(0);

$link = logalysis_db_connect();

if (isset($_POST["job_id"]) && $job_id)
{
  $note_type = (isset($_POST["note_type"]) ? $_POST["note_type"] : "");
  mysqli_query($link, "INSERT INTO notes VALUE(0, {$job_id}, UTC_TIMESTAMP(), {$_SESSION["las_login_user_id"]}, '" . addslashes($note_type) . "', '" . addslashes($_POST["remarks"]) . "')");
  $note_id = mysqli_insert_id($link);
  if ($note_type == "CHANGE DETAILS") $position = 101;
  else
  {
    $state = db_fetch_row($link, "SELECT name, position + 1 FROM states WHERE state_id = (SELECT state_id FROM jobs WHERE job_id = {$job_id})");
    $position = ($state[0] == $note_type ? $state[1] : 0);
  }
  if ($position > 100)
  {
    if (db_result($link, "SELECT COUNT(1) FROM states WHERE position = {$position}")) $state_id = db_result($link, "SELECT state_id FROM states WHERE position = {$position}");
    else $state_id = 1;
    $sql = "UPDATE jobs SET state_id = {$state_id}, close_time = NULL, close_user_id = 0" . ($position == 101 ? ", comments = CONCAT(comments, '\nLC" . str_pad($note_id, 6, "0", STR_PAD_LEFT) . "')" : "") . " WHERE job_id = {$job_id}";
    mysqli_query($link, $sql);
    write_audit($link, $job_id, $_SESSION["las_login_user_id"], 12, $sql);
  }
  
  echo "<script type='text/javascript'>if (parent.frame_note_list) parent.frame_note_list.location.href = \"note_list.php?job_id={$job_id}\"; else { window.opener.location.reload(); window.close(); }</script>";
}
else $note_id = (isset($_GET["note_id"]) && is_numeric($_GET["note_id"]) ? $_GET["note_id"] : 0);

if (!$note_id)
{
  echo "<div class='menu'>";
  if ($note_txt[0] == "change_details") echo "<a class='menu' onmouseover='visState(\"dvsCt\", 1);'>CHANGE TYPE</a>";
  echo "<a class='menu' href='#' onclick='this.style.display = \"none\"; visState(\"ancPw\", 1); document.forms[0].submit();'>SAVE</a>";
  echo "<a id='ancPw' class='menu' style='color:#FF9999; visibility:hidden'>PLEASE WAIT...</a>";
  echo "</div><br />";
}

echo "<form action='note_show.php' method='POST'>";
echo "<input type='hidden' name='job_id' value='{$job_id}' />";
if ($note_txt[0] && ($note_txt[0] != "note")) echo "<input type='text' name='note_type' size='32' readonly='readonly' value='" . strtoupper(strtr($note_txt[0], "_", " ")) . "' />";
echo "<textarea name='remarks' style='height:90%; width:100%'";
if ($note_id)
{
  echo " readonly='readonly'>";
  if ($note_id == -1)
  {
    $result = mysqli_query($link, "SELECT save_time, save_user_id, note_type, note_id, remarks FROM notes WHERE job_id = {$job_id} ORDER BY save_time");
    while ($note = mysqli_fetch_row($result)) echo "******** {$note[0]} " . get_user_name($link, $note[1]) . " ****************\n" . ($note[2] ? "*** {$note[2]}" . ($note[2] == "CHANGE DETAILS" ? " LC" . str_pad($note[3], 6, "0", STR_PAD_LEFT) : "") . " ***\n" : "") . "{$note[4]}\n\n\n";
    mysqli_free_result($result);
  }
  else
  {
    $result = mysqli_query($link, "SELECT note_type, note_id, remarks FROM notes WHERE note_id = {$note_id}");
    if ($note = mysqli_fetch_row($result)) echo ($note[0] ? "*** {$note[0]}" . ($note[0] == "CHANGE DETAILS" ? " LC" . str_pad($note[1], 6, "0", STR_PAD_LEFT) : "") . " ***\n" : "") . $note[2];
    mysqli_free_result($result);
  } 
}
else echo ">";
if ($note_txt[1]) echo file_get_contents("plugins/note/{$note_txt[0]}.{$note_txt[1]}." . ($note_txt[0] == "change_details" ? "change" : "note") . ".txt");
echo "</textarea>";
echo "</form>";

if ($note_txt[0] == "change_details")
{
  echo "<div id='dvsCt' style='visibility:hidden' onmouseover='visState(\"dvsCt\", 1);' onmouseout='visState(\"dvsCt\", 0);'>";
  echo "<div class='menu' style='width:auto'><a class='menu' style='color:#FFFFFE'>CHANGE TYPE</a></div>";
  $count = 0;
  $note_plugins = scandir("plugins/note");
  foreach ($note_plugins as &$row)
  {
    if (strstr($row, ".change.txt") && !strstr($row, ".change.change.txt"))
    {
      $txt = preg_replace("/^(.+)\.change\.txt$/", "$1", $row);
      $row = preg_replace("/^.+\.(.+)\.change\.txt$/", "$1", $row);
      echo "<div class='menu' style='top:". (++$count * 20) . "px'><a class='menu' href='note_show.php?job_id={$job_id}&note_txt={$txt}'>" . strtoupper(strtr($row, "_", " ")) . "</a></div>";
    }
  }
  echo "</div>";
}

mysqli_close($link);

?>

</body>
</html>
