/* Copyright 2016 Del Castle */

var styTr = null;

function rowDark(sty)
{
  if (styTr) styTr.backgroundColor = "#DBD8BE";
  sty.backgroundColor = "#BFBCA2";
  styTr = sty;
}

function addZero(val)
{
  return (val < 10 ? "0" + val : val);
}

function nowTime(day, sec)
{
  var objDt = new Date();
  if (day) objDt.setDate(objDt.getDate() - day);
  return objDt.getFullYear() + "-"
       + addZero(objDt.getMonth() + 1) + "-"
       + addZero(objDt.getDate()) + " "
       + addZero(objDt.getHours()) + ":"
       + addZero(objDt.getMinutes()) + ":"
       + (sec ? addZero(objDt.getSeconds()) : "00");
}

function setCheck(val)
{
  var aryCk = document.getElementsByTagName("input");
  for (var cnt = 0; cnt < aryCk.length; cnt++)
  {
    if (aryCk[cnt].type == "checkbox") aryCk[cnt].checked = val;
  }
}

function actionBlock(act, ppt, val)
{
  var cntDv;
  var strArgs = "";
  var aryDv;
  var aryCk = document.getElementsByTagName("input");
  for (var cnt = 0; cnt < aryCk.length; cnt++)
  {
    if ((aryCk[cnt].type == "checkbox") && aryCk[cnt].checked)
    {
      aryDv = aryCk[cnt].parentNode.nextSibling.nextSibling.getElementsByTagName("div");
      for (cntDv = 0; cntDv < aryDv.length; cntDv++) strArgs += " \"" + aryDv[cntDv].title.replace(/(\s\n|\n)/g, "\" \"") + "\"";
    }
  }
  if (strArgs)
  {
    var strPt;
    if ((strPt = prompt(ppt, val)) != null)
    {
      strArgs = "\"" + strPt + "\"" + strArgs;
      var objFm = document.createElement("form");
      objFm.setAttribute("action", (act ? "block_insert" : "block_remove"));
      objFm.setAttribute("method", "post");
      var objIn = document.createElement("input");
      objIn.setAttribute("type", "hidden");
      objIn.setAttribute("name", "args");
      objIn.setAttribute("value", strArgs);
      objFm.appendChild(objIn);
      document.body.appendChild(objFm);
      objFm.submit();
    }
  }
  else alert("No Indicators in Selection!");
}

function exportIOCs(id)
{
  var strArgs = "";
  var aryCk = document.getElementsByTagName("input");
  for (var cnt = 0; cnt < aryCk.length; cnt++)
  {
    if ((aryCk[cnt].type == "checkbox") && aryCk[cnt].checked) strArgs += "*" + aryCk[cnt].nextSibling.value;
  }
  if (strArgs)
  {
    var objFm = document.createElement("form");
    objFm.setAttribute("action", "export_iocs?id=" + id);
    objFm.setAttribute("method", "post");
    var objIn = document.createElement("input");
    objIn.setAttribute("type", "hidden");
    objIn.setAttribute("name", "args");
    objIn.setAttribute("value", strArgs);
    objFm.appendChild(objIn);
    document.body.appendChild(objFm);
    objFm.submit();
    setTimeout("location.href = \"export_iocs_" + id + ".txt\"", 5000);
  }
  else alert("None Selected!");
}

function importList(id)
{
  var strId;
  var strList = document.getElementById("list").value.replace(/\s/g, ",").replace(/,,/g, ",");
  var aryList = strList.split(",");
  for (var cnt in aryList)
  {
    strId = id + (Date.now() + cnt).toString(16);
    if (aryList[cnt].match(/@/)) addTree(0, false, "item", strId, "is", "Email", "From", "string", aryList[cnt].replace(/'/, "&apos;"), "");
    else if (aryList[cnt].match(/\//)) addTree(0, false, "item", strId, "is", "UrlHistoryItem", "URL", "string", aryList[cnt].replace(/'/, "&apos;"), "");
    else if (aryList[cnt].match(/[a-z]/i)) addTree(0, false, "item", strId, "is", "DnsEntryItem", "Host", "string", aryList[cnt].replace(/'/, "&apos;"), "");
    else addTree(0, false, "item", strId, "is", "PortItem", "remoteIP", "IP", aryList[cnt].replace(/'/, "&apos;"), "");
  }
  reloadTree();
  document.getElementById("list").value = "";
  document.getElementById("import_list").style.display = "none";
}

function addLink(rel, val)
{
  var objTb = document.getElementById("links");
  objTb.style.display = "block";
  var objTr = objTb.insertRow(-1);
  var objTd = objTr.insertCell(0);
  objTd.innerHTML = "<input type='text' name='rel' size='20' value='" + rel + "' />";
  objTd = objTr.insertCell(1);
  objTd.innerHTML = "<input type='text' name='link' size='60' value='" + val + "' />";
  objTd = objTr.insertCell(2);
  objTd.innerHTML = "<input type='button' value='DELETE' onclick='var objTr = this.parentNode.parentNode; if (confirm(\"Confirm Delete Link?\")) { objTr.parentNode.deleteRow(objTr.rowIndex); if (document.getElementById(\"links\").rows.length == 1) document.getElementById(\"links\").style.display = \"none\"; }' />";
}

function changeItems(obj)
{
  var cnt;
  var cntFields = -1;
  obj.nextSibling.nextSibling.options.length = 0;
  for (cnt = 0; cnt < iocTerms.length; cnt++)
  {
    if (iocTerms[cnt][0] == obj.options[obj.selectedIndex].value)
    {
      cntFields = cnt;
      break;
    }
  }
  if (cntFields != -1)
  {
    var objOp;
    for (cnt = 1; cnt < iocTerms[cntFields].length; cnt++)
    {
      objOp = document.createElement("option");
      objOp.text = iocTerms[cntFields][cnt];
      obj.nextSibling.nextSibling.add(objOp);
    }
  }
}

function showItems(typ, fld)
{
  var cnt;
  var cntFields = -1;
  var strHtml = "<select id='types' onchange='changeItems(this);'><option>All</option>";
  for (cnt = 0; cnt < iocTerms.length; cnt++)
  {
    strHtml += "<option value='" + iocTerms[cnt][0] + "'" + (iocTerms[cnt][0] == typ ? " selected" : "") + ">" + iocTerms[cnt][0].replace("Item", "") + "</option>";
    if (iocTerms[cnt][0] == typ) cntFields = cnt;
  }
  strHtml += "</select>/<select id='fields'>";
  if (cntFields != -1)
  {
    for (cnt = 1; cnt < iocTerms[cntFields].length; cnt++) strHtml += "<option" + (iocTerms[cntFields][cnt] == fld ? " selected" : "") + ">" + iocTerms[cntFields][cnt] + "</option>";
  }
  strHtml += "</select>";
  document.write(strHtml);
}

function valOption(obj)
{
  var objSl = document.getElementById(obj);
  if (objSl.options.length == 0) return "";
  else return objSl.options[objSl.selectedIndex].value;
}
