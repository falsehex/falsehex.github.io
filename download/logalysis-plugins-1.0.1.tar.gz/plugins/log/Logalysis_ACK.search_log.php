<?php

echo "<input type='hidden' name='nosave' value='true' />";
echo "<p>Limit <input type='text' name='limit' size='7' maxlength='5' value='{$limit}' /></p>";
search_time($search[1], $search[2]);
echo "<p>User<br /><input type='text' name='char_1_64' size='26' maxlength='32' value='{$search[8]}' /><br />";
echo "Type<br /><input type='text' name='char_2_64' size='26' maxlength='32' value='{$search[9]}' /><br />";
echo "Alert<br /><input type='text' name='char_3_255' size='26' maxlength='255' value='{$search[10]}' /><br />";
echo "Source<br /><input type='text' name='char_4_255' size='26' maxlength='255' value='{$search[11]}' /></p>";

?>
