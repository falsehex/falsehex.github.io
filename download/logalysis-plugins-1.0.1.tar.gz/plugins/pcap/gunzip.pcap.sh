#!/bin/bash

if [ -f "${1}" ]
then
  if [ ! -d "${1}...dir" ]; then
    mkdir "${1}...dir"
  fi
  tshark -xr "${1}" | uncomp_hex.pl | xxd -r -p > "${1}...dir/gunzip.txt"
  if [ `stat -c %s "${1}...dir/gunzip.txt"` -eq 0 ]
  then
    rm -f "${1}...dir/gunzip.txt"
    if [ `ls -1 "${1}...dir" | wc -l` -eq 0 ]; then
      rm -rf "${1}...dir"
    fi
  fi
fi
