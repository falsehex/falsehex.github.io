<html>
<head>
<meta name='copyright' content='2012-2016 Del Castle' />
<meta charset='UTF-8' />
<meta http-equiv='content-type' content='text/html' />
<link rel='stylesheet' type='text/css' href='fx/css/logalysis.css' />

<script type='text/javascript' src='fx/js/esort.js'></script>

<script type='text/javascript' src='fx/js/logalysis.js'></script>

<?php

include "common.php";
session_start();
/*if (isset($_SESSION["las_last_activity"]) && ((time() - $_SESSION["las_last_activity"]) > 3600))
{
  session_unset();
  session_destroy();
} 
$_SESSION["las_last_activity"] = time();*/
if (empty($_SESSION["las_login_user_name"])) exit("</head><body>{$login_bounce}");
date_default_timezone_set("UTC");

$login_user_id = $_SESSION["las_login_user_id"];
$job_id = (is_numeric($_GET["job_id"]) ? $_GET["job_id"] : 0);
$ref_no = $_GET["ref_no"];
$log_id = (isset($_GET["log_id"]) && is_numeric($_GET["log_id"]) ? $_GET["log_id"] : 0);
$limit = (isset($_GET["limit"]) && is_numeric($_GET["limit"]) ? $_GET["limit"] : 100);
$plugin = (isset($_GET["plugin"]) ? $_GET["plugin"] : "");
$start_time = (isset($_GET["start_time"]) ? $_GET["start_time"] : "");
$finish_time = (isset($_GET["finish_time"]) ? $_GET["finish_time"] : "");
$num_1 = (isset($_GET["num_1"]) && is_numeric($_GET["num_1"]) ? $_GET["num_1"] : "");
$num_2 = (isset($_GET["num_2"]) && is_numeric($_GET["num_2"]) ? $_GET["num_2"] : "");
$num_3 = (isset($_GET["num_3"]) && is_numeric($_GET["num_3"]) ? $_GET["num_3"] : "");
$num_4 = (isset($_GET["num_4"]) && is_numeric($_GET["num_4"]) ? $_GET["num_4"] : "");
$num_5 = (isset($_GET["num_5"]) && is_numeric($_GET["num_5"]) ? $_GET["num_5"] : "");
$char_1_64 = (isset($_GET["char_1_64"]) ? $_GET["char_1_64"] : "");
$char_2_64 = (isset($_GET["char_2_64"]) ? $_GET["char_2_64"] : "");
$char_3_255 = (isset($_GET["char_3_255"]) ? $_GET["char_3_255"] : "");
$char_4_255 = (isset($_GET["char_4_255"]) ? $_GET["char_4_255"] : "");
$char_5_255 = (isset($_GET["char_5_255"]) ? $_GET["char_5_255"] : "");
$char_6_255 = (isset($_GET["char_6_255"]) ? $_GET["char_6_255"] : "");
$protocol = (isset($_GET["protocol"]) ? $_GET["protocol"] : "");
$source_ip = (isset($_GET["source_ip"]) ? $_GET["source_ip"] : "");
$source_port = (isset($_GET["source_port"]) && is_numeric($_GET["source_port"]) ? $_GET["source_port"] : "");
$target_ip = (isset($_GET["target_ip"]) ? $_GET["target_ip"] : "");
$target_port = (isset($_GET["target_port"]) && is_numeric($_GET["target_port"]) ? $_GET["target_port"] : "");
$action = (isset($_GET["action"]) ? $_GET["action"] : "");

if (!$action)
{
  echo "<script type='text/javascript'>";
  echo "function textLog() { alert(\"No Text Conversion For Log Type!\"); }";
  echo "function saveLog() { location.href = \"log_show.php?job_id={$job_id}&ref_no={$ref_no}&limit={$limit}&plugin=" . urlencode($plugin) . "&start_time=" . urlencode($start_time) . "&finish_time=" . urlencode($finish_time) . "&num_1={$num_1}&num_2={$num_2}&num_3={$num_3}&num_4={$num_4}&num_5={$num_5}&char_1_64=" . urlencode($char_1_64) . "&char_2_64=" . urlencode($char_2_64) . "&char_3_255=" . urlencode($char_3_255) . "&char_4_255=" . urlencode($char_4_255) . "&char_5_255=" . urlencode($char_5_255) . "&char_6_255=" . urlencode($char_6_255) . "&protocol=" . urlencode($protocol) . "&source_ip=" . urlencode($source_ip) . "&source_port={$source_port}&target_ip=" . urlencode($target_ip) . "&target_port={$target_port}&action=save\"; }";
  echo "</script>";
}

echo "</head>";
echo "<body>";

if ($action) echo "<script type='text/javascript'>parent.frame_log_list.location.href = \"log_list.php?job_id={$job_id}&ref_no={$ref_no}\";</script>";
else if (!$_SESSION["las_move_log"])
{
  echo "<div class='menu'>";
  if (empty($_GET["nosave"])) echo "<a class='menu' href='#' onclick='textLog();'>TEXT</a>";
  if ($log_id)
  {
    echo "<a class='menu' href='log_show.php?job_id={$job_id}&ref_no={$ref_no}&log_id={$log_id}&action=move'>MOVE</a>";
    echo "<a class='menu' href='#' onclick='if (confirm(\"Confirm Delete!\")) location.href = \"log_show.php?job_id={$job_id}&ref_no={$ref_no}&log_id={$log_id}&action=delete\";'>DELETE</a>";
  }
  else if (empty($_GET["nosave"]))
  {
    echo "<a class='menu' href='#' onclick='this.style.display = \"none\"; visState(\"ancPw\", 1); saveLog();'>SAVE</a>";
    echo "<a id='ancPw' class='menu' style='color:#FF9999; visibility:hidden'>PLEASE WAIT...</a>";
  }
  echo "</div><br />";
}

if (($action == "move") || ($action == "delete")) echo "<script type='text/javascript'>location.href = \"blank.html\";</script>";
else include "plugins/log/{$plugin}." . ($log_id ? "logalysis_log" : "generate_log") . ".php";

if ($action)
{
  $link = logalysis_db_connect();

  if ($action == "move") $_SESSION["las_move_log"] = $log_id;
  else if ($action == "delete")
  {
    mysqli_query($link, "DELETE FROM events WHERE log_id = {$log_id}");
    mysqli_query($link, "DELETE FROM logs WHERE log_id = {$log_id}");
  }
  else if (($action == "save") && $job_id)
  {
    mysqli_query($link, "INSERT INTO logs VALUES(0, {$job_id}, UTC_TIMESTAMP(), {$login_user_id}, '" . addslashes($plugin) . "', '" . addslashes($start_time) . "', '" . addslashes($finish_time) . "', " . ($num_1 == "" ? "NULL" : $num_1) . ", " . ($num_2 == "" ? "NULL" : $num_2) . ", " . ($num_3 == "" ? "NULL" : $num_3) . ", " . ($num_4 == "" ? "NULL" : $num_4) . ", " . ($num_5 == "" ? "NULL" : $num_5) . ", '" . addslashes($char_1_64) . "', '" . addslashes($char_2_64) . "', '" . addslashes($char_3_255) . "', '" . addslashes($char_4_255) . "', '" . addslashes($char_5_255) . "', '" . addslashes($char_6_255) . "', '" . addslashes($protocol) . "', '" . addslashes($source_ip) . "', " . ($source_port == "" ? "NULL" : $source_port) . ", '" . addslashes($target_ip) . "', " . ($target_port == "" ? "NULL" : $target_port) . ")");
    $log_id = mysqli_insert_id($link);
    foreach ($save as &$row) mysqli_query($link, "INSERT INTO events VALUES(0, {$log_id}, '" . addslashes($row[0]) . "', '" . addslashes($row[1]) . "', " . (isset($row[2]) ? $row[2] : "NULL") . ", " . (isset($row[3]) ? $row[3] : "NULL") . ", " . (isset($row[4]) ? $row[4] : "NULL") . ", " . (isset($row[5]) ? $row[5] : "NULL") . ", " . (isset($row[6]) ? $row[6] : "NULL") . ", '" . addslashes($row[7]) . "', '" . addslashes($row[8]) . "', '" . addslashes($row[9]) . "', '" . addslashes($row[10]) . "', '" . addslashes($row[11]) . "', '" . addslashes($row[12]) . "', '" . addslashes($row[13]) . "', '" . addslashes($row[14]) . "', " . (isset($row[15]) ? $row[15] : "NULL") . ", '" . addslashes($row[16]) . "', " . (isset($row[17]) ? $row[17] : "NULL") . ", " . (isset($row[18]) ? $row[18] : "NULL") . ")");
  }

  mysqli_close($link);
}

?>

</body>
</html>
