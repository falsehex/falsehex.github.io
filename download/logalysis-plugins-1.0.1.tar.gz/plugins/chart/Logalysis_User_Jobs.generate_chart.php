<?php

$link = logalysis_db_connect();

if (!isset($shape)) $shape = (isset($_POST["shape"]) ? $_POST["shape"] : "");
if (!isset($show_vals)) $show_vals = (isset($_POST["show_vals"]) ? $_POST["show_vals"] : "");

$table = "<table id='logalysis_user_jobs_{$shape}_table' class='chart'><tr><th class='chart'></th><th class='chart'>User</th><th class='chart'>Jobs</th><th class='chart'>Time</th></tr>";
$count = 0;
$extra = " WHERE job_id != 1";
if ($start_time) $extra .= " AND create_time >= '" . addslashes($start_time) . "'";
if ($finish_time) $extra .= " AND create_time <= '" . addslashes($finish_time) . "'";
$result = mysqli_query($link, "SELECT create_user_id, COUNT(1), SUM(spent) FROM jobs{$extra} GROUP BY create_user_id ORDER BY COUNT(1) DESC");
while ($row = mysqli_fetch_row($result))
{
  $actual = ($row[0] == -1 ? $system : db_result($link, "SELECT actual FROM users WHERE user_id = {$row[0]}"));
  $row[0] = ($actual ? $actual : db_result($link, "SELECT name FROM users WHERE user_id = {$row[0]}"));
  $row[2] = date("z\D G\H i\M", $row[2]);
  $table .= "<tr><td class='chart'>" . ++$count . "</td>";
  foreach ($row as &$cell) $table .= "<td class='chart'>{$cell}</td>";
  $table .= "</tr>";
}
mysqli_free_result($result);
$table .= "</table>";
if ($count)
{
  if (empty($nohdr)) echo "<h4>LOGALYSIS USER JOBS<br />" . ($start_time ? date("d-m-Y H:i:s", strtotime($start_time)) . " -" : "") . ($finish_time ? "- " . date("d-m-Y H:i:s", strtotime($finish_time)) : "") . "</h4>";
  if (empty($nogfx)) echo "<canvas id='logalysis_user_jobs_{$shape}_canvas' width='640' height='320' ondblclick='window.open(this.toDataURL());'></canvas>";
  echo $table;

  if (empty($nogfx)) echo "<script type='text/javascript'>{$shape}Chart(\"logalysis_user_jobs_{$shape}\", 0, 2" . ($shape == "vbar" ? ", \"{$show_vals}\"" : "") . ");</script>";
}
else echo "<h5>NO EVENTS FOUND!</h5>";

mysqli_close($link);

?>
