/* common.h - 01 Sep 15
   PacketZero - 3D Network Monitor
   Copyright 2006-2015 Del Castle  */

#include <netinet/in.h>

//packet info
#pragma pack(1)
struct packet_info
{  //1st members used with memcmp
  in_addr SrcIP, DstIP;
  unsigned short SrcPort, DstPort;
  unsigned char Sensor, Protocol;
};

//packet extra info
#pragma pack(1)
struct packet_xtra
{
  char Id;
  bool Service;
  unsigned char SrcMAC[6];
  unsigned int Bytes;
  packet_info PacketInfo;
};

//DNS info
#pragma pack(1)
struct packet_dns
{
  char Id, Hostname[256];
  in_addr HostIP;
};

const size_t PKT_INFO_SIZE = sizeof(packet_info), PKT_XTRA_SIZE = sizeof(packet_xtra), PKT_DNS_SIZE = sizeof(packet_dns);
