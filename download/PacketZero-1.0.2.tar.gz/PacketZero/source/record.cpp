/* record.cpp - 01 Sep 15
   PacketZero - 3D Network Monitor
   Copyright 2006-2015 Del Castle  */

#include <stdio.h>
#include <string.h>

#include "record.h"

//copy packet traffic file from/to
void copyTraffic(const char *ifilename, const char *ofilename)
{
  FILE *fileIn, *fileOut;
  if ((fileIn = fopen(ifilename, "rb")))
  {
    char strId[5];
    if (fgets(strId, 5, fileIn))
    {
      if (!strcmp(strId, "0PT0"))
      {
        if ((fileOut = fopen(ofilename, "wb")))
        {
          packet_time oPacket;
          fputs("0PT0", fileOut);
          while (fread(&oPacket, PKT_TIME_SIZE, 1, fileIn) == 1)
          {
            if (fwrite(&oPacket, PKT_TIME_SIZE, 1, fileOut) != 1) break;
          }
          fclose(fileOut);
        }
      }
    }
    fclose(fileIn);
  }
}
