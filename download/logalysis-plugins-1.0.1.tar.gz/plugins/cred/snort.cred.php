<?php

$snort_db_host = "localhost";
$snort_db_user = "snort";
$snort_db_pass = "snort";
$snort_db_name = "snort";

$snort_www_host = "http://127.0.0.1";

?>
