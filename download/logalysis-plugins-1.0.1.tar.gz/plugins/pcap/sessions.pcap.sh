#!/bin/bash

if [ -f "${1}" ]
then
  SESSIONS=`tshark -r "${1}" -nqz conv,tcp | grep -P "^\d" | wc -l`
  if [ $SESSIONS -gt 1 ]
  then
    if [ ! -d "${1}...dir" ]; then
      mkdir "${1}...dir"
    fi
    tshark -r "${1}" -nqz conv,tcp | grep -P "^\d" | while read LINE
    do
      CONV=`echo $LINE | cut -d " " -f 1,3 | tr : " "`
      S_IP=`echo $CONV | cut -d " " -f 1`
      S_PT=`echo $CONV | cut -d " " -f 2`
      T_IP=`echo $CONV | cut -d " " -f 3`
      T_PT=`echo $CONV | cut -d " " -f 4`
      FILTER="ip.addr eq ${S_IP} and ip.addr eq ${T_IP} and tcp.port eq ${S_PT} and tcp.port eq ${T_PT}"
      PCAP="${1}...dir/${S_IP}:${S_PT}--${T_IP}:${T_PT}.pcap"
      tshark -r "${1}" -R "${FILTER}" -w "${PCAP}"
      if [ `stat -c %s "${PCAP}"` -eq 0 ]; then
        rm -f "${PCAP}"
      else
        echo -n "CREATED:  " > "${PCAP}...info"
        date -u +"%F %T" >> "${PCAP}...info"
        echo -n "EVENT:    " >> "${PCAP}...info"
        DATE=`tshark -r "${PCAP}" -c 1 -t e | awk '{print $2}' | awk -F "." '{print $1}'`
        date -u -d "1970-01-01 ${DATE} sec" +"%F %T" >> "${PCAP}...info"
        echo "IP 1:     ${S_IP}" >> "${PCAP}...info"
        echo "PORT 1:   ${S_PT}" >> "${PCAP}...info"
        echo "IP 2:     ${T_IP}" >> "${PCAP}...info"
        echo -e "PORT 2:   ${T_PT}\n" >> "${PCAP}...info"
        sh $0 "${PCAP}"
      fi
    done
  else
    if [ $SESSIONS -eq 1 ]
    then
      if [ ! -d "${1}...dir" ]; then
        mkdir "${1}...dir"
      fi
      tcpflow -Cr "${1}" > "${1}...dir/session.txt"
      if [ `stat -c %s "${1}...dir/session.txt"` -eq 0 ]
      then
        rm -f "${1}...dir/session.txt"
        if [ `ls -1 "${1}...dir" | wc -l` -eq 0 ]; then
          rm -rf "${1}...dir"
        fi
      fi
    fi
  fi
fi
