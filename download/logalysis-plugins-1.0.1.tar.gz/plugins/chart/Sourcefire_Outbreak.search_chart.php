<?php

search_time($start_time, $finish_time);
echo "<p>GID:SID <input type='text' name='gid' size='4' maxlength='10' value='1' />:<input type='text' name='sid' size='10' maxlength='10' /></p>";
echo "<p>Plot <select name='plot'>";
echo "<option value='ip_src'>Source IP</option>";
echo "<option value='ip_dst'>Target IP</option>";
echo "</select></p>";

?>
