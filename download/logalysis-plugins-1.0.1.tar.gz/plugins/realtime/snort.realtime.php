<?php

include "plugins/misc/snort.php";
include "plugins/cred/snort.cred.php";

$link = mysqli_connect($snort_db_host, $snort_db_user, $snort_db_pass, $snort_db_name);
if ($link)
{
  if ($ackn == "snort")
  {
    $part = explode(";", $_GET["file_id"]);
    mysqli_query($link, "UPDATE iphdr SET ip_tos = {$part[3]} WHERE ip_tos = {$part[2]} AND sid = {$part[0]} AND cid = {$part[1]}");
    if (mysqli_affected_rows($link)) file_put_contents("/var/log/logalysis/ack.log", time() . " \"{$_SESSION["las_login_user_name"]}\" " . ($part[3] == 255 ? "ACK" : ($part[3] == 254 ? "CHK" : "UCK")) . " \"SNORT\" \"{$part[4]}\" \"{$part[5]}\" {$part[6]} {$part[7]}\n", FILE_APPEND);
  }

  if (!$ackn)
  {
    $result = mysqli_query($link, "SELECT * FROM event WHERE (sid, cid) IN (SELECT sid, cid FROM iphdr WHERE ip_tos != 255) ORDER BY timestamp DESC LIMIT 20");  //sid, cid, signature, timestamp
    while ($row = mysqli_fetch_row($result))
    {
      $tos = db_result($link, "SELECT ip_tos FROM iphdr WHERE sid = {$row[0]} AND cid = {$row[1]}");
      $priority = snort_priority(db_result($link, "SELECT sig_priority FROM signature WHERE sig_id = {$row[2]}"), TRUE, ($tos == 254));
      $sensor = "{$row[0]}:" . db_result($link, "SELECT hostname FROM sensor WHERE sid = {$row[0]}");
      $label = db_result($link, "SELECT sig_name FROM signature WHERE sig_id = {$row[2]}");
      $gid = db_result($link, "SELECT sig_gid FROM signature WHERE sig_id = {$row[2]}");
      $sid = db_result($link, "SELECT sig_sid FROM signature WHERE sig_id = {$row[2]}");
      $class = db_result($link, "SELECT sig_class_name FROM sig_class WHERE sig_class_id = (SELECT sig_class_id FROM signature WHERE sig_id = {$row[2]})");
      $proto = db_result($link, "SELECT ip_proto FROM iphdr WHERE sid = {$row[0]} AND cid = {$row[1]}");
      $srcip = db_result($link, "SELECT INET_NTOA(ip_src) FROM iphdr WHERE sid = {$row[0]} AND cid = {$row[1]}");
      $dstip = db_result($link, "SELECT INET_NTOA(ip_dst) FROM iphdr WHERE sid = {$row[0]} AND cid = {$row[1]}");
      if ($proto == 6)  //TCP
      {
        $srcpt = db_result($link, "SELECT tcp_sport FROM tcphdr WHERE sid = {$row[0]} AND cid = {$row[1]}");
        $dstpt = db_result($link, "SELECT tcp_dport FROM tcphdr WHERE sid = {$row[0]} AND cid = {$row[1]}");
      }
      else if ($proto == 17)  //UDP
      {
        $srcpt = db_result($link, "SELECT udp_sport FROM udphdr WHERE sid = {$row[0]} AND cid = {$row[1]}");
        $dstpt = db_result($link, "SELECT udp_dport FROM udphdr WHERE sid = {$row[0]} AND cid = {$row[1]}");
      }
      else
      {
        $srcpt = NULL;
        $dstpt = NULL;
      }
      $data = db_result($link, "SELECT COUNT(1) FROM data WHERE sid = {$row[0]} AND cid = {$row[1]}");
      $data = ($data ? "<a class='action' href='pcap_get.php?plugin=Snort&file_id={$row[0]};{$row[1]};{$proto};{$srcpt};{$dstpt}'>PCAP</a> <a class='action' href='file_layout.php?job_id=1&ref_no=SCRATCHPAD&search=Snort;{$row[3]};{$row[3]};{$srcip};{$srcpt};{$dstip};{$dstpt}&file_id={$row[0]};{$row[1]};{$proto};{$srcpt};{$dstpt}' target='frame_show'>FILE</a>" : "");
      $url = "realtime_show.php?ackn=snort&file_id={$row[0]};{$row[1]};{$tos}";
      echo "<tr onclick='txtBold(this.style);'>";
      echo "<td style='background:" . priority_color($priority) . "'><a class='action' href='javascript:void(0);' ondblclick='if (ackAlert(\"{$url};" . ($tos == 254 ? 0 : 254) . ";{$gid}:{$sid};{$srcip};" . strtotime($row[3]) . ";\" + cntRt)) setPriority(this);'>{$priority}</a></td>";
      echo "<td>{$row[3]}</td>";
      echo "<td>Snort</td>";
      echo "<td title='Class: {$class}\nProto: " . protocol_name($proto) . "\nSrc: {$srcip}:{$srcpt}\nDst: {$dstip}:{$dstpt}'>{$label} " . (($gid == 1) || ($gid == 3) ? "<a class='action' href='javascript:popUp(\"{$snort_www_host}/snort_rule.php?sid={$sid}\");'>{$gid}:{$sid}</a>" : "{$gid}:{$sid}") . "</td>";
      echo "<td><a class='action' href='javascript:popUp(\"host_show.php?host_ip={$srcip}\");'>{$srcip}</a></td>";
      echo "<td>1</td>";
      echo "<td><a class='action' href='javascript:void(0);' ondblclick='if (ackAlert(\"{$url};255;{$gid}:{$sid};{$srcip};" . strtotime($row[3]) . ";\" + cntRt)) this.parentNode.parentNode.style.display = \"none\";'>ACK</a> {$data} ";
      echo "<a class='action' href='javascript:void(0);' ondblclick='location.href = \"details_show.php?details=\" + cntRt + \"" . urlencode(";0;1;4;0;{$sensor};Snort Alert: " . strtr($label, "'", "\"") . ";GID/SID: {$gid}:{$sid}\nClassification: {$class};;;;;{$row[3]};{$proto};{$srcip};{$srcpt};{$dstip};{$dstpt}") . "\"'>JOB</a></td></tr>";
      $count++;
    }
    $total = db_result($link, "SELECT COUNT(1) FROM event WHERE (sid, cid) IN (SELECT sid, cid FROM iphdr WHERE ip_tos < 254)");
    if ($total > 50) echo "<tr><td style='background:red'>0 E</td><td></td><td>Snort</td><td>SNORT ALERTS > 50</td><td></td><td>{$total}</td><td></td></tr>";
  }

  mysqli_close($link);
}
else echo "<tr><td style='background:red'>0 E</td><td></td><td>Snort</td><td>ERROR: MYSQL DB {$snort_db_name} CONNECT FAILED</td><td></td><td></td><td></td></tr>";

?>
