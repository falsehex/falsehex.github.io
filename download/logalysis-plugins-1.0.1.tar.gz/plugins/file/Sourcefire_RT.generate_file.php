<?php

include "plugins/cred/sourcefire.cred.php";

$link = mysqli_connect($sourcefire_db_host, $sourcefire_db_user, $sourcefire_db_pass, $sourcefire_db_name);
if (!$link) die("Error: mysql db {$sourcefire_db_name} connect failed");

$count = 0;
$pcap_files = "";
$part = explode(";", $file_id);
$result = mysqli_query($link, "SELECT sensor_id, event_id, tv_sec FROM event WHERE reviewed = {$part[4]} AND sig_gen = {$part[0]} AND sig_id = {$part[1]} AND ip_src = {$part[2]} AND tv_sec <= {$part[3]}");
while ($row = mysqli_fetch_row($result))
{
  $pcap_name = "{$file_name}_" . ++$count . ".pcap";
  exec("wget --no-check-certificate -t 1 -O \"{$pcap_name}\" \"{$sourcefire_www_host}/external_pcap.cgi?sensor_id={$row[0]}&event_id={$row[1]}&event_sec={$row[2]}\"");
  if (file_exists($pcap_name)) $pcap_files .= "\"{$pcap_name}\" ";
}
mysqli_free_result($result);
$file_name .= ".pcap";
exec("mergecap -w \"{$file_name}\" {$pcap_files}");
exec("rm -f {$pcap_files}");

mysqli_close($link);

?>
