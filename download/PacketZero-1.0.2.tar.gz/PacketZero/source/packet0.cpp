/* packet0.cpp - 26 May 16
   PacketZero - 3D Network Monitor
   Copyright 2006-2016 Del Castle  */

#include <arpa/inet.h>
#include <fcntl.h>
#ifdef __APPLE__
#include <OpenGL/gl.h>
#else
#include <GL/gl.h>
#endif
#include <pthread.h>
#include <SDL2/SDL.h>
#include <signal.h>
#include <syslog.h>
#include <unistd.h>

#include "glue.h"
#include "objects.h"
#include "misc.h"  //last or crash

bool goRun = true, canAnimate = true, goRefresh, showOSD;
int mouseLeft = 0, mouseMiddle = 0, mouseX = 0, mouseY = 0, boxX = 0, boxY = 0, GLueId[6] = {0, 0, 0, 0, 0, 0};  //2D GUI result identification
char strOSD[80], strHost[570];
view_spot homeView[2] = {{0.0, 75.0, -360.0, 180.0, 0.0}, {-360.0, 75.0, 0.0, 90.0, 0.0}};  //default views
obj_prefs objPrefs = {"0PF0", false, false, false, false, false, false, true, true, false, false, 0, 0, 0, 6333, 0, 0, 800, 600, -1, "", {"", "", "", ""}
  , "sudo sensor0", "", "1", "sudo killall sensor0", Text_Both, Label_Off, Active_Alert, {homeView[0], homeView[0], homeView[0], homeView[0], homeView[0]}};  //preferences
Objects *objLL;
GLue *gui2D;  //2D GUI
SDL_Window *SDLWindow;
SDL_Cursor *SDLCursor_ARROW, *SDLCursor_IBEAM, *SDLCursor_CROSSHAIR, *SDLCursor_SIZENWSE, *SDLCursor_SIZEWE, *SDLCursor_SIZENS, *SDLCursor_HAND;

FILE *fileTraffic;  //packet traffic record file
unsigned long long timeOffset = 0;  //packet traffic time offset
packet_traffic packetTraffic = Traffic_Stop;  //packet traffic state
packet_time replayPacket;  //packet traffic replay packet

//prototypes
void stopRun(int sig);
void draw2D();
void displayGL(bool animate, bool second);
void resizeGL(int w, int h);
void showWait();
void messageBox(const char *title, const char *message);
void updateOSD();
void processButton(int val, unsigned short mods);
void keyboardGL(int key);
void processMenu(int item);
void buttonGL(unsigned char button, unsigned char down);
void wheelGL(int y);
void motionGL(int x, int y);
void loadPrefs();
void savePrefs();
void *processPacket(void *arg);

//close application
void stopRun(int sig)
{
  syslog(LOG_INFO, "sig %d - stopping...\n", sig);
  if (sig) goRun = false;
}

//draw 2D objects
void draw2D()
{
  glDisable(GL_DEPTH_TEST);
  glMatrixMode(GL_PROJECTION);
  glPushMatrix();
  glLoadIdentity();
  glOrtho(0.0, objPrefs.WinWidth, 0.0, objPrefs.WinHeight, -1.0, 1.0);
  glMatrixMode(GL_MODELVIEW);
  glPushMatrix();
  glLoadIdentity();
  glTranslatef(0.375, 0.375, 0.0);  //rasterisation fix
  if (objPrefs.OSD && showOSD)
  {
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE);
    glColor3ub((objPrefs.Anomaly ? 50 : 30), (objPrefs.Anomaly ? 0 : 30), (objPrefs.Anomaly ? 0 : 30));
    glRecti(4, objPrefs.WinHeight - 4, objPrefs.WinWidth - 4, objPrefs.WinHeight - (fontHeight() + 14));  //4 + 5 + 5
    glDisable(GL_BLEND);
    glColor3ub((objPrefs.Anomaly ? clrRedBright[0] : clrGreyDull[0]), (objPrefs.Anomaly ? clrRedBright[1] : clrGreyDull[1]), (objPrefs.Anomaly ? clrRedBright[2] : clrGreyDull[2]));
    glBegin(GL_LINE_LOOP);
      glVertex2i(4, objPrefs.WinHeight - 4);
      glVertex2i(objPrefs.WinWidth - 4, objPrefs.WinHeight - 4);
      glVertex2i(objPrefs.WinWidth - 4, objPrefs.WinHeight - (fontHeight() + 14));
      glVertex2i(4, objPrefs.WinHeight - (fontHeight() + 14));
    glEnd();
    glColor3ub(clrWhite[0], clrWhite[1], clrWhite[2]);
    glRasterPos2i(10, objPrefs.WinHeight - (fontHeight() + 9));  //4 + 5
    drawString((const unsigned char *)(canAnimate ? strOSD : "PAUSED"));
  }
  if (objLL->SelectedHost)  //draw selected host info
  {
    glColor3ub(clrWhite[0], clrWhite[1], clrWhite[2]);
    glRasterPos2i(10, objPrefs.WinHeight - (objPrefs.OSD && showOSD ? (fontHeight() * 2) + 24 : fontHeight() + 10));  //4 + 5 + 5 + 10
    drawString((const unsigned char *)strHost);
  }
  if (packetTraffic > Traffic_Halt)  //draw packet traffic record/replay status
  {
    time_t timeDisplay = time(0) - (time_t)(timeOffset / 1000);
    char strBuffer[25];
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE);
    glColor3ub(30, 30, 30);
    glRecti(4, fontHeight() + 14, objPrefs.WinWidth - 4, 4);
    glDisable(GL_BLEND);
    glColor3ub(100, 100, 100);
    glBegin(GL_LINE_LOOP);
      glVertex2i(4, fontHeight() + 14);
      glVertex2i(objPrefs.WinWidth - 4, fontHeight() + 14);
      glVertex2i(objPrefs.WinWidth - 4, 4);
      glVertex2i(4, 4);
    glEnd();
    if (packetTraffic == Traffic_Record)
    {
      glColor3ub(clrRed[0], clrRed[1], clrRed[2]);
      if (timeOffset) strftime(strBuffer, 17, "REC %j %H:%M:%S", gmtime(&timeDisplay));
      else strncpy(strBuffer, "REC", 4);
    }
    else
    {
      glColor3ub(clrGreen[0], clrGreen[1], clrGreen[2]);
      strftime(strBuffer, 25, "REPLAY %d-%m-%y %H:%M:%S", localtime(&timeDisplay));
    }
    glRasterPos2i(10, 9);
    drawString((const unsigned char *)strBuffer);
  }
  if (objLL->LinkHost)
  {
    glColor3ub(clrWhite[0], clrWhite[1], clrWhite[2]);
    glRasterPos2i(10, fontHeight() + 24);
    drawString((const unsigned char *)"Link Line");
  }
  if (gui2D->On())  //draw 2D GUI
  {
    int valSelected = gui2D->Draw();
    if (mouseLeft) valSelected = mouseLeft;
    switch (valSelected)
    {
      case GLUE_TITLE_BAR: case GLUE_BAR_RIGHT: case GLUE_BAR_BOTTOM: SDL_SetCursor(SDLCursor_HAND); break;
      case GLUE_RESIZE: SDL_SetCursor(SDLCursor_SIZENWSE); break;
      case GLUE_RESIZE_RIGHT: SDL_SetCursor(SDLCursor_SIZEWE); break;
      case GLUE_RESIZE_BOTTOM: SDL_SetCursor(SDLCursor_SIZENS); break;
      case GLUE_INPUT_TEXT: SDL_SetCursor(SDLCursor_IBEAM); break;
      default: SDL_SetCursor(SDLCursor_ARROW);
    }
  }
  else if (mouseLeft)  //draw selection box
  {
    if ((boxX - mouseX) && (boxY - (objPrefs.WinHeight - mouseY))) SDL_SetCursor(SDLCursor_CROSSHAIR);
    glColor3ub(clrGreyBright[0], clrGreyBright[1], clrGreyBright[2]);
    glBegin(GL_LINE_LOOP);
      glVertex2i(boxX, boxY);
      glVertex2i(mouseX, boxY);
      glVertex2i(mouseX, objPrefs.WinHeight - mouseY);
      glVertex2i(boxX, objPrefs.WinHeight - mouseY);
    glEnd();
  }
  else SDL_SetCursor(SDLCursor_ARROW);
  glMatrixMode(GL_PROJECTION);
  glPopMatrix();
  glMatrixMode(GL_MODELVIEW);
  glPopMatrix();
  glEnable(GL_DEPTH_TEST);
}

//draw graphics
void displayGL(bool animate, bool second)
{
  goRefresh = false;
  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
  glLoadIdentity();
  glRotated(objPrefs.ViewSpot[0].AngleY, 1.0, 0.0, 0.0);
  glRotated(objPrefs.ViewSpot[0].AngleX, 0.0, 1.0, 0.0);
  glTranslated(-objPrefs.ViewSpot[0].X, -objPrefs.ViewSpot[0].Y, -objPrefs.ViewSpot[0].Z);
  objLL->Draw(animate, second, &objPrefs);
  draw2D();
  SDL_GL_SwapWindow(SDLWindow);
}

//window resize event
void resizeGL(int w, int h)
{
  objPrefs.WinWidth = (w < 100 ? 100 : w);
  objPrefs.WinHeight = (h < 100 ? 100 : h);
  if ((w < 100) || (h < 100)) SDL_SetWindowSize(SDLWindow, objPrefs.WinWidth, objPrefs.WinHeight);
  double clipPlane = CLIP_TOP * ((double)objPrefs.WinWidth / (double)objPrefs.WinHeight);
  showOSD = ((objPrefs.WinWidth >= 200) && (objPrefs.WinHeight >= 200));  //don't draw OSD if window smaller than 200x200
  glViewport(0, 0, objPrefs.WinWidth, objPrefs.WinHeight);
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  glFrustum(-clipPlane, clipPlane, -CLIP_TOP, CLIP_TOP, 1.0, CLIP_FAR);
  glMatrixMode(GL_MODELVIEW);
  gui2D->ScreenSize(objPrefs.WinWidth, objPrefs.WinHeight);
  goRefresh = true;
}

//2D GUI window "please wait"
void showWait()
{
  gui2D->CreateWindow(-1, -1, 18, 10, "PROCESSING", false);
  gui2D->AddLabel(2, 2, "Please Wait...");
  displayGL(false, false);
}

//show message box
void messageBox(const char *title, const char *message)
{
  gui2D->CreateWindow(-1, -1, lenStr(message) + 4, 18, title);
  gui2D->AddLabel(2, 2, message);
  gui2D->AddButton(2, 8, GLUE_CLOSE, "OK", false, true);  //no align as dynamic width
  displayGL(false, false);
}

//update OSD text
void updateOSD()
{
  strncpy(strOSD, "Sensor: ", 9);
  if (objPrefs.ShowSensor) sprintf(strOSD, "%s%hhu", strOSD, objPrefs.ShowSensor);  //3
  else strncat(strOSD, "All", 3);
  strncat(strOSD, "\tProtocol: ", 11);
  if (objPrefs.ShowProtocol)
  {
    char strBuffer[5];
    sprintf(strOSD, "%s%s", strOSD, decodeProtocol(objPrefs.ShowProtocol, strBuffer));  //4
  }
  else strncat(strOSD, "All", 3);
  strncat(strOSD, "\tPort: ", 7);
  if (objPrefs.ShowPort) sprintf(strOSD, "%s%hu", strOSD, objPrefs.ShowPort);  //5
  else strncat(strOSD, "All", 3);
  sprintf(strOSD, "%s\t%s: %s\tActive: %s\t", strOSD, txtText[objPrefs.LabelText], (objPrefs.HostActive == Active_Label ? "Active" : txtLabel[objPrefs.HostLabel])
    , txtActive[objPrefs.HostActive]);  //36
  if (objPrefs.AnomDetect) strncat(strOSD, "A", 1);
  if (objPrefs.Broadcasts) strncat(strOSD, "B", 1);
  else if (objPrefs.DstHosts) strncat(strOSD, "D", 1);
  if (objPrefs.FastPackets) strncat(strOSD, "F", 1);
  if (objPrefs.NewLinks) strncat(strOSD, "L", 1);
  if (objPrefs.NewPackets) strncat(strOSD, "P", 1);
}

//process 2D GUI button selected
void processButton(int val, unsigned short mods)
{
  if (val == GLUE_CLOSE)
  {
    gui2D->Close(false);  //close focused 2D GUI window
    return;
  }
  unsigned char cntService;
  char strBuffer[256], strPath1[4096], strPath2[4096], *pInput1, *pInput2, *pInput3, *pInput4, *pInput5;
  int resultId = GLueId[0] % OBJ_ID;  //result identification
  switch (resultId)
  {
    case GUI_0NL_OPEN: case GUI_0NL_SAVE:
      pInput1 = gui2D->GetInputText(GLueId[0] / OBJ_ID);
      if (*pInput1 != '\0')
      {
        if (val == GLUE_CUSTOM)
        {
          if (strstr(pInput1, ".0nl"))
          {
            remove(getPath(pInput1, strPath1));
            createFileList(getPath("tmp_packet0", strPath1), getPath("", strPath2), ".0nl");
          }
        }
        else
        {
          showWait();
          if (resultId == GUI_0NL_OPEN) objLL->LoadNet(getPath(pInput1, strPath1));
          else
          {
            addExtension(pInput1, ".0nl");
            objLL->SaveNet(getPath(pInput1, strPath1));
          }
          gui2D->Close();  //close all 2D GUI windows
        }
      }
      else messageBox("ERROR", "Enter File Name!");
      break;
    case GUI_0PT_OPEN: case GUI_0PT_SAVE:
      pInput1 = gui2D->GetInputText(GLueId[0] / OBJ_ID);
      if (*pInput1 != '\0')
      {
        if (val == GLUE_CUSTOM)
        {
          if (strstr(pInput1, ".0pt"))
          {
            remove(getPath(pInput1, strPath1));
            createFileList(getPath("tmp_packet0", strPath1), getPath("", strPath2), ".0pt");
          }
        }
        else
        {
          showWait();
          if (packetTraffic == Traffic_Record) packetTraffic = Traffic_Halt;
          else if (packetTraffic == Traffic_Replay)
          {
            objLL->DestroyPackets();
            packetTraffic = Traffic_Halt;
          }
          while (packetTraffic == Traffic_Halt) usleep(1000);
          if (resultId == GUI_0PT_OPEN) copyTraffic(getPath(pInput1, strPath1), getPath("traffic_0pt", strPath2));
          else
          {
            addExtension(pInput1, ".0pt");
            copyTraffic(getPath("traffic_0pt", strPath1), getPath(pInput1, strPath2));
          }
          gui2D->Close();  //close all 2D GUI windows
        }
      }
      else messageBox("ERROR", "Enter File Name!");
      break;
    case GUI_EDIT_HOSTNAME: case GUI_EDIT_REMARKS:
      pInput1 = gui2D->GetInputText(GLueId[0] / OBJ_ID);
      strncpy((resultId == GUI_EDIT_HOSTNAME ? objLL->SelectedHost->Hostname : objLL->SelectedHost->Remarks), pInput1, 256);
      objLL->InfoSelected(strHost);
      gui2D->Close();  //close all 2D GUI windows
      break;
    case GUI_FIND_HOSTS:
      pInput1 = gui2D->GetInputText(GLueId[0] / OBJ_ID);
      pInput2 = gui2D->GetInputText(GLueId[1]);
      pInput3 = gui2D->GetInputText(GLueId[2]);
      pInput4 = gui2D->GetInputText(GLueId[3]);
      pInput5 = gui2D->GetInputText(GLueId[4]);
      if ((*pInput1 != '\0') || (*pInput2 != '\0') || (*pInput3 != '\0') || (*pInput4 != '\0') || (*pInput5 != '\0'))
      {
        if (val == GLUE_CUSTOM)
        {
          gui2D->PutInputText("", GLueId[0] / OBJ_ID);
          gui2D->PutInputText("", GLueId[1]);
          gui2D->PutInputText("", GLueId[2]);
          gui2D->PutInputText("", GLueId[3]);
          gui2D->PutInputText("", GLueId[4]);
        }
        else
        {
          objLL->SelectedHost = 0;
          if (!(mods & KMOD_CTRL)) objLL->SetHosts(4, 0, (objPrefs.HostActive == Active_Show));  //pHost->Selected
          bool isNet = false, goIP;
          unsigned short servicePort = 0;
          unsigned int cntFound = 0;
          in_addr_t netMask = 0, netAddress = 0;
          if (*pInput1 != '\0')
          {
            char *pPrefix;
            strncpy(strBuffer, pInput1, 19);
            if ((pPrefix = strchr(strBuffer, '/')))
            {
              *pPrefix = '\0';
              if (atoi(++pPrefix)) netMask = htonl(0xFFFFFFFF << (32 - atoi(pPrefix)));
              netAddress = inet_addr(strBuffer) & netMask;
              isNet = true;
            }
          }
          if (*pInput5 != '\0')
          {
            if ((atoi(pInput5) >= 0) && (atoi(pInput5) <= 65535)) servicePort = (unsigned short)atoi(pInput5);
            else gui2D->PutInputText("0", GLueId[4]);
          }
          obj_host *pHost;
          objLL->HostsLL.Start(0);
          while ((pHost = (obj_host *)objLL->HostsLL.Read(0)))
          {
            goIP = true;
            if (*pInput1 != '\0')
            {
              if (isNet)
              {
                if ((pHost->HostIP.s_addr & netMask) != netAddress) goIP = false;
              }
              else if (strcmp(inet_ntoa(pHost->HostIP), pInput1)) goIP = false;
            }
            if (goIP && strstr(lowerStr(pHost->HostMAC, strBuffer), pInput2) && strstr(lowerStr(pHost->Hostname, strBuffer), pInput3)
              && strstr(lowerStr(pHost->Remarks, strBuffer), pInput4))
            {
              if (*pInput5 == '\0')
              {
                pHost->Selected = 1;
                cntFound++;
              }
              else
              {
                for (cntService = 0; cntService < HOST_SERVICES; cntService++)
                {
                  if (pHost->Services[cntService] == -1) break;
                  if ((pHost->Services[cntService] / 10000) == servicePort)
                  {
                    pHost->Selected = 1;
                    cntFound++;
                    break;
                  }
                }
              }
            }
            objLL->HostsLL.Next(0);
          }
          sprintf(strBuffer, "Found: %u", cntFound);
          gui2D->PutLabelText(strBuffer, GLueId[5]);
        }
      }
      break;
    case GUI_INFO_SELECTION:
      gui2D->Scroll();  //start
      if (val == GLUE_CUSTOM) objLL->InfoSelection();
      else objLL->InfoGeneral();
      break;
    case GUI_MAKE_HOST:
      pInput1 = gui2D->GetInputText(GLueId[0] / OBJ_ID);
      if (*pInput1 != '\0')
      {
        in_addr oIP;
        oIP.s_addr = inet_addr(pInput1);
        objLL->SelectedHost = objLL->GetHost(0, oIP, true, &objPrefs);
        objLL->SelectedHost->Anomaly = 0;
        objLL->SelectedHost->Selected = 1;
        objLL->InfoSelected(strHost);
        gui2D->Close();  //close all 2D GUI windows
      }
      else messageBox("ERROR", "Enter IP Address!");
      break;
    case GUI_PACKET_PORT: case GUI_PACKET_PROTOCOL:
      pInput1 = gui2D->GetInputText(GLueId[0] / OBJ_ID);
      if (*pInput1 != '\0')
      {
        if (resultId == GUI_PACKET_PORT)
        {
          if ((atoi(pInput1) >= 1) && (atoi(pInput1) <= 65535))
          {
            objPrefs.ShowPort = (unsigned short)atoi(pInput1);
            if (objPrefs.ShowPort) objLL->DestroyPackets();
          }
          else messageBox("ERROR", "Invalid Port No.!");
        }
        else if ((atoi(pInput1) >= 1) && (atoi(pInput1) <= 255))
        {
          objPrefs.ShowProtocol = (unsigned char)atoi(pInput1);
          if (objPrefs.ShowProtocol) objLL->DestroyPackets();
        }
        else messageBox("ERROR", "Invalid Protocol No.!");
        updateOSD();
        gui2D->Close();  //close all 2D GUI windows
      }
      else messageBox("ERROR", "Enter Number!");
      break;
    case GUI_SELECT_INACTIVE:
      pInput1 = gui2D->GetInputText(GLueId[0] / OBJ_ID);
      pInput2 = gui2D->GetInputText(GLueId[1]);
      pInput3 = gui2D->GetInputText(GLueId[2]);
      if ((*pInput1 != '\0') || (*pInput2 != '\0') || (*pInput3 != '\0'))
      {
        objLL->SelectedHost = 0;
        time_t timeInactive = time(0);
        obj_host *pHost;
        objLL->HostsLL.Start(0);
        while ((pHost = (obj_host *)objLL->HostsLL.Read(0)))
        {
          pHost->Selected = ((timeInactive - pHost->LastPacket) > ((atoi(pInput1) * 86400) + (atoi(pInput2) * 360) + (atoi(pInput3) * 60)) ? 1 : 0);
          objLL->HostsLL.Next(0);
        }
        gui2D->Close();  //close all 2D GUI windows
      }
      else messageBox("ERROR", "Enter Days, Hours or Minutes!");
      break;
    case GUI_SENSOR_START:
      pInput1 = gui2D->GetInputText(GLueId[0] / OBJ_ID);
      pInput2 = gui2D->GetInputText(GLueId[1]);
      pInput3 = gui2D->GetInputText(GLueId[2]);
      if ((*pInput1 != '\0') && (*pInput2 != '\0') && (*pInput3 != '\0'))
      {
        if ((atoi(pInput3) >= 1) && (atoi(pInput3) <= 255))
        {
          char strCommand[537];
          strncpy(objPrefs.SensorStart, pInput1, 256);
          strncpy(objPrefs.SensorInfile, pInput2, 256);
          strncpy(objPrefs.SensorId, pInput3, 4);
          objPrefs.SensorPromisc = gui2D->GetChecked(GLueId[3]);
          sprintf(strCommand, "%s -i %s -s %s -u %hu %s -d", objPrefs.SensorStart, objPrefs.SensorInfile, objPrefs.SensorId, objPrefs.SensorPort, (objPrefs.SensorPromisc ? "-p" : ""));
          if (system(strCommand)) messageBox("ERROR", "Start Sensor Failed!");
          else gui2D->Close();  //close all 2D GUI windows
        }
        else messageBox("ERROR", "Invalid Sensor ID!");
      }
      else messageBox("ERROR", "Enter Command, Interface/File and Sensor ID!");
      break;
    case GUI_SENSOR_STOP:
      pInput1 = gui2D->GetInputText(GLueId[0] / OBJ_ID);
      if (*pInput1 != '\0')
      {
        strncpy(objPrefs.SensorStop, pInput1, 256);
        if (system(objPrefs.SensorStop)) messageBox("ERROR", "Stop Sensor Failed!");
        else gui2D->Close();  //close all 2D GUI windows
      }
      else messageBox("ERROR", "Enter Stop Sensor Command!");
      break;
    case GUI_SET_COMMANDS:
      strncpy(objPrefs.Commands[0], gui2D->GetInputText(GLueId[0] / OBJ_ID), 256);
      strncpy(objPrefs.Commands[1], gui2D->GetInputText(GLueId[1]), 256);
      strncpy(objPrefs.Commands[2], gui2D->GetInputText(GLueId[2]), 256);
      strncpy(objPrefs.Commands[3], gui2D->GetInputText(GLueId[3]), 256);
      gui2D->Close();  //close all 2D GUI windows
      break;
    case GUI_SET_EXPORT_CSV:
      pInput1 = gui2D->GetInputText(GLueId[0] / OBJ_ID);
      if (*pInput1 != '\0')
      {
        showWait();
        addExtension(pInput1, ".csv");
        sprintf(strPath1, "%s/%s", getenv("HOME"), pInput1);
        FILE *fileExport;
        if ((fileExport = fopen(strPath1, "w")))
        {
          char strRow[1097];
          fputs("\"IP\",\"MAC\",\"Name\",\"Remarks\",\"Services\"\n", fileExport);
          obj_host *pHost;
          objLL->HostsLL.Start(0);
          while ((pHost = (obj_host *)objLL->HostsLL.Read(0)))
          {
            if (pHost->Selected)
            {
              strncpy(strRow, "\"", 2);
              escapeQuotes(inet_ntoa(pHost->HostIP), strRow);
              strncat(strRow, "\",\"", 3);
              escapeQuotes(pHost->HostMAC, strRow);
              strncat(strRow, "\",\"", 3);
              escapeQuotes(pHost->Hostname, strRow);
              strncat(strRow, "\",\"", 3);
              escapeQuotes(pHost->Remarks, strRow);
              strncat(strRow, "\",\"", 3);
              for (cntService = 0; cntService < HOST_SERVICES; cntService++)
              {
                if (pHost->Services[cntService] == -1) break;
                sprintf(strRow, "%s%s:%d ", strRow, decodeProtocol((pHost->Services[cntService] % 10000) / 10, strBuffer), pHost->Services[cntService] / 10000);
              }
              strncat(strRow, "\"\n", 2);
              fputs(strRow, fileExport);
            }
            objLL->HostsLL.Next(0);
          }
          fclose(fileExport);
        }
        gui2D->Close();  //close all 2D GUI windows
      }
      else messageBox("ERROR", "Enter File Name!");
      break;
    case GUI_SET_NETPOS:
      pInput1 = gui2D->GetInputText(GLueId[0] / OBJ_ID);
      if (*pInput1 != '\0')
      {
        FILE *fileNetPos, *fileTemp;
        if ((fileNetPos = fopen(getPath("netpos.txt", strPath1), "r")))
        {
          if ((fileTemp = fopen(getPath("tmp_packet0", strPath2), "w")))
          {
            switch (val)
            {
              case GLUE_CUSTOM: gui2D->Scroll(GLUE_SCROLL_UP); break;
              case (GLUE_CUSTOM + 1): gui2D->Scroll(GLUE_SCROLL_DOWN); break;
              case (GLUE_CUSTOM + 2): break;  //nothing
              default:
                gui2D->Scroll();  //start
                fputs(pInput1, fileTemp);
                fputc('\n', fileTemp);
            }
            bool putTemp = false;
            char strTemp[256], *pEnd;
            while (fgets(strBuffer, 256, fileNetPos))
            {
              if ((pEnd = strchr(strBuffer, '\n'))) *pEnd = '\0';  //remove \n for comparison
              if (strcmp(strBuffer, pInput1))
              {
                if (val == GLUE_CUSTOM)
                {
                  if (putTemp)
                  {
                    fputs(strTemp, fileTemp);
                    fputc('\n', fileTemp);
                  }
                  strncpy(strTemp, strBuffer, 256);
                  putTemp = true;
                }
                else
                {
                  fputs(strBuffer, fileTemp);
                  fputc('\n', fileTemp);
                  if (putTemp)
                  {
                    fputs(strTemp, fileTemp);
                    fputc('\n', fileTemp);
                    putTemp = false;
                  }
                }
              }
              else if (val == GLUE_CUSTOM)
              {
                if (putTemp)
                {
                  fputs(strBuffer, fileTemp);
                  fputc('\n', fileTemp);
                  fputs(strTemp, fileTemp);
                  fputc('\n', fileTemp);
                  putTemp = false;
                }
                else
                {
                  fputs(strBuffer, fileTemp);
                  fputc('\n', fileTemp);
                }
              }
              else if (val == (GLUE_CUSTOM + 1))
              {
                strncpy(strTemp, strBuffer, 256);
                putTemp = true;
              }
            }
            if (putTemp)
            {
              fputs(strTemp, fileTemp);
              fputc('\n', fileTemp);
            }
            fclose(fileTemp);
            fclose(fileNetPos);
            remove(strPath1);  //netpos.txt
            rename(strPath2, strPath1);  //tmp_packet0, netpos.txt
            objLL->LoadNetPos(strPath1);  //reload netpos
          }
          else fclose(fileNetPos);
        }
      }
      break;
    case GUI_SET_PREFERENCES:
      pInput1 = gui2D->GetInputText(GLueId[0] / OBJ_ID);
      if (*pInput1 != '\0')
      {
        if ((atoi(pInput1) >= 1) && (atoi(pInput1) <= 65535))
        {
          unsigned short origPort = objPrefs.SensorPort;
          objPrefs.SensorPort = (unsigned short)atoi(pInput1);
          objPrefs.DstHosts = gui2D->GetChecked(GLueId[1]);
          if (objPrefs.DstHosts && objPrefs.Broadcasts) objPrefs.Broadcasts = false;
          objPrefs.FastPackets = gui2D->GetChecked(GLueId[2]);
          objPrefs.Font = (gui2D->GetChecked(GLueId[3]) ? 1 : 0);
          setFont(objPrefs.Font);
          objPrefs.OSD = gui2D->GetChecked(GLueId[4]);
          updateOSD();
          gui2D->Close();  //close all 2D GUI windows
          if (objPrefs.SensorPort != origPort) messageBox("RESTART REQUIRED", "Restart PacketZero to use New Port!");
        }
        else messageBox("ERROR", "Invalid Sensor Port No.!");
      }
      else messageBox("ERROR", "Enter Sensor Port No.!");
      break;
  }
}

//keyboard event
void keyboardGL(int key)
{
  unsigned short mods = SDL_GetModState();
  if (mods & KMOD_CTRL) key += GL_KEY_CTRL;
  if (gui2D->On())
  {
    char *pClipboard;
    switch (key)
    {
      case (GL_KEY_CTRL + 'x'):
        if ((pClipboard = gui2D->GetInputText()))
        {
          strncpy(objPrefs.Clipboard, pClipboard, 256);  //cut input text to clipboard
          gui2D->PutInputText("");
        }
        break;
      case (GL_KEY_CTRL + 'c'): if ((pClipboard = gui2D->GetInputText())) strncpy(objPrefs.Clipboard, pClipboard, 256); break;  //copy input text to clipboard
      case (GL_KEY_CTRL + 'v'): gui2D->PutInputText(objPrefs.Clipboard); break;  //paste input text from clipboard
      case GL_KEY_ENTER: processButton(gui2D->DefaultButton(), mods); break;  //process 2D GUI default button
      case GL_KEY_ESC: gui2D->Close(false); break;  //close focused 2D GUI window
      case GL_KEY_TAB: case (GL_KEY_CTRL + GL_KEY_TAB):  //select next/previous host in selection, update host info
        if ((GLueId[0] % OBJ_ID) == GUI_INFO_HOST)
        {
          objLL->TabHost(strHost, (key != GL_KEY_TAB));
          if (objLL->SelectedHost)
          {
            gui2D->Scroll();  //start
            objLL->InfoHost(strHost);
          }
          break;
        }  //pass tab to 2D GUI
      default: gui2D->Key(key, (mods & KMOD_SHIFT));  //pass key to 2D GUI
    }
  }
  else
  {
    double moveSpeed = (mods & KMOD_SHIFT ? 3.0 : 2.0) * MOVE_SIZE, angleX = objPrefs.ViewSpot[0].AngleX * RADIANS, angleY = objPrefs.ViewSpot[0].AngleY * RADIANS;
    char strPath1[4096], strPath2[4096];
    switch (key)
    {
      case GL_KEY_UP: case GL_KEY_DOWN:  //move forward/back
        if (key == GL_KEY_DOWN) moveSpeed *= -1.0;
        objPrefs.ViewSpot[0].X += sin(angleX) * cos(angleY) * moveSpeed;
        objPrefs.ViewSpot[0].Y -= sin(angleY) * moveSpeed;
        objPrefs.ViewSpot[0].Z -= cos(angleX) * cos(angleY) * moveSpeed;
        break;
      case GL_KEY_LEFT: case GL_KEY_RIGHT:  //move left/right
        if (key == GL_KEY_RIGHT) moveSpeed *= -1.0;
        objPrefs.ViewSpot[0].X -= cos(angleX) * moveSpeed;
        objPrefs.ViewSpot[0].Z -= sin(angleX) * moveSpeed;
        break;
      case GL_KEY_HOME: case (GL_KEY_CTRL + GL_KEY_HOME): objPrefs.ViewSpot[0] = (key == GL_KEY_HOME ? homeView[0] : homeView[1]); break;  //recall default views
      case (GL_KEY_CTRL + GL_KEY_F1): case (GL_KEY_CTRL + GL_KEY_F2): case (GL_KEY_CTRL + GL_KEY_F3): case (GL_KEY_CTRL + GL_KEY_F4):  //recall view position 1-4
        objPrefs.ViewSpot[0] = objPrefs.ViewSpot[(key + 1) - (GL_KEY_CTRL + GL_KEY_F1)];
        break;
      case (GL_KEY_CTRL + 'a'): objLL->SetHosts(4, 1, (objPrefs.HostActive == Active_Show)); break;  //select all hosts, pHost->Selected
      case (GL_KEY_CTRL + 's'): case (GL_KEY_CTRL + 'n'): case 't': case 'j': case (GL_KEY_CTRL + 'j'): case 'p': case (GL_KEY_CTRL + 'p'):
      case 'q': case 'e': case 'w': case 'a': case 'd': case 's':
        if ((key == (GL_KEY_CTRL + 's')) || (key == (GL_KEY_CTRL + 'n'))) objLL->SelectedHost = 0;
        obj_host *pHost;
        objLL->HostsLL.Start(0);
        while ((pHost = (obj_host *)objLL->HostsLL.Read(0)))
        {
          if (key == (GL_KEY_CTRL + 's')) pHost->Selected = (pHost->Selected ? 0 : 1);  //invert selection
          else if (key == (GL_KEY_CTRL + 'n')) pHost->Selected = (*pHost->Hostname != '\0' ? 1 : 0);  //select all named hosts
          else if (pHost->Selected)
          {
            switch (key)
            {
              case 't': pHost->Label = (pHost->Label ? 0 : 1); break;  //toggle selection persistant IP
              case 'j': pHost->AutoLink = 1; break;  //automatic link lines for selection
              case (GL_KEY_CTRL + 'j'): pHost->AutoLink = 0; break;  //stop automatic link lines for selection
              case 'p': pHost->Packets = 1; break;  //show packets for selection
              case (GL_KEY_CTRL + 'p'): pHost->Packets = 0; break;  //stop showing packets for selection
              default:
                if (pHost->Lock) break;
                if (key == 'q') pHost->Y += HOST_SPACE;  //move selection up
                else if (key == 'e') pHost->Y -= HOST_SPACE;  //move selection down
                else
                {
                  if (key == 'w') angleX = objPrefs.ViewSpot[0].AngleX * RADIANS;  //move selection forward
                  else if (key == 'a') angleX = (objPrefs.ViewSpot[0].AngleX - 90.0) * RADIANS;  //move selection left
                  else if (key == 'd') angleX = (objPrefs.ViewSpot[0].AngleX + 90.0) * RADIANS;  //move selection right
                  else angleX = (objPrefs.ViewSpot[0].AngleX + 180.0) * RADIANS;  //move selection back
                  if (cos(angleX) < -0.707) pHost->Z += HOST_SPACE;
                  else if (sin(angleX) > 0.707) pHost->X += HOST_SPACE;
                  else if (sin(angleX) < -0.707) pHost->X -= HOST_SPACE;
                  else pHost->Z -= HOST_SPACE;
                }
                objLL->DetectCluster(1, pHost);
            }
          }
          objLL->HostsLL.Next(0);
        }
        break;
      case 'f':  //2D GUI find hosts
        gui2D->CreateWindow(-1, -1, 59, 44, "FIND HOSTS");
        gui2D->AddLabel(2, 3, "IP/Net:");
        gui2D->AddLabel(34, 3, "(CIDR Notation for Net)");
        gui2D->AddLabel(2, 9, "MAC:");
        GLueId[1] = gui2D->AddInput(12, 8, 17, 17, "", true, true);
        gui2D->AddLabel(2, 15, "Hostname:");
        GLueId[2] = gui2D->AddInput(12, 14, 43, 255, "", true);
        gui2D->AddLabel(2, 21, "Remarks:");
        GLueId[3] = gui2D->AddInput(12, 20, 43, 255, "", true);
        gui2D->AddLabel(2, 27, "Port No.:");
        GLueId[4] = gui2D->AddInput(12, 26, 5, 5, "", true, true);
        GLueId[5] = gui2D->AddLabel(26, 27, "");
        GLueId[0] = (gui2D->AddInput(12, 2, 18, 18, "", true, true) * OBJ_ID) + GUI_FIND_HOSTS;  //last for focus
        gui2D->AddButton(27, 32, GLUE_OK, "Find", true, true);
        gui2D->AddButton(37, 32, GLUE_CUSTOM, "Clear");
        gui2D->AddButton(48, 32, GLUE_CLOSE, "Close");
        break;
      case GL_KEY_TAB: case (GL_KEY_CTRL + GL_KEY_TAB): objLL->TabHost(strHost, (key != GL_KEY_TAB)); break;  //select next/previous host in selection
      case 'c':  //cycle show IP - IP/name - name only
        if (objPrefs.LabelText == Text_IP) objPrefs.LabelText = Text_Both;
        else if (objPrefs.LabelText == Text_Both) objPrefs.LabelText = Text_Name;
        else objPrefs.LabelText = Text_IP;
        updateOSD();
        break;
      case 'm':  //make host
        gui2D->CreateWindow(-1, -1, 39, 20, "MAKE HOST");
        gui2D->AddLabel(2, 3, "Enter IP Address:");
        GLueId[0] = (gui2D->AddInput(20, 2, 15, 15, "", false, true) * OBJ_ID) + GUI_MAKE_HOST;
        gui2D->AddButton(19, 8, GLUE_OK, "OK", true, true);
        gui2D->AddButton(27, 8, GLUE_CLOSE, "Cancel");
        break;
      case 'n':  //edit selected host hostname
        if (!objLL->SelectedHost) break;
        gui2D->CreateWindow(-1, -1, 54, 23, inet_ntoa(objLL->SelectedHost->HostIP));
        gui2D->AddLabel(2, 2, "Edit Hostname:");
        GLueId[0] = (gui2D->AddInput(2, 5, 48, 255, objLL->SelectedHost->Hostname) * OBJ_ID) + GUI_EDIT_HOSTNAME;
        gui2D->AddButton(34, 11, GLUE_OK, "OK", true, true);
        gui2D->AddButton(42, 11, GLUE_CLOSE, "Cancel");
        break;
      case 'r':  //edit selected host remarks
        if (!objLL->SelectedHost) break;
        gui2D->CreateWindow(-1, -1, 54, 23, inet_ntoa(objLL->SelectedHost->HostIP));
        gui2D->AddLabel(2, 2, "Edit Remarks:");
        GLueId[0] = (gui2D->AddInput(2, 5, 48, 255, objLL->SelectedHost->Remarks) * OBJ_ID) + GUI_EDIT_REMARKS;
        gui2D->AddButton(34, 11, GLUE_OK, "OK", true, true);
        gui2D->AddButton(42, 11, GLUE_CLOSE, "Cancel");
        break;
      case 'l': case (GL_KEY_CTRL + 'l'):  //create/delete start/end link line with selected host
        if (objLL->SelectedHost)
        {
          if (objLL->LinkHost)
          {
            if (objLL->LinkHost != objLL->SelectedHost)
            {
              if (key == (GL_KEY_CTRL + 'l')) objLL->DeleteLink(objLL->SelectedHost);
              else objLL->CreateLink(0, objLL->LinkHost, objLL->SelectedHost, 0);
            }
            objLL->LinkHost = 0;
          }
          else objLL->LinkHost = objLL->SelectedHost;
        }
        else objLL->LinkHost = 0;
        break;
      case 'y':  //automatic link lines for all hosts
        objPrefs.NewLinks = true;
        objLL->SetHosts(1, 1);  //pHost->AutoLink
        updateOSD();
        break;
      case (GL_KEY_CTRL + 'y'):  //toggle automatic link lines for new hosts
        objPrefs.NewLinks = !objPrefs.NewLinks;
        updateOSD();
        break;
      case (GL_KEY_CTRL + 'r'):  //delete link lines for all hosts
        objPrefs.NewLinks = false;
        objLL->SetHosts(1, 0);  //pHost->AutoLink
        objLL->DestroyLinks();
        updateOSD();
        break;
      case 'u':  //show packets for all hosts
        objPrefs.NewPackets = true;
        objLL->SetHosts(3, 1);  //pHost->Packets
        updateOSD();
        break;
      case (GL_KEY_CTRL + 'u'):  //toggle show packets for new hosts
        objPrefs.NewPackets = !objPrefs.NewPackets;
        updateOSD();
        break;
      case GL_KEY_F1: case GL_KEY_F2: case GL_KEY_F3: case GL_KEY_F4:
        objPrefs.ShowSensor = (unsigned char)((key + 1) - GL_KEY_F1);
        objLL->DestroyPackets();
        updateOSD();
        break;
      case GL_KEY_F5:  //show packets from all sensors
        objPrefs.ShowSensor = 0;
        updateOSD();
        break;
      case '-':  //decrement sensor to show packets from
        objPrefs.ShowSensor--;
        objLL->DestroyPackets();
        updateOSD();
        break;
      case '=':  //increment sensor to show packets from
        objPrefs.ShowSensor++;
        objLL->DestroyPackets();
        updateOSD();
        break;
      case 'b':  //toggle broadcasts
        objPrefs.Broadcasts = !objPrefs.Broadcasts;
        if (objPrefs.Broadcasts && objPrefs.DstHosts) objPrefs.DstHosts = false;
        updateOSD();
        break;
      case 'v': objPrefs.PortText = !objPrefs.PortText; break;  //toggle show packet destination port
      case 'z':  //toggle packet speed
        objPrefs.FastPackets = !objPrefs.FastPackets;
        updateOSD();
        break;
      case 'k':  //packets off
        objPrefs.NewPackets = false;
        objLL->SetHosts(3, 0);  //pHost->Packets
        objLL->DestroyPackets();
        updateOSD();
        break;
      case GL_KEY_PAGEDN:  //packet traffic record
        if (packetTraffic > Traffic_Halt) packetTraffic = Traffic_Halt;
        while (packetTraffic == Traffic_Halt) usleep(1000);
        if ((fileTraffic = fopen(getPath("traffic_0pt", strPath1), "wb")))
        {
          fputs("0PT0", fileTraffic);
          timeOffset = 0;
          packetTraffic = Traffic_Record;
        }
        break;
      case GL_KEY_INSERT:  //packet traffic replay
        if (packetTraffic > Traffic_Halt) packetTraffic = Traffic_Halt;
        while (packetTraffic == Traffic_Halt) usleep(1000);
        if ((fileTraffic = fopen(getPath("traffic_0pt", strPath1), "rb")))
        {
          fseek(fileTraffic, 4, SEEK_SET);
          if (fread(&replayPacket, PKT_TIME_SIZE, 1, fileTraffic) == 1)
          {
            objLL->DestroyPackets();
            timeOffset = milliTime(0) - milliTime(&replayPacket.Time);
            packetTraffic = Traffic_Replay;
          }
          else fclose(fileTraffic);
        }
        break;
      case GL_KEY_PAGEUP: if (packetTraffic == Traffic_Replay) timeOffset = milliTime(0) - milliTime(&replayPacket.Time); break;  //packet traffic replay - jump to next packet
      case GL_KEY_END:  //packet traffic record/replay stop
        if (packetTraffic == Traffic_Record) packetTraffic = Traffic_Halt;
        else if (packetTraffic == Traffic_Replay)
        {
          objLL->DestroyPackets();
          packetTraffic = Traffic_Halt;
        }
        break;
      case GL_KEY_F7: case GL_KEY_F8:  //2D GUI open/save packet traffic file
        createFileList(getPath("tmp_packet0", strPath1), getPath("", strPath2), ".0pt");
        if (key == GL_KEY_F7)
        {
          gui2D->CreateWindow(-1, -1, 56, 47, "OPEN PACKET TRAFFIC FILE...", true, true);
          GLueId[0] = (gui2D->AddInput(2, 5, 50, 251, "") * OBJ_ID) + GUI_0PT_OPEN;
        }
        else
        {
          gui2D->CreateWindow(-1, -1, 56, 47, "SAVE PACKET TRAFFIC FILE AS...", true, true);
          GLueId[0] = (gui2D->AddInput(2, 5, 50, 251, "") * OBJ_ID) + GUI_0PT_SAVE;
        }
        gui2D->AddLabel(2, 2, "Enter File Name:");
        gui2D->AddList(2, 10, 2, 10, strPath1);
        gui2D->AddButton(26, 8, GLUE_OK, "OK", false, true);
        gui2D->AddButton(14, 8, GLUE_CUSTOM, "Delete", false, false);
        gui2D->AddButton(2, 8, GLUE_CLOSE, "Cancel", false, false);
        break;
      case GL_KEY_SPACE: canAnimate = !canAnimate; break;  //toggle animation
      case (GL_KEY_CTRL + 'k'): objLL->SetHosts(0, 0); break;  //acknowledge all anomalies, pHost->Anomaly
      case 'o': objPrefs.OSD = !objPrefs.OSD; break;  //toggle OSD
      case 'i':  //2D GUI selected host info
        if (!objLL->SelectedHost) break;
        objLL->InfoHost(strHost);
        gui2D->CreateWindow(-2, -2, 56, 48, "HOST INFORMATION", true, true);
        gui2D->AddView(2, 2, 2, 2, 10, getPath("tmp_packet0", strPath1));
        GLueId[0] = GUI_INFO_HOST;
        break;
      case 'g':  //2D GUI selection info
        objLL->InfoSelection();
        gui2D->CreateWindow(-2, -2, 56, 48, "SELECTION INFORMATION", true, true);
        gui2D->AddButton(2, 2, GLUE_CUSTOM, "Selection");
        gui2D->AddButton(17, 2, GLUE_CUSTOM + 1, "General");
        gui2D->AddButton(30, 2, GLUE_CLOSE, "Close", true, true);
        gui2D->AddView(2, 10, 2, 2, 17, getPath("tmp_packet0", strPath1));
        GLueId[0] = GUI_INFO_SELECTION;
        break;
      case 'x':  //toggle fullscreen
        SDL_SetWindowFullscreen(SDLWindow, (SDL_GetWindowFlags(SDLWindow) & SDL_WINDOW_FULLSCREEN_DESKTOP ? 0 : SDL_WINDOW_FULLSCREEN_DESKTOP));
        break;
      case 'h':  //2D GUI help
        gui2D->CreateWindow(-2, -2, 56, 48, "HELP", true, true);
        gui2D->AddBitmap(3, 2, 0, 0, clrRed[0], clrRed[1], clrRed[2], GUI_GFX[16]);
        gui2D->AddLabel(5, 2, "ICMP");
        gui2D->AddBitmap(12, 2, 0, 0, clrGreen[0], clrGreen[1], clrGreen[2], GUI_GFX[16]);
        gui2D->AddLabel(14, 2, "TCP");
        gui2D->AddBitmap(21, 2, 0, 0, clrBlue[0], clrBlue[1], clrBlue[2], GUI_GFX[16]);
        gui2D->AddLabel(23, 2, "UDP");
        gui2D->AddBitmap(30, 2, 0, 0, clrYellow[0], clrYellow[1], clrYellow[2], GUI_GFX[16]);
        gui2D->AddLabel(32, 2, "ARP");
        gui2D->AddBitmap(39, 2, 0, 0, clrGreyBright[0], clrGreyBright[1], clrGreyBright[2], GUI_GFX[16]);
        gui2D->AddLabel(41, 2, "OTHER");
        gui2D->AddView(2, 6, 2, 2, 21, getPath("controls.txt", strPath1));
        GLueId[0] = 0;
        break;
      case (GL_KEY_CTRL + 'q'): goRun = false; break;
    }
  }
  goRefresh = true;
}

//process 2D GUI menu item selected
void processMenu(int item)
{
  gui2D->Close();  //close all 2D GUI windows
  if (!item) return;
  if (item <= 9)
  {
    showWait();
    if (item == 9) objLL->SelectedHost = 0;
    bool initHost = true;
    int posX = 0, posY = 0, posZ = 0;
    obj_host *pHost;
    objLL->HostsLL.Start(0);
    while ((pHost = (obj_host *)objLL->HostsLL.Read(0)))
    {
      if (pHost->Selected && !pHost->Lock)
      {
        switch (item)
        {
          case 1:  //move selection to grey zone
            if (pHost->X < 0) pHost->X *= -1;
            if (pHost->Z < 0) pHost->Z *= -1;
            objLL->BlankHost(1, pHost, 1, ROW_HOSTS);
            objLL->DetectCluster(1, pHost);
            break;
          case 2:  //move selection to blue zone
            if (pHost->X > 0) pHost->X *= -1;
            if (pHost->Z < 0) pHost->Z *= -1;
            objLL->BlankHost(1, pHost, 1, ROW_HOSTS);
            objLL->DetectCluster(1, pHost);
            break;
          case 3:  //move selection to green zone
            if (pHost->X > 0) pHost->X *= -1;
            if (pHost->Z > 0) pHost->Z *= -1;
            objLL->BlankHost(1, pHost, 1, ROW_HOSTS);
            objLL->DetectCluster(1, pHost);
            break;
          case 4:  //move selection to red zone
            if (pHost->X < 0) pHost->X *= -1;
            if (pHost->Z > 0) pHost->Z *= -1;
            objLL->BlankHost(1, pHost, 1, ROW_HOSTS);
            objLL->DetectCluster(1, pHost);
            break;
          case 5: case 6: case 7:  //auto arrange
            if (initHost)
            {
              objLL->BlankHost(1, pHost, (item == 7 ? 2 : 1), (item == 5 ? ROW_HOSTS : 10));
              objLL->DetectCluster(1, pHost);
              posX = pHost->X;
              posY = pHost->Y;
              posZ = pHost->Z;
              initHost = false;
            }
            else
            {
              pHost->X = posX;
              pHost->Y = posY;
              pHost->Z = posZ;
              objLL->BlankHost(1, pHost, (item == 7 ? 2 : 1), (item == 5 ? ROW_HOSTS : 10));
              objLL->DetectCluster(1, pHost);
            }
            break;
          case 8:  //arrange into nets
            if (!(posX = objLL->NetHost(0, pHost))) break;
            if (posX == 1) objLL->BlankHost(1, pHost, 1, ROW_HOSTS);
            objLL->DetectCluster(1, pHost);
            break;
          case 9:  //delete selection
            if (pHost == objLL->LinkHost) objLL->LinkHost = 0;;
            objLL->BlankHost(1, pHost, 1, ROW_HOSTS);
            objLL->DetectCluster(1, pHost);
            objLL->HostsLL.Delete(0);
            objLL->DestroyPackets(pHost);
            objLL->DestroyAlerts(pHost);
            objLL->DestroyLinks(pHost);
            pHost = 0;
            break;
        }
      }
      if (pHost) objLL->HostsLL.Next(0);
    }
    gui2D->Close();  //close all 2D GUI windows
  }
  else if (item <= 36)
  {
    if (item >= 31) objLL->SelectedHost = 0;
    unsigned char cntService;
    time_t timeInactive = time(0);
    char strCommand[274];
    obj_host *pHost;
    objLL->HostsLL.Start(0);
    while ((pHost = (obj_host *)objLL->HostsLL.Read(0)))
    {
      switch (item)
      {
        case 31: pHost->Selected = pHost->Anomaly; break;  //select all anomalies
        case 32: pHost->Selected = pHost->Packets; break;  //select all showing packets
        case 33: pHost->Selected = ((timeInactive - pHost->LastPacket) > 300 ? 1 : 0); break;  //select inactive > 5 minutes
        case 34: pHost->Selected = ((timeInactive - pHost->LastPacket) > 3600 ? 1 : 0); break;  //select inactive > 1 hour
        case 35: pHost->Selected = ((timeInactive - pHost->LastPacket) > 86400 ? 1 : 0); break;  //select inactive > 1 day
        case 36: pHost->Selected = ((timeInactive - pHost->LastPacket) > 604800 ? 1 : 0); break;  //select inactive > 1 week
        default:
          if (!pHost->Selected) break;
          switch (item)
          {
            case 10: case 11: case 12: case 13: case 14: case 15: case 16: case 17: case 18: case 19: pHost->Color = item % 10; break;  //colour
            case 20: pHost->Lock = 1; break;  //lock on
            case 21: pHost->Lock = 0; break;  //lock off
            case 22: objLL->DestroyLinks(pHost); break;  //reset selection link lines
            case 23: pHost->Downloads = 0; break;  //reset downloads
            case 24: pHost->Uploads = 0; break;  //reset uploads
            case 25: for (cntService = 0; cntService < HOST_SERVICES; cntService++) pHost->Services[cntService] = -1; break;  //reset services list
            case 26: pHost->Anomaly = 0; break;  //acknowledge anomaly
            case 27: case 28: case 29: case 30:
              if (*objPrefs.Commands[item - 27] == '\0') break;
              sprintf(strCommand, "%s %s &", objPrefs.Commands[item - 27], inet_ntoa(pHost->HostIP));
              if (system(strCommand)) break;  //nothing
              break;
          }
      }
      objLL->HostsLL.Next(0);
    }
  }
  else
  {
    char strBuffer[256] = "", strPath1[4096], strPath2[4096];
    switch (item)
    {
      case 37: case 38:  //2D GUI netpos editor
        if ((item == 38) && objLL->SelectedHost) sprintf(strBuffer, "pos %s/32 %d %d %d %s", inet_ntoa(objLL->SelectedHost->HostIP), objLL->SelectedHost->X / HOST_SPACE
          , objLL->SelectedHost->Y / HOST_SPACE, objLL->SelectedHost->Z / HOST_SPACE, txtColor[objLL->SelectedHost->Color]);  //add selected host netpos
        gui2D->CreateWindow(-1, -1, 56, 47, "NET POSITIONS", true, true);
        gui2D->AddLabel(2, 2, "Line:");
        GLueId[0] = (gui2D->AddInput(2, 5, 50, 255, strBuffer) * OBJ_ID) + GUI_SET_NETPOS;
        gui2D->AddList(2, 10, 2, 10, getPath("netpos.txt", strPath1));
        gui2D->AddButton(46, 8, GLUE_CUSTOM, "\x7F", false, false);  //item up
        gui2D->AddButton(39, 8, GLUE_CUSTOM + 1, "\x80", false, false);  //item down
        gui2D->AddButton(25, 8, GLUE_OK, "Add", false, true);
        gui2D->AddButton(13, 8, GLUE_CUSTOM + 2, "Delete", false, false);
        gui2D->AddButton(2, 8, GLUE_CLOSE, "Close", false, false);
        break;
      case 39: objLL->DestroyAll(); break;  //clear network layout
      case 40: keyboardGL('i'); break;  //2D GUI selected host info
      case 41:  //show selected host packets only
        if (!objLL->SelectedHost) break;
        keyboardGL('k');  //packets off
        objLL->SelectedHost->Packets = 1;  //show packets
        break;
      case 42:  //move selected host here
        if (!objLL->SelectedHost) break;
        if (objLL->SelectedHost->Lock) break;
        objLL->SelectedHost->X += (int)((objPrefs.ViewSpot[0].X - objLL->SelectedHost->X) / HOST_SPACE) * HOST_SPACE;
        objLL->SelectedHost->Y += (int)((objPrefs.ViewSpot[0].Y - objLL->SelectedHost->Y) / HOST_SPACE) * HOST_SPACE;
        objLL->SelectedHost->Z += (int)((objPrefs.ViewSpot[0].Z - objLL->SelectedHost->Z) / HOST_SPACE) * HOST_SPACE;
        objLL->DetectCluster(0, objLL->SelectedHost);
        break;
      case 43:  //go to selected host
        if (objLL->SelectedHost)
        {
          view_spot tViewSpot = {(double)objLL->SelectedHost->X, (double)objLL->SelectedHost->Y + 5.0
            , (double)objLL->SelectedHost->Z + ((objLL->SelectedHost->Z < 0 ? -16.0 : 16.0) * MOVE_SIZE), (objLL->SelectedHost->Z < 0 ? 180.0 : 0.0), 0.0};
          objPrefs.ViewSpot[0] = tViewSpot;
        }
        break;
      case 44: keyboardGL('n'); break;  //edit selected host hostname
      case 45: keyboardGL('r'); break;  //edit selected host remarks
      case 46: keyboardGL('g'); break;  //2D GUI selection info
      case 47: keyboardGL(GL_KEY_CTRL + 'k'); break;  //acknowledge all anomalies
      case 48:  //toggle anomaly detection
        objPrefs.AnomDetect = !objPrefs.AnomDetect;
        updateOSD();
        break;
      case 50: keyboardGL('u'); break;  //show packets for all hosts
      case 51:  //show all protocols packets
        objPrefs.ShowProtocol = 0;
        updateOSD();
        break;
      case 52:  //show ICMP packets
        objPrefs.ShowProtocol = IPPROTO_ICMP;
        objLL->DestroyPackets();
        updateOSD();
        break;
      case 53:  //show TCP packets
        objPrefs.ShowProtocol = IPPROTO_TCP;
        objLL->DestroyPackets();
        updateOSD();
        break;
      case 54:  //show UDP packets
        objPrefs.ShowProtocol = IPPROTO_UDP;
        objLL->DestroyPackets();
        updateOSD();
        break;
      case 55:  //show ARP packets
        objPrefs.ShowProtocol = IPPROTO_ARP;
        objLL->DestroyPackets();
        updateOSD();
        break;
      case 56:  //enter protocol to show packets for
        gui2D->CreateWindow(-1, -1, 29, 20, "PACKETS PROTOCOL");
        gui2D->AddLabel(2, 3, "Enter Protocol No.:");
        GLueId[0] = (gui2D->AddInput(22, 2, 3, 3, "", false, true) * OBJ_ID) + GUI_PACKET_PROTOCOL;
        gui2D->AddButton(9, 8, GLUE_OK, "OK", true, true);
        gui2D->AddButton(17, 8, GLUE_CLOSE, "Cancel");
        break;
      case 57:  //show all ports packets
        objPrefs.ShowPort = 0;
        updateOSD();
        break;
      case 58:  //enter port to show packets for
        gui2D->CreateWindow(-1, -1, 27, 20, "PACKETS PORT");
        gui2D->AddLabel(2, 3, "Enter Port No.:");
        GLueId[0] = (gui2D->AddInput(18, 2, 5, 5, "", false, true) * OBJ_ID) + GUI_PACKET_PORT;
        gui2D->AddButton(7, 8, GLUE_OK, "OK", true, true);
        gui2D->AddButton(15, 8, GLUE_CLOSE, "Cancel");
        break;
      case 59: keyboardGL('k'); break;  //packets off
      case 60: case 65:  //2D GUI open/save network layout file
        createFileList(getPath("tmp_packet0", strPath1), getPath("", strPath2), ".0nl");
        if (item == 60)
        {
          gui2D->CreateWindow(-1, -1, 56, 47, "OPEN NETWORK LAYOUT FILE...", true, true);
          GLueId[0] = (gui2D->AddInput(2, 5, 50, 251, "") * OBJ_ID) + GUI_0NL_OPEN;
        }
        else
        {
          gui2D->CreateWindow(-1, -1, 56, 47, "SAVE NETWORK LAYOUT FILE AS...", true, true);
          GLueId[0] = (gui2D->AddInput(2, 5, 50, 251, "") * OBJ_ID) + GUI_0NL_SAVE;
        }
        gui2D->AddLabel(2, 2, "Enter File Name:");
        gui2D->AddList(2, 10, 2, 10, strPath1);
        gui2D->AddButton(26, 8, GLUE_OK, "OK", false, true);
        gui2D->AddButton(14, 8, GLUE_CUSTOM, "Delete", false, false);
        gui2D->AddButton(2, 8, GLUE_CLOSE, "Cancel", false, false);
        break;
      case 61: objLL->LoadNet(getPath("1network_0nl", strPath1)); break;  //restore network layout 1
      case 62: objLL->LoadNet(getPath("2network_0nl", strPath1)); break;  //restore network layout 2
      case 63: objLL->LoadNet(getPath("3network_0nl", strPath1)); break;  //restore network layout 3
      case 64: objLL->LoadNet(getPath("4network_0nl", strPath1)); break;  //restore network layout 4
      case 66: objLL->SaveNet(getPath("1network_0nl", strPath1)); break;  //save current network layout as network layout 1
      case 67: objLL->SaveNet(getPath("2network_0nl", strPath1)); break;  //save current network layout as network layout 2
      case 68: objLL->SaveNet(getPath("3network_0nl", strPath1)); break;  //save current network layout as network layout 3
      case 69: objLL->SaveNet(getPath("4network_0nl", strPath1)); break;  //save current network layout as network layout 4
      case 70: keyboardGL(GL_KEY_HOME); break;  //recall default views
      case 71: case 72: case 73: case 74: keyboardGL(GL_KEY_CTRL + GL_KEY_F1 + (item - 71)); break;  //recall view position 1-4, ctrl+f1-f4
      case 75: case 76: case 77: case 78: objPrefs.ViewSpot[item - 74] = objPrefs.ViewSpot[0]; break;  //save current view as view position 1-4
      case 80:  //show selection IP/name
        objPrefs.HostLabel = Label_Selection;
        if (objPrefs.HostActive == Active_Label) objPrefs.HostActive = Active_Nothing;
        updateOSD();
        break;
      case 81:  //show all IP/name
        objPrefs.HostLabel = Label_All;
        if (objPrefs.HostActive == Active_Label) objPrefs.HostActive = Active_Nothing;
        updateOSD();
        break;
      case 82:  //on-active show IP/name
        objPrefs.HostActive = Active_Label;
        updateOSD();
        break;
      case 84: objLL->SetHosts(2, 0);  //show no IP/name, including persistant, pHost->Label
      case 83:  //show IP/name off
        objPrefs.HostLabel = Label_Off;
        if (objPrefs.HostActive == Active_Label) objPrefs.HostActive = Active_Nothing;
        updateOSD();
        break;
      case 85:  //on-active alert
        objPrefs.HostActive = Active_Alert;
        updateOSD();
        break;
      case 86:  //on-active show host
        objPrefs.HostActive = Active_Show;
        updateOSD();
        break;
      case 87:  //on-active select host
        objPrefs.HostActive = Active_Select;
        updateOSD();
        break;
      case 88:  //on-active do nothing
        objPrefs.HostActive = Active_Nothing;
        updateOSD();
        break;
      case 90: keyboardGL('f'); break;  //2D GUI find hosts
      case 91:
        gui2D->CreateWindow(-1, -1, 43, 20, "SELECT INACTIVE >");
        gui2D->AddLabel(2, 3, "Days:");
        gui2D->AddLabel(15, 3, "Hours:");
        GLueId[1] = gui2D->AddInput(22, 2, 2, 2, "", false, true);
        gui2D->AddLabel(28, 3, "Minutes:");
        GLueId[2] = gui2D->AddInput(37, 2, 2, 2, "", false, true);
        GLueId[0] = (gui2D->AddInput(8, 2, 3, 3, "", false, true) * OBJ_ID) + GUI_SELECT_INACTIVE;
        gui2D->AddButton(23, 8, GLUE_OK, "OK", true, true);
        gui2D->AddButton(31, 8, GLUE_CLOSE, "Cancel");
        break;
      case 92:  //show preferences
        sprintf(strBuffer, "%hu", objPrefs.SensorPort);
        gui2D->CreateWindow(-1, -1, 34, 44, "PREFERENCES");
        gui2D->AddLabel(2, 3, "Add Destination Hosts [D]:");
        GLueId[1] = gui2D->AddCheck(29, 2, objPrefs.DstHosts);
        gui2D->AddLabel(2, 9, "Fast Packets [F]:");
        GLueId[2] = gui2D->AddCheck(29, 8, objPrefs.FastPackets);
        gui2D->AddLabel(2, 15, "Large Font:");
        GLueId[3] = gui2D->AddCheck(29, 14, (objPrefs.Font ? true : false));
        gui2D->AddLabel(2, 21, "OSD:");
        GLueId[4] = gui2D->AddCheck(29, 20, objPrefs.OSD);
        gui2D->AddLabel(2, 27, "Sensor Port No.:");
        GLueId[0] = (gui2D->AddInput(25, 26, 5, 5, strBuffer, false, true) * OBJ_ID) + GUI_SET_PREFERENCES;
        gui2D->AddButton(14, 32, GLUE_OK, "OK", true, true);
        gui2D->AddButton(22, 32, GLUE_CLOSE, "Cancel");
        break;
      case 93:  //start local sensor
        gui2D->CreateWindow(-1, -1, 54, 38, "START LOCAL SENSOR");
        gui2D->AddLabel(2, 2, "Command:");
        gui2D->AddLabel(2, 11, "Interface/File:");
        GLueId[1] = gui2D->AddInput(2, 14, 48, 255, objPrefs.SensorInfile);
        gui2D->AddLabel(2, 21, "Sensor ID:");
        GLueId[2] = gui2D->AddInput(13, 20, 3, 3, objPrefs.SensorId, false, true);
        gui2D->AddLabel(20, 21, "(1-255)");
        gui2D->AddLabel(31, 21, "Promiscuous Mode:");
        GLueId[3] = gui2D->AddCheck(49, 20, objPrefs.SensorPromisc);
        GLueId[0] = (gui2D->AddInput(2, 5, 48, 255, objPrefs.SensorStart) * OBJ_ID) + GUI_SENSOR_START;  //last for focus
        gui2D->AddButton(31, 26, GLUE_OK, "Start", true, true);
        gui2D->AddButton(42, 26, GLUE_CLOSE, "Cancel");
        break;
      case 94:  //stop local sensor
        gui2D->CreateWindow(-1, -1, 54, 23, "STOP LOCAL SENSOR");
        gui2D->AddLabel(2, 2, "Command:");
        GLueId[0] = (gui2D->AddInput(2, 5, 48, 255, objPrefs.SensorStop) * OBJ_ID) + GUI_SENSOR_STOP;
        gui2D->AddButton(32, 11, GLUE_OK, "Stop", true, true);
        gui2D->AddButton(42, 11, GLUE_CLOSE, "Cancel");
        break;
      case 95:  //set selection commands
        gui2D->CreateWindow(-1, -1, 54, 42, "SET COMMANDS");
        gui2D->AddLabel(2, 2, "Host IP Address will be Appended to End of Command");
        gui2D->AddLabel(2, 7, "1:");
        gui2D->AddLabel(2, 13, "2:");
        GLueId[1] = gui2D->AddInput(5, 12, 45, 255, objPrefs.Commands[1]);
        gui2D->AddLabel(2, 19, "3:");
        GLueId[2] = gui2D->AddInput(5, 18, 45, 255, objPrefs.Commands[2]);
        gui2D->AddLabel(2, 25, "4:");
        GLueId[3] = gui2D->AddInput(5, 24, 45, 255, objPrefs.Commands[3]);
        GLueId[0] = (gui2D->AddInput(5, 6, 45, 255, objPrefs.Commands[0]) * OBJ_ID) + GUI_SET_COMMANDS;  //last for focus
        gui2D->AddButton(33, 30, GLUE_OK, "Set", true, true);
        gui2D->AddButton(42, 30, GLUE_CLOSE, "Cancel");
        break;
      case 96:  //export selection details in CSV file
        createFileList(getPath("tmp_packet0", strPath1), getenv("HOME"), ".csv");
        gui2D->CreateWindow(-1, -1, 56, 47, "EXPORT SELECTION DETAILS IN CSV FILE AS...", true, true);
        gui2D->AddLabel(2, 2, "Enter File Name:");
        GLueId[0] = (gui2D->AddInput(2, 5, 50, 251, "") * OBJ_ID) + GUI_SET_EXPORT_CSV;
        gui2D->AddList(2, 10, 2, 10, strPath1);
        gui2D->AddButton(14, 8, GLUE_OK, "OK", false, true);
        gui2D->AddButton(2, 8, GLUE_CLOSE, "Cancel", false, false);
        break;
      case 97: keyboardGL('h'); break;  //2D GUI help
      case 98:  //about
        gui2D->CreateWindow(-1, -1, 34, 28, "ABOUT");
        gui2D->AddLabel(2, 2, "PacketZero 1.0.2");
        gui2D->AddLabel(2, 5, "Copyright 2006-2016 Del Castle");
        gui2D->AddLabel(2, 8, "www.falsehex.com");
        gui2D->AddLabel(2, 11, "falsehex@gmail.com");
        gui2D->AddBitmap(2, 15, 1, 0, clrRed[0], clrRed[1], clrRed[2], GUI_GFX[0]);
        gui2D->AddBitmap(2, 15, 9, 0, clrRed[0], clrRed[1], clrRed[2], GUI_GFX[1]);
        gui2D->AddBitmap(2, 15, 1, 8, clrRed[0], clrRed[1], clrRed[2], GUI_GFX[2]);
        gui2D->AddBitmap(2, 15, 9, 8, clrRed[0], clrRed[1], clrRed[2], GUI_GFX[3]);
        gui2D->AddBitmap(2, 15, 1, 16, clrRed[0], clrRed[1], clrRed[2], GUI_GFX[4]);
        gui2D->AddBitmap(2, 15, 1, 24, clrRed[0], clrRed[1], clrRed[2], GUI_GFX[6]);
        gui2D->AddBitmap(2, 15, 1, 0, clrBlack[0], clrBlack[1], clrBlack[2], GUI_GFX[8]);
        gui2D->AddBitmap(2, 15, 9, 0, clrBlack[0], clrBlack[1], clrBlack[2], GUI_GFX[9]);
        gui2D->AddBitmap(2, 15, 1, 8, clrBlack[0], clrBlack[1], clrBlack[2], GUI_GFX[10]);
        gui2D->AddBitmap(2, 15, 9, 8, clrBlack[0], clrBlack[1], clrBlack[2], GUI_GFX[11]);
        gui2D->AddBitmap(2, 15, 0, 16, clrBlack[0], clrBlack[1], clrBlack[2], GUI_GFX[12]);
        gui2D->AddBitmap(2, 15, 1, 24, clrBlack[0], clrBlack[1], clrBlack[2], GUI_GFX[14]);
        gui2D->AddBitmap(2, 15, 15, 0, clrGreen[0], clrGreen[1], clrGreen[2], GUI_GFX[0]);
        gui2D->AddBitmap(2, 15, 23, 0, clrGreen[0], clrGreen[1], clrGreen[2], GUI_GFX[1]);
        gui2D->AddBitmap(2, 15, 15, 8, clrGreen[0], clrGreen[1], clrGreen[2], GUI_GFX[2]);
        gui2D->AddBitmap(2, 15, 23, 8, clrGreen[0], clrGreen[1], clrGreen[2], GUI_GFX[3]);
        gui2D->AddBitmap(2, 15, 23, 16, clrGreen[0], clrGreen[1], clrGreen[2], GUI_GFX[5]);
        gui2D->AddBitmap(2, 15, 23, 24, clrGreen[0], clrGreen[1], clrGreen[2], GUI_GFX[7]);
        gui2D->AddBitmap(2, 15, 15, 0, clrBlack[0], clrBlack[1], clrBlack[2], GUI_GFX[8]);
        gui2D->AddBitmap(2, 15, 23, 0, clrBlack[0], clrBlack[1], clrBlack[2], GUI_GFX[9]);
        gui2D->AddBitmap(2, 15, 15, 8, clrBlack[0], clrBlack[1], clrBlack[2], GUI_GFX[10]);
        gui2D->AddBitmap(2, 15, 23, 8, clrBlack[0], clrBlack[1], clrBlack[2], GUI_GFX[11]);
        gui2D->AddBitmap(2, 15, 24, 16, clrBlack[0], clrBlack[1], clrBlack[2], GUI_GFX[13]);
        gui2D->AddBitmap(2, 15, 23, 24, clrBlack[0], clrBlack[1], clrBlack[2], GUI_GFX[15]);
        gui2D->AddBitmap(2, 15, 8, 0, clrYellow[0], clrYellow[1], clrYellow[2], GUI_GFX[0]);
        gui2D->AddBitmap(2, 15, 16, 0, clrYellow[0], clrYellow[1], clrYellow[2], GUI_GFX[1]);
        gui2D->AddBitmap(2, 15, 8, 8, clrYellow[0], clrYellow[1], clrYellow[2], GUI_GFX[2]);
        gui2D->AddBitmap(2, 15, 16, 8, clrYellow[0], clrYellow[1], clrYellow[2], GUI_GFX[3]);
        gui2D->AddBitmap(2, 15, 8, 16, clrYellow[0], clrYellow[1], clrYellow[2], GUI_GFX[4]);
        gui2D->AddBitmap(2, 15, 16, 16, clrYellow[0], clrYellow[1], clrYellow[2], GUI_GFX[5]);
        gui2D->AddBitmap(2, 15, 8, 24, clrYellow[0], clrYellow[1], clrYellow[2], GUI_GFX[6]);
        gui2D->AddBitmap(2, 15, 16, 24, clrYellow[0], clrYellow[1], clrYellow[2], GUI_GFX[7]);
        gui2D->AddBitmap(2, 15, 8, 0, clrBlack[0], clrBlack[1], clrBlack[2], GUI_GFX[8]);
        gui2D->AddBitmap(2, 15, 16, 0, clrBlack[0], clrBlack[1], clrBlack[2], GUI_GFX[9]);
        gui2D->AddBitmap(2, 15, 8, 8, clrBlack[0], clrBlack[1], clrBlack[2], GUI_GFX[10]);
        gui2D->AddBitmap(2, 15, 16, 8, clrBlack[0], clrBlack[1], clrBlack[2], GUI_GFX[11]);
        gui2D->AddBitmap(2, 15, 7, 16, clrBlack[0], clrBlack[1], clrBlack[2], GUI_GFX[12]);
        gui2D->AddBitmap(2, 15, 17, 16, clrBlack[0], clrBlack[1], clrBlack[2], GUI_GFX[13]);
        gui2D->AddBitmap(2, 15, 8, 24, clrBlack[0], clrBlack[1], clrBlack[2], GUI_GFX[14]);
        gui2D->AddBitmap(2, 15, 16, 24, clrBlack[0], clrBlack[1], clrBlack[2], GUI_GFX[15]);
        gui2D->AddButton(26, 16, GLUE_CLOSE, "OK", true, true);
        GLueId[0] = 0;
        break;
      case 99: keyboardGL(GL_KEY_CTRL + 'q'); break;  //quit
      case 1000:
        if (objLL->SelectedHost) {
        gui2D->AddMenu(1001, "Selected", 1002);
          gui2D->AddMenu(1002, "Information (I)", 40);
          gui2D->AddMenu(1002, "Show Packets Only", 41);
          gui2D->AddMenu(1002, "Move Here", 42);
          gui2D->AddMenu(1002, "Go To", 43);
          gui2D->AddMenu(1002, "Hostname (N)", 44);
          gui2D->AddMenu(1002, "Remarks (R)", 45);
          gui2D->AddMenu(1002, "Add Net Position", 38); }
        gui2D->AddMenu(1001, "Selection", 1003);
          gui2D->AddMenu(1003, "Information (G)", 46);
          gui2D->AddMenu(1003, "Colour", 1004);
            gui2D->AddMenu(1004, "Grey", 10);
            gui2D->AddMenu(1004, "Orange", 11);
            gui2D->AddMenu(1004, "Yellow", 12);
            gui2D->AddMenu(1004, "Fluro", 13);
            gui2D->AddMenu(1004, "Green", 14);
            gui2D->AddMenu(1004, "Mint", 15);
            gui2D->AddMenu(1004, "Aqua", 16);
            gui2D->AddMenu(1004, "Blue", 17);
            gui2D->AddMenu(1004, "Purple", 18);
            gui2D->AddMenu(1004, "Violet", 19);
          gui2D->AddMenu(1003, "Lock", 1005);
            gui2D->AddMenu(1005, "On", 20);
            gui2D->AddMenu(1005, "Off", 21);
          gui2D->AddMenu(1003, "Move To Zone", 1006);
            gui2D->AddMenu(1006, "Grey", 1);
            gui2D->AddMenu(1006, "Blue", 2);
            gui2D->AddMenu(1006, "Green", 3);
            gui2D->AddMenu(1006, "Red", 4);
          gui2D->AddMenu(1003, "Arrange", 1007);
            gui2D->AddMenu(1007, "Default", 5);
            gui2D->AddMenu(1007, "10x10", 6);
            gui2D->AddMenu(1007, "10x10 2xSpace", 7);
            gui2D->AddMenu(1007, "Into Nets", 8);
          gui2D->AddMenu(1003, "Commands", 1008);
            gui2D->AddMenu(1008, "Command 1", 27);
            gui2D->AddMenu(1008, "Command 2", 28);
            gui2D->AddMenu(1008, "Command 3", 29);
            gui2D->AddMenu(1008, "Command 4", 30);
            gui2D->AddMenu(1008, "Set", 95);
          gui2D->AddMenu(1003, "Export CSV", 96);
          gui2D->AddMenu(1003, "Reset", 1009);
            gui2D->AddMenu(1009, "Link Lines", 22);
            gui2D->AddMenu(1009, "Downloads", 23);
            gui2D->AddMenu(1009, "Uploads", 24);
            gui2D->AddMenu(1009, "Services", 25);
          gui2D->AddMenu(1003, "Delete", 1010);
            gui2D->AddMenu(1010, "Confirm", 9);
        gui2D->AddMenu(1001, "Control", 1011);
          gui2D->AddMenu(1011, "Find Hosts (F)", 90);
          gui2D->AddMenu(1011, "Select Inactive", 1012);
            gui2D->AddMenu(1012, "> 5 Minutes", 33);
            gui2D->AddMenu(1012, "> 1 Hour", 34);
            gui2D->AddMenu(1012, "> 1 Day", 35);
            gui2D->AddMenu(1012, "> 1 Week", 36);
            gui2D->AddMenu(1012, "> Other", 91);
          gui2D->AddMenu(1011, "Preferences", 92);
          gui2D->AddMenu(1011, "Local Sensor", 1013);
            gui2D->AddMenu(1013, "Start", 93);
            gui2D->AddMenu(1013, "Stop", 94);
          gui2D->AddMenu(1011, "Help (H)", 97);
          gui2D->AddMenu(1011, "About", 98);
          gui2D->AddMenu(1011, "Quit", 99);
        gui2D->AddMenu(1001, "Anomalies", 1014);
          gui2D->AddMenu(1014, "Select All", 31);
          gui2D->AddMenu(1014, "Acknowledge", 1015);
            gui2D->AddMenu(1015, "Selection", 26);
            gui2D->AddMenu(1015, "All (Ctrl+K)", 47);
          gui2D->AddMenu(1014, "Toggle Detection", 48);
        gui2D->AddMenu(1001, "Packets", 1016);
          gui2D->AddMenu(1016, "Show All (U)", 50);
          gui2D->AddMenu(1016, "Protocol", 1017);
            if (objPrefs.ShowProtocol) gui2D->AddMenu(1017, "All", 51);
            if (objPrefs.ShowProtocol != IPPROTO_ICMP) gui2D->AddMenu(1017, "ICMP", 52);
            if (objPrefs.ShowProtocol != IPPROTO_TCP) gui2D->AddMenu(1017, "TCP", 53);
            if (objPrefs.ShowProtocol != IPPROTO_UDP) gui2D->AddMenu(1017, "UDP", 54);
            if (objPrefs.ShowProtocol != IPPROTO_ARP) gui2D->AddMenu(1017, "ARP", 55);
            gui2D->AddMenu(1017, "Other", 56);
          gui2D->AddMenu(1016, "Port", (objPrefs.ShowPort ? 1018 : 58));
            if (objPrefs.ShowPort)
            {
              gui2D->AddMenu(1018, "All", 57);
              gui2D->AddMenu(1018, "Enter", 58);
            }
          gui2D->AddMenu(1016, "Select Showing", 32);
          gui2D->AddMenu(1016, "Off (K)", 59);
        gui2D->AddMenu(1001, "Layout", 1019);
          gui2D->AddMenu(1019, "Restore", 1020);
            gui2D->AddMenu(1020, "File", 60);
            gui2D->AddMenu(1020, "Net 1", 61);
            gui2D->AddMenu(1020, "Net 2", 62);
            gui2D->AddMenu(1020, "Net 3", 63);
            gui2D->AddMenu(1020, "Net 4", 64);
          gui2D->AddMenu(1019, "Save", 1021);
            gui2D->AddMenu(1021, "File", 65);
            gui2D->AddMenu(1021, "Net 1", 66);
            gui2D->AddMenu(1021, "Net 2", 67);
            gui2D->AddMenu(1021, "Net 3", 68);
            gui2D->AddMenu(1021, "Net 4", 69);
          gui2D->AddMenu(1019, "Net Positions", 37);
          gui2D->AddMenu(1019, "Clear", 1022);
            gui2D->AddMenu(1022, "Confirm", 39);
        gui2D->AddMenu(1001, "View", 1023);
          gui2D->AddMenu(1023, "Recall", 1024);
            gui2D->AddMenu(1024, "Home (Ctrl+Home)", 70);
            gui2D->AddMenu(1024, "Pos 1 (Ctrl+F1)", 71);
            gui2D->AddMenu(1024, "Pos 2 (Ctrl+F2)", 72);
            gui2D->AddMenu(1024, "Pos 3 (Ctrl+F3)", 73);
            gui2D->AddMenu(1024, "Pos 4 (Ctrl+F4)", 74);
          gui2D->AddMenu(1023, "Save", 1025);
            gui2D->AddMenu(1025, "Pos 1", 75);
            gui2D->AddMenu(1025, "Pos 2", 76);
            gui2D->AddMenu(1025, "Pos 3", 77);
            gui2D->AddMenu(1025, "Pos 4", 78);
        gui2D->AddMenu(1001, "IP/Name", 1026);
          if (objPrefs.HostLabel != Label_Selection) gui2D->AddMenu(1026, "Show Selection", 80);
          if (objPrefs.HostLabel != Label_All) gui2D->AddMenu(1026, "Show All", 81);
          if (objPrefs.HostActive != Active_Label) gui2D->AddMenu(1026, "Show On-Active", 82);
          if (objPrefs.HostLabel != Label_Off) gui2D->AddMenu(1026, "Show Off", 83);
          gui2D->AddMenu(1026, "All Off", 84);
        gui2D->AddMenu(1001, "On-Active", 1027);
          if (objPrefs.HostActive != Active_Alert) gui2D->AddMenu(1027, "Alert", 85);
          if (objPrefs.HostActive != Active_Label) gui2D->AddMenu(1027, "Show IP/Name", 82);
          if (objPrefs.HostActive != Active_Show) gui2D->AddMenu(1027, "Show Host", 86);
          if (objPrefs.HostActive != Active_Select) gui2D->AddMenu(1027, "Select", 87);
          if (objPrefs.HostActive != Active_Nothing) gui2D->AddMenu(1027, "Do Nothing", 88);
        break;
    }
  }
}

//mouse button event
void buttonGL(unsigned char button, unsigned char down)
{
#ifdef __APPLE__
  if (!(SDL_GetWindowFlags(SDLWindow) & SDL_WINDOW_INPUT_FOCUS)) return;  //window focus fix
#endif
  if (button == SDL_BUTTON_LEFT)
  {
    unsigned short mods = SDL_GetModState();
    if (gui2D->On())  //if 2D GUI displayed
    {
      int valSelected = gui2D->MouseButton(!down);  //2D GUI object clicked
      if (down) mouseLeft = (valSelected && (valSelected <= GLUE_BAR_BOTTOM) ? valSelected : 0);  //2D GUI move
      else
      {
        if (valSelected >= GLUE_OK) processButton(valSelected, mods);  //process 2D GUI button selected
        else if (valSelected == GLUE_MENU_ITEM) processMenu(gui2D->GetSelected());
        mouseLeft = 0;
      }
    }
    else if (down)  //start selection box
    {
      boxX = mouseX;
      boxY = objPrefs.WinHeight - mouseY;
      mouseLeft = 1;
    }
    else if (mouseLeft)
    {
      if (!(mods & KMOD_CTRL)) objLL->SetHosts(4, 0, (objPrefs.HostActive == Active_Show));  //pHost->Selected
      int boxWidth = abs(boxX - mouseX) + 1, boxHeight = abs(boxY - (objPrefs.WinHeight - mouseY)) + 1, numRGB = boxWidth * boxHeight * 3;
      unsigned int numHost;
      unsigned char *pRGB = new unsigned char [numRGB];
      obj_host *pHost;
      if ((boxWidth < 5) && (boxHeight < 5))
      {
        objLL->DrawPick(true, (objPrefs.HostActive != Active_Show));
        glReadPixels(boxX, boxY, 1, 1, GL_RGB, GL_UNSIGNED_BYTE, pRGB);
        numHost = (unsigned int)(pRGB[0] + (pRGB[1] << 8) + (pRGB[2] << 16));
        if (numHost)
        {
          if (numHost == 1)  //selected host
          {
            if (objLL->SelectedHost->Cluster)
            {
              objLL->SelectedHost->Selected = 0;
              objLL->SelectedHost = objLL->SelectedHost->Cluster;  //cycle thru hosts in cluster
              objLL->SelectedHost->Selected = 1;
              objLL->InfoSelected(strHost);
            }
            else if (objLL->SelectedHost->Label)
            {
              objLL->SelectedHost->Selected = 0;
              objLL->SelectedHost->Label = 0;
              objLL->SelectedHost = 0;
            }
            else
            {
              objLL->SelectedHost->Selected = 1;
              objLL->SelectedHost->Label = 1;  //activate persistant IP
            }
          }
          else
          {
            objLL->SelectedHost = (obj_host *)objLL->HostsLL.Find(numHost - 1);
            if (objLL->SelectedHost->Selected)
            {
              objLL->SelectedHost->Selected = 0;
              if (objLL->SelectedHost->Cluster)  //deselect all in cluster
              {
                for (pHost = objLL->SelectedHost->Cluster; pHost != objLL->SelectedHost; pHost = pHost->Cluster) pHost->Selected = 0;
              }
              objLL->SelectedHost = 0;
            }
            else
            {
              objLL->SelectedHost->Selected = 1;
              objLL->InfoSelected(strHost);
            }
          }
        }
        else objLL->SelectedHost = 0;
      }
      else
      {
        int startX = (boxX < mouseX ? boxX : mouseX), startY = (boxY < (objPrefs.WinHeight - mouseY) ? boxY : objPrefs.WinHeight - mouseY), cntHits, cntRGB;
        unsigned int lastHit = 0;
        do {
          cntHits = 0;
          objLL->DrawPick(false, (objPrefs.HostActive != Active_Show));
          glReadPixels(startX, startY, boxWidth, boxHeight, GL_RGB, GL_UNSIGNED_BYTE, pRGB);
          for (cntRGB = 0; cntRGB < numRGB; cntRGB += 3)
          {
            numHost = (unsigned int)(pRGB[cntRGB] + (pRGB[cntRGB + 1] << 8) + (pRGB[cntRGB + 2] << 16));
            if (numHost && (numHost != lastHit))
            {
              if (numHost == 1) objLL->SelectedHost->Selected = 1;
              else
              {
                pHost = (obj_host *)objLL->HostsLL.Find(numHost - 1);
                pHost->Selected = 1;
              }
              lastHit = numHost;
              cntHits++;
            }
          }
        } while (cntHits);
        objLL->SelectedHost = 0;
      }
      delete[] pRGB;
      mouseLeft = 0;
    }
  }
  else if (button == SDL_BUTTON_MIDDLE) mouseMiddle = down;  //start move view
  else if ((button == SDL_BUTTON_RIGHT) && !gui2D->On()) processMenu(1000);
  goRefresh = true;
}

//mouse wheel event
void wheelGL(int y)
{
  if (gui2D->On()) gui2D->Scroll((y > 0 ? GLUE_SCROLL_UP : GLUE_SCROLL_DOWN));  //scroll text in 2D GUI
  else objPrefs.ViewSpot[0].Y += y * MOVE_SIZE;  //move view up/down
  goRefresh = true;
}

//mouse motion event
void motionGL(int x, int y)
{
  gui2D->MouseMotion(x, objPrefs.WinHeight - y);
  if (mouseLeft || mouseMiddle)
  {
    if (mouseMiddle)  //move view
    {
      objPrefs.ViewSpot[0].AngleX += (x - mouseX) * 0.3;
      objPrefs.ViewSpot[0].AngleY += (y - mouseY) * 0.3;
      if (objPrefs.ViewSpot[0].AngleX > 180.0) objPrefs.ViewSpot[0].AngleX -= 360.0;
      else if (objPrefs.ViewSpot[0].AngleX < -180.0) objPrefs.ViewSpot[0].AngleX += 360.0;
      if (objPrefs.ViewSpot[0].AngleY > 180.0) objPrefs.ViewSpot[0].AngleY -= 360.0;
      else if (objPrefs.ViewSpot[0].AngleY < -180.0) objPrefs.ViewSpot[0].AngleY += 360.0;
    }
    else if (gui2D->On()) gui2D->MouseMove(mouseLeft, x - mouseX, y - mouseY);  //2D GUI mouse move object
    goRefresh = true;
  }
  mouseX = x;
  mouseY = y;
}

//load preferences
void loadPrefs()
{
  char strPath[4096];
  FILE *filePrefs;
  if ((filePrefs = fopen(getPath("packet0_prefs", strPath), "rb")))
  {
    fseek(filePrefs , 0 , SEEK_END);
    if (ftell(filePrefs) == sizeof(obj_prefs))
    {
      rewind(filePrefs);
      if (fread(&objPrefs, sizeof(obj_prefs), 1, filePrefs) == 1)
      {
        if (!strcmp(objPrefs.Version, "0PF0"))
        {
          fclose(filePrefs);
          return;
        }
      }
    }
    fclose(filePrefs);
    remove(strPath);
  }
}

//save preferences
void savePrefs()
{
  char strPath[4096];
  FILE *filePrefs;
  if ((filePrefs = fopen(getPath("packet0_prefs", strPath), "wb")))
  {
    if (fwrite(&objPrefs, sizeof(obj_prefs), 1, filePrefs) != 1)
    {
      fclose(filePrefs);
      remove(strPath);
      return;
    }
    fclose(filePrefs);
  }
}

//packet gatherer
void *processPacket(void *arg)
{
  if (arg) return 0;  //remove unused parameter warning
  int sockSensors;  //sensors UDP socket
  sockaddr_in addrSensors;  //sensors listening address
  addrSensors.sin_family = AF_INET;
  addrSensors.sin_addr.s_addr = INADDR_ANY;
  addrSensors.sin_port = htons(objPrefs.SensorPort);
  if ((sockSensors = socket(PF_INET, SOCK_DGRAM, IPPROTO_UDP)) == -1)
  {
    syslog(LOG_WARNING, "socket create failed, continuing\n");
  }
  else if (bind(sockSensors, (sockaddr *)&addrSensors, sizeof(sockaddr_in)) == -1)
  {
    syslog(LOG_WARNING, "socket bind failed, continuing\n");
    close(sockSensors);
  }
  fcntl(sockSensors, F_SETFL, O_NONBLOCK);
  enum packet_source { Source_None, Source_File, Source_Socket };
  packet_source packetSource;
  packet_info *packetInfo = 0;
  packet_xtra *packetXtra = 0;  //packet info from sensor
  packet_dns *packetDNS;  //DNS info from sensor
  timeval timePacket;
  size_t szTime = sizeof(timeval);
  ssize_t szRecv;
  in_addr_t netMask, netAddress;
  unsigned long long timeReplay;
  char packetBuffer[PKT_DNS_SIZE];
  obj_host *pHost, *pDstHost;
  while (goRun)
  {
    packetSource = Source_None;
    if (packetTraffic == Traffic_Halt)
    {
      fclose(fileTraffic);
      packetTraffic = Traffic_Stop;
    }
    if (packetTraffic == Traffic_Replay)
    {
      timeReplay = milliTime(0) - timeOffset;
      if (replayPacket.Time.tv_sec && (timeReplay >= milliTime(&replayPacket.Time)))
      {
        packetInfo = &replayPacket.PacketInfo;
        packetSource = Source_File;
      }
      else if (!replayPacket.Time.tv_sec && !objLL->Packets()) packetTraffic = Traffic_Halt;  //stop replay when last packet ends
    }
    else if ((szRecv = recv(sockSensors, packetBuffer, PKT_DNS_SIZE, 0)) > 0)  //received UDP packet
    {
      if ((packetBuffer[0] == 85) && (szRecv == (ssize_t)PKT_XTRA_SIZE))  //85 used to identify packet info
      {
        packetXtra = (packet_xtra *)packetBuffer;
        packetInfo = &packetXtra->PacketInfo;
        packetSource = Source_Socket;
        if (packetTraffic == Traffic_Record)  //record packet
        {
          if (!timeOffset) timeOffset = milliTime(0);
          gettimeofday(&timePacket, 0);
          if (fwrite(&timePacket, szTime, 1, fileTraffic) != 1) packetTraffic = Traffic_Halt;
          else if (fwrite(packetInfo, PKT_INFO_SIZE, 1, fileTraffic) != 1) packetTraffic = Traffic_Halt;
        }
      }
      else if ((packetBuffer[0] == 42) && (szRecv == (ssize_t)PKT_DNS_SIZE))  //42 used to identify DNS info
      {
        packetDNS = (packet_dns *)packetBuffer;
        if ((pHost = objLL->GetHost(2, packetDNS->HostIP, false, 0)))
        {
          if (*pHost->Hostname == '\0') strncat(pHost->Hostname, packetDNS->Hostname, 255);
          objLL->HostsLL.Free(2);
        }
      }
    }
    if (packetSource)
    {
      pHost = objLL->GetHost(2, packetInfo->SrcIP, true, &objPrefs);
      if (packetSource == Source_Socket)
      {
        pHost->LastSensor = packetInfo->Sensor;
        pHost->Uploads += packetXtra->Bytes;
        time(&pHost->LastPacket);
        if (*pHost->HostMAC == '\0') sprintf(pHost->HostMAC, "%02X:%02X:%02X:%02X:%02X:%02X", packetXtra->SrcMAC[0], packetXtra->SrcMAC[1], packetXtra->SrcMAC[2], packetXtra->SrcMAC[3]
          , packetXtra->SrcMAC[4], packetXtra->SrcMAC[5]);
        if (!((((packetInfo->Protocol == IPPROTO_TCP) || (packetInfo->Protocol == IPPROTO_UDP)) && !packetXtra->Service)))  //true if other protocol
          objLL->AddService(pHost, (packetInfo->SrcPort * 10000) + (packetInfo->Protocol * 10), objPrefs.AnomDetect);
      }
      if ((pDstHost = objLL->GetHost(3, packetInfo->DstIP, objPrefs.DstHosts, &objPrefs)))
      {
        if (packetSource == Source_Socket)
        {
          pDstHost->LastSensor = packetInfo->Sensor;
          pDstHost->Downloads += packetXtra->Bytes;
          time(&pDstHost->LastPacket);
        }
        objLL->CreatePacket(packetInfo, pHost, pDstHost, true, &objPrefs);
        objLL->HostsLL.Free(3);
      }
      else if (objPrefs.Broadcasts && (netMask = objLL->IsBroadcast(packetInfo->DstIP)))
      {
        netAddress = packetInfo->DstIP.s_addr & netMask;
        objLL->HostsLL.Start(3);
        while ((pDstHost = (obj_host *)objLL->HostsLL.Read(3)))
        {
          if ((pDstHost != pHost) && ((pDstHost->HostIP.s_addr & netMask) == netAddress)) objLL->CreatePacket(packetInfo, pHost, pDstHost, false, &objPrefs);
          objLL->HostsLL.Next(3);
        }
      }
      objLL->HostsLL.Free(2);
      if (packetSource == Source_File)
      {
        if (fread(&replayPacket, PKT_TIME_SIZE, 1, fileTraffic) != 1) replayPacket.Time.tv_sec = 0;
      }
    }
    else usleep(1000);
  }
  close(sockSensors);
  if (packetTraffic) fclose(fileTraffic);
  return 0;
}

int main()
{
  syslog(LOG_INFO, "started\n");
  if (SDL_Init(SDL_INIT_VIDEO) < 0)
  {
    syslog(LOG_ERR, "SDL_Init() failed: %s\n", SDL_GetError());
    return 1;
  }
  loadPrefs();  //load preferences
  SDLWindow = SDL_CreateWindow("PacketZero", objPrefs.WinX, objPrefs.WinY, objPrefs.WinWidth, objPrefs.WinHeight, SDL_WINDOW_OPENGL | SDL_WINDOW_RESIZABLE);
  if (!SDLWindow)
  {
    syslog(LOG_ERR, "SDL_CreateWindow() failed: %s\n", SDL_GetError());
    SDL_Quit();
    return 1;
  }
  SDLCursor_ARROW = SDL_CreateSystemCursor(SDL_SYSTEM_CURSOR_ARROW);
  SDLCursor_IBEAM = SDL_CreateSystemCursor(SDL_SYSTEM_CURSOR_IBEAM);
  SDLCursor_CROSSHAIR = SDL_CreateSystemCursor(SDL_SYSTEM_CURSOR_CROSSHAIR);
  SDLCursor_SIZENWSE = SDL_CreateSystemCursor(SDL_SYSTEM_CURSOR_SIZENWSE);
  SDLCursor_SIZEWE = SDL_CreateSystemCursor(SDL_SYSTEM_CURSOR_SIZEWE);
  SDLCursor_SIZENS = SDL_CreateSystemCursor(SDL_SYSTEM_CURSOR_SIZENS);
  SDLCursor_HAND = SDL_CreateSystemCursor(SDL_SYSTEM_CURSOR_HAND);
  SDL_GLContext SDLContext = SDL_GL_CreateContext(SDLWindow);
  if (!SDLContext)
  {
    syslog(LOG_ERR, "SDL_GL_CreateContext() failed: %s\n", SDL_GetError());
    SDL_DestroyWindow(SDLWindow);
    SDL_Quit();
    return 1;
  }
  char strPath[4096];
  checkControls(strPath);  //check for controls file, create it & data directory
  glEnable(GL_DEPTH_TEST);
  glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
  glReadBuffer(GL_BACK);
  glPixelStorei(GL_PACK_ALIGNMENT, 1);
  objLL = new Objects;
  gui2D = new GLue;
  initFont();
  if (objPrefs.Font == -1)
  {
    SDL_DisplayMode SDLDisplay;
    if (!SDL_GetCurrentDisplayMode(0, &SDLDisplay)) objPrefs.Font = (SDLDisplay.w > 1920 ? 1 : 0);  //set large font size based on display width
    else objPrefs.Font = 0;
  }
  setFont(objPrefs.Font);
  objLL->LoadNetPos(getPath("netpos.txt", strPath));  //load netpos
  objLL->LoadNet(getPath("0network_0nl", strPath));  //load network layout 0
  resizeGL(objPrefs.WinWidth, objPrefs.WinHeight);
  updateOSD();
  bool goAnimate, goSecond;
  int keyDown = 0;
  unsigned long long timeFrame = 0, cntFrame = 0;
  SDL_Event SDLEvent;
  pthread_t oPthread;
  pthread_create(&oPthread, 0, processPacket, 0);  //sensor packet thread
  signal(SIGINT, stopRun);  //capture ctrl+c
  signal(SIGTERM, stopRun);  //capture kill
  while (goRun)
  {
    goAnimate = false;
    goSecond = false;
    while (SDL_PollEvent(&SDLEvent))
    {
      switch (SDLEvent.type)
      {
        case SDL_KEYDOWN:
          if (!gui2D->On() && (SDLEvent.key.keysym.sym >= GL_KEY_RIGHT) && (SDLEvent.key.keysym.sym <= GL_KEY_UP))
          {
            switch (SDLEvent.key.keysym.sym)
            {
              case GL_KEY_UP: keyDown |= 1; break;
              case GL_KEY_DOWN: keyDown |= 2; break;
              case GL_KEY_LEFT: keyDown |= 4; break;
              case GL_KEY_RIGHT: keyDown |= 8; break;
            }
          }
          else keyboardGL(SDLEvent.key.keysym.sym);
          break;
        case SDL_KEYUP:
          if (!gui2D->On() && (SDLEvent.key.keysym.sym >= GL_KEY_RIGHT) && (SDLEvent.key.keysym.sym <= GL_KEY_UP))
          {
            switch (SDLEvent.key.keysym.sym)
            {
              case GL_KEY_UP: keyDown &= 14; break;
              case GL_KEY_DOWN: keyDown &= 13; break;
              case GL_KEY_LEFT: keyDown &= 11; break;
              case GL_KEY_RIGHT: keyDown &= 7; break;
            }
          }
          break;
        case SDL_MOUSEBUTTONDOWN: case SDL_MOUSEBUTTONUP: buttonGL(SDLEvent.button.button, SDLEvent.button.state); break;
        case SDL_MOUSEMOTION: motionGL(SDLEvent.motion.x, SDLEvent.motion.y); break;
        case SDL_MOUSEWHEEL: wheelGL(SDLEvent.wheel.y); break;
        case SDL_WINDOWEVENT:
          if (SDLEvent.window.event == SDL_WINDOWEVENT_MOVED)
          {
            objPrefs.WinX = SDLEvent.window.data1;
            objPrefs.WinY = SDLEvent.window.data2;
          }
          else if (SDLEvent.window.event == SDL_WINDOWEVENT_RESIZED) resizeGL(SDLEvent.window.data1, SDLEvent.window.data2);
          break;
        case SDL_QUIT: goRun = false; break;
      }
    }
    if ((milliTime(0) - timeFrame) > 32)  //30.3 FPS
    {
#ifdef __APPLE__
      if (!(SDL_GetWindowFlags(SDLWindow) & SDL_WINDOW_INPUT_FOCUS)) keyDown = 0;  //window focus fix
#endif
      if (keyDown & 1) keyboardGL(GL_KEY_UP);
      if (keyDown & 2) keyboardGL(GL_KEY_DOWN);
      if (keyDown & 4) keyboardGL(GL_KEY_LEFT);
      if (keyDown & 8) keyboardGL(GL_KEY_RIGHT);
      if (!(++cntFrame % 30)) goSecond = true;
      if (canAnimate && (objLL->Packets() || objLL->Alerts() || goSecond)) goAnimate = true;
      else if (goSecond || gui2D->On() || (packetTraffic > Traffic_Halt)) goRefresh = true;
      timeFrame = milliTime(0);
    }
    if (goRefresh || goAnimate) displayGL(goAnimate, goSecond);
    else usleep(1000);
  }
  syslog(LOG_INFO, "stopping...\n");
  pthread_join(oPthread, 0);  //wait for thread to exit
  objLL->SaveNet(strPath);  //save network layout 0, 0network_0nl
  savePrefs();  //save preferences
  destroyFont();
  SDL_GL_DeleteContext(SDLContext);
  SDL_FreeCursor(SDLCursor_ARROW);
  SDL_FreeCursor(SDLCursor_IBEAM);
  SDL_FreeCursor(SDLCursor_CROSSHAIR);
  SDL_FreeCursor(SDLCursor_SIZENWSE);
  SDL_FreeCursor(SDLCursor_SIZEWE);
  SDL_FreeCursor(SDLCursor_SIZENS);
  SDL_FreeCursor(SDLCursor_HAND);
  SDL_DestroyWindow(SDLWindow);
  SDL_Quit();
  delete gui2D;
  delete objLL;
  syslog(LOG_INFO, "stopped\n");
  return 0;
}
