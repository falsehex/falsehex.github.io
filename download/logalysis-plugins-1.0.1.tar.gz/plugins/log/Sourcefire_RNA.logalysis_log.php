<?php

$link = logalysis_db_connect();

if (empty($nohdr)) echo "<h4>SOURCEFIRE RNA</h4>";
echo "<table class='esort'>";
echo "<tr><th></th><th>First</th><th>Last</th><th>Protocol</th><th>Source IP</th><th>Port</th><th>Target IP</th><th>Port</th><th>Packets TX</th><th>Packets RX</th><th>Bytes TX</th><th>Bytes RX</th><th>Application</th><th>Version</th><th>Service</th></tr>";
$count = 0;
$result = mysqli_query($link, "SELECT time_1, time_2, protocol, source_ip, source_port, target_ip, target_port, num_1, num_2, num_3, num_4, char_3_255, char_4_255, char_5_255 FROM events WHERE log_id = {$log_id} ORDER BY time_1");
while ($row = mysqli_fetch_row($result))
{
  echo "<tr onclick='txtBold(this.style);'><td>" . ++$count . "</td>";
  $row[2] = protocol_name($row[2]);
  $row[3] = "<a class='action' href='javascript:popUp(\"host_show.php?host_ip={$row[3]}\");'>{$row[3]}</a>";
  $row[5] = "<a class='action' href='javascript:popUp(\"host_show.php?host_ip={$row[5]}\");'>{$row[5]}</a>";
  $row[9] = format_bytes($row[9]);
  $row[10] = format_bytes($row[10]);
  foreach ($row as &$cell) echo "<td>{$cell}</td>";
  echo "</tr>";
}
mysqli_free_result($result);
echo "</table>";

mysqli_close($link);

?>
