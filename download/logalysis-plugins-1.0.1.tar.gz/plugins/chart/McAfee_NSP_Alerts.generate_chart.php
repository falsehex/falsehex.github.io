<?php

include "plugins/cred/mcafee_nsp.cred.php";

$link = mysqli_connect($mcafee_nsp_db_host, $mcafee_nsp_db_user, $mcafee_nsp_db_pass, $mcafee_nsp_db_name);
if (!$link) die("Error: mysql db {$mcafee_nsp_db_name} connect failed");

if (!isset($shape)) $shape = (isset($_POST["shape"]) ? $_POST["shape"] : "");
if (!isset($blocked)) $blocked = (isset($_POST["blocked"]) ? $_POST["blocked"] : 0);
if (!isset($show_vals)) $show_vals = (isset($_POST["show_vals"]) ? $_POST["show_vals"] : "");

$table = "<table id='mcafee_nsp_alerts_{$shape}_{$blocked}_table' class='chart'><tr><th class='chart'></th><th class='chart'>Alert</th><th class='chart'>Events</th></tr>";
$count = 0;
$extra = " WHERE alertDuration = 0";
if ($start_time) $extra .= " AND creationTime >= '{$start_time}'";
if ($finish_time) $extra .= " AND creationTime <= '{$finish_time}'";
if ($blocked) $extra .= " AND resultSetValue " . ($blocked == "yes" ? ">" : "<") . " 700";
$result = mysqli_query($link, "SELECT attackIdRef, COUNT(1) FROM iv_alert{$extra} GROUP BY attackIdRef ORDER BY COUNT(1) DESC LIMIT {$limit}");
while ($row = mysqli_fetch_row($result))
{
  $row[0] = db_result($link, "SELECT name FROM iv_attack WHERE id = '{$row[0]}'") . (empty($nohdr) ? " ({$row[0]})" : "");
  $table .= "<tr><td class='chart'>" . ++$count . "</td>";
  foreach ($row as &$cell) $table .= "<td class='chart'>{$cell}</td>";
  $table .= "</tr>";
}
mysqli_free_result($result);
$table .= "</table>";
if ($count)
{
  if (empty($nohdr)) echo "<h4>MCAFEE NSP TOP {$limit} ALERTS<br />" . ($start_time ? date("d-m-Y H:i:s", strtotime($start_time)) . " -" : "") . ($finish_time ? "- " . date("d-m-Y H:i:s", strtotime($finish_time)) : "") . "</h4>";
  if (empty($nogfx)) echo "<canvas id='mcafee_nsp_alerts_{$shape}_{$blocked}_canvas' width='640' height='320' ondblclick='window.open(this.toDataURL());'></canvas>";
  echo $table;

  if (empty($nogfx)) echo "<script type='text/javascript'>{$shape}Chart(\"mcafee_nsp_alerts_{$shape}_{$blocked}\", 0, 2" . ($shape == "vbar" ? ", \"{$show_vals}\"" : "") . ");</script>";
}
else echo "<h5>NO EVENTS FOUND!</h5>";

mysqli_close($link);

?>
