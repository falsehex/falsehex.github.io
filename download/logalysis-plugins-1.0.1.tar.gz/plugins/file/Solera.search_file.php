<?php

search_time($search[1], $search[2]);
echo "<p>IP / TCP Port<br /><input type='text' name='search_3' size='17' maxlength='15' value='{$search[3]}' />";
echo "<input type='text' name='search_4' size='7' maxlength='5' value='{$search[4]}' /><br />";
echo "IP / TCP Port<br /><input type='text' name='search_5' size='17' maxlength='15' value='{$search[5]}' />";
echo "<input type='text' name='search_6' size='7' maxlength='5' value='{$search[6]}' /></p>";

?>
