/* sensor0.cpp - 01 Sep 15
   PacketZero - 3D Network Monitor
   Copyright 2006-2015 Del Castle  */

#include <pcap.h>
#include <stdlib.h>
#include <string.h>
#ifdef _MSC_VER
#include <winsock2.h>
#pragma comment(lib, "Ws2_32.lib")
#else
#include <arpa/inet.h>
#include <signal.h>
#include <sys/stat.h>
#include <syslog.h>
#include <unistd.h>
#endif

#include "protocol.h"
#include "udptrack.h"

#ifndef _MSC_VER
bool replayPcap = false;
unsigned long long timeNow, timeRelative, timeOffset = 0;  //pcap replay time offset
#endif
int datalinkPcap, sockPacket0;  //packet0 UDP socket
sockaddr_in addrPacket0;  //packet0 IP/broadcast address
pcap_t *pPcap;
UDPTrack *udpTrack;

//prototypes
void stopRun(int sig);
void showUsage(char *command);
unsigned long long microTime(const timeval *val);
void dnsResponse(char *data, char *name, in_addr *ip, unsigned int len);
void processPacket(u_char *u, const struct pcap_pkthdr *hdr, const u_char *pkt);

//close application
void stopRun(int sig)
{
#ifndef _MSC_VER
  syslog(LOG_INFO, "sig %d - stopping...\n", sig);
#endif
  if (sig) pcap_breakloop(pPcap);
}

//show usage
void showUsage(char *command)
{
#ifdef _MSC_VER
  fprintf(stderr, "sensor0 1.0.1 usage: %s [[[<id>] <destination>] <port>] [-p]\n"
    "  <id> : identify packets from a specific sensor when multiple exist (1-255, default 1)\n"
    "  <destination> : PacketZero IP or broadcast address (default localhost)\n"
    "  <port> : PacketZero UDP port (default 6333)\n"
    "  -p : enable promiscuous mode\n", command);
#else
  fprintf(stderr, "sensor0 1.0.1 usage: %s [-i <interface/file>] [-s <id>] [-h <destination>] [-u <port>] [-p] [-d]\n"
    "  -i <interface> : listen on interface (en0, eth1, ppp0, wlan0, etc.); or\n"
    "     <file> : read packets from pcap file, '-' for stdin\n"
    "  -s <id> : identify packets from a specific sensor when multiple exist (1-255, default 1)\n"
    "  -h <destination> : PacketZero IP or broadcast address (default localhost)\n"
    "  -u <port> : PacketZero UDP port (default 6333)\n"
    "  -p : enable promiscuous mode\n"
    "  -d : run as daemon\n", command);
#endif
}

#ifndef _MSC_VER
//convert timeval to time in microseconds
unsigned long long microTime(const timeval *val)
{
  if (val) return (unsigned long long)((val->tv_sec * 1000000) + val->tv_usec);
  timeval timeCurrent;
  gettimeofday(&timeCurrent, 0);  //current time
  return (unsigned long long)((timeCurrent.tv_sec * 1000000) + timeCurrent.tv_usec);
}
#endif

//get hostname and IP address from type A class IN standard query response DNS packet payload
void dnsResponse(char *data, char *name, in_addr *ip, unsigned int len)
{
  if (!len) return;  //no data
  int cntLabel;
  while (*data)
  {
    for (cntLabel = *data; cntLabel; cntLabel--)  //3www6google3com0
    {
      if (!--len) return;  //out of data
      data++;
      if (strlen(name) == 255) return;  //buffer overflow check
      strncat(name, data, 1);
    }
    if (!--len) return;  //out of data
    data++;
    if (*data && (strlen(name) < 254)) strncat(name, ".", 1);
  }
  data++;
  dns_tail *dnsTail = (dns_tail *)data;
  if ((*name != '\0') && (ntohs(dnsTail->qtype) == 1) && (ntohs(dnsTail->qclas) == 1) && (ntohs(dnsTail->type) == 1) && (ntohs(dnsTail->clas) == 1)) ip->s_addr = dnsTail->addr.s_addr;
}

//pcap_loop
void processPacket(u_char *u, const struct pcap_pkthdr *hdr, const u_char *pkt)
{
#ifndef _MSC_VER
  if (replayPcap)
  {
    timeNow = microTime(0);
    if (!timeOffset) timeOffset = timeNow - microTime(&hdr->ts);
    timeRelative = microTime(&hdr->ts) + timeOffset;
    if (timeRelative > timeNow) usleep((useconds_t)(timeRelative - timeNow));
  }
#endif
  bool isARP = false;
  unsigned int capBytes = hdr->caplen;
  packet_xtra packetXtra = {85, false, {0, 0, 0, 0, 0, 0}, 0, {{0}, {0}, 0, 0, *u, 0}};  //85 used to identify packet info
  if (capBytes < IP_HDR_SIZE) return;  //malformed packet check
  if (datalinkPcap == DLT_EN10MB)
  {
    ether_header *hdrEther = (ether_header *)pkt;
    memcpy(&packetXtra.SrcMAC, &hdrEther->ether_shost, 6);
    if (ntohs(hdrEther->ether_type) == ETHERTYPE_VLAN)  //802.1Q VLAN
    {
      pkt += 4;  //sizeof 802.1Q VLAN header
      capBytes -= 4;
      hdrEther = (ether_header *)pkt;
    }
    if (ntohs(hdrEther->ether_type) == ETHERTYPE_IP)
    {
      pkt += ETHER_HDR_SIZE;
      capBytes -= ETHER_HDR_SIZE;
    }
    else if (ntohs(hdrEther->ether_type) == ETHERTYPE_ARP)
    {
      if (capBytes < ARP_HDR_SIZE) return;  //malformed packet check
      ether_arp *hdrARP = (ether_arp *)(pkt + ETHER_HDR_SIZE);
      memcpy(&packetXtra.PacketInfo.SrcIP, &hdrARP->arp_spa, 4);
      memcpy(&packetXtra.PacketInfo.DstIP, &hdrARP->arp_tpa, 4);
      packetXtra.PacketInfo.Protocol = IPPROTO_ARP;
      isARP = true;
    }
    else return;
  }
  else if (datalinkPcap == DLT_LINUX_SLL)
  {
    sll_header *hdrSLL = (sll_header *)pkt;
    if (ntohs(hdrSLL->sll_halen) == 6) memcpy(&packetXtra.SrcMAC, &hdrSLL->sll_addr, 6);
    if (ntohs(hdrSLL->sll_protocol) == ETHERTYPE_IP)
    {
      pkt += SLL_HDR_SIZE;
      capBytes -= SLL_HDR_SIZE;
    }
    else return;
  }
  else if (datalinkPcap == DLT_PPP)
  {
    ppp_header *hdrPPP = (ppp_header *)pkt;
    if (ntohs(hdrPPP->ppp_protocol) == 0x21)  //IPv4
    {
      pkt += PPP_HDR_SIZE;
      capBytes -= PPP_HDR_SIZE;
    }
    else return;
  }
  if (!isARP)
  {
    if (capBytes < IP_HDR_SIZE) return;  //malformed packet check
    iphdr *hdrIP = (iphdr *)pkt;
    if (hdrIP->version != 4) return;  //not IPv4
    if (hdrIP->ihl != 5) return;  //IPv4 options check
    unsigned short isFrag = (unsigned short)(ntohs(hdrIP->frag_off) << 3);
    if (hdrIP->protocol == IPPROTO_GRE)  //generic routing encapsulation
    {
      if (isFrag) return;  //fragmented packet check
      if (capBytes < GRE_TAIL_SIZE) return;  //malformed packet check
      gre_hdr *hdrGRE = (gre_hdr *)(pkt + IP_HDR_SIZE);
      if (hdrGRE->crks) return;  //GRE options check
      if (ntohs(hdrGRE->type) != ETHERTYPE_IP) return;  //not IP
      pkt += GRE_HDR_SIZE;
      capBytes -= GRE_HDR_SIZE;
      hdrIP = (iphdr *)pkt;
      if (hdrIP->version != 4) return;  //not IPv4
      if (hdrIP->ihl != 5) return;  //IPv4 options check
      isFrag = (unsigned short)(ntohs(hdrIP->frag_off) << 3);
    }
    packetXtra.Bytes = ntohs(hdrIP->tot_len);
    packetXtra.PacketInfo.SrcIP.s_addr = hdrIP->saddr;
    packetXtra.PacketInfo.DstIP.s_addr = hdrIP->daddr;
    if (isFrag) packetXtra.PacketInfo.Protocol = IPPROTO_FRAG;
    else packetXtra.PacketInfo.Protocol = hdrIP->protocol;
    if (packetXtra.PacketInfo.Protocol == IPPROTO_TCP)
    {
      if (capBytes >= TCP_HDR_SIZE)
      {
        tcphdr *hdrTCP = (tcphdr *)(pkt + IP_HDR_SIZE);
        if (hdrTCP->syn && hdrTCP->ack) packetXtra.Service = true;
        packetXtra.PacketInfo.SrcPort = ntohs(hdrTCP->source);
        packetXtra.PacketInfo.DstPort = ntohs(hdrTCP->dest);
      }
      else packetXtra.PacketInfo.Protocol = IPPROTO_FRAG;
    }
    else if (packetXtra.PacketInfo.Protocol == IPPROTO_UDP)
    {
      if (capBytes >= UDP_HDR_SIZE)
      {
        udphdr *hdrUDP = (udphdr *)(pkt + IP_HDR_SIZE);
        if (udpTrack->Kind(&packetXtra.PacketInfo) == UDP_Service) packetXtra.Service = true;  //ACK used to identify service
        packetXtra.PacketInfo.SrcPort = ntohs(hdrUDP->source);
        packetXtra.PacketInfo.DstPort = ntohs(hdrUDP->dest);
        if ((packetXtra.PacketInfo.SrcPort == 53) && (capBytes > DNS_TAIL_SIZE))  //port 53 DNS, malformed packet check
        {
          HEADER *hdrDNS = (HEADER *)(pkt + UDP_HDR_SIZE);
          if ((hdrDNS->qr == 1) && !hdrDNS->opcode && !hdrDNS->rcode && (ntohs(hdrDNS->qdcount) == 1) && (ntohs(hdrDNS->ancount) == 1))
          {
            packet_dns packetDNS = {42, "", {0}};  //42 used to identify DNS info
            char *dnsData = (char *)(pkt + DNS_HDR_SIZE);
            dnsResponse(dnsData, packetDNS.Hostname, &packetDNS.HostIP, capBytes - DNS_TAIL_SIZE);
            if (packetDNS.HostIP.s_addr)
            {
#ifdef _MSC_VER
              if (sendto(sockPacket0, (const char *)&packetDNS, PKT_DNS_SIZE, 0, (sockaddr *)&addrPacket0, SOCK_ADDR_SIZE) != PKT_DNS_SIZE)  //send DNS info to packet0
              {
#else
              if (sendto(sockPacket0, &packetDNS, PKT_DNS_SIZE, 0, (sockaddr *)&addrPacket0, SOCK_ADDR_SIZE) != (ssize_t)PKT_DNS_SIZE)  //send DNS info to packet0
              {
                syslog(LOG_ERR, "socket send failed (dns info)\n");
#endif
                stopRun(2);  //SIGINT
              }
            }
          }
        }
      }
      else packetXtra.PacketInfo.Protocol = IPPROTO_FRAG;
    }
  }
#ifdef _MSC_VER
  if (sendto(sockPacket0, (const char *)&packetXtra, PKT_XTRA_SIZE, 0, (sockaddr *)&addrPacket0, SOCK_ADDR_SIZE) != PKT_XTRA_SIZE)  //send packet info to packet0
  {
#else
  if (sendto(sockPacket0, &packetXtra, PKT_XTRA_SIZE, 0, (sockaddr *)&addrPacket0, SOCK_ADDR_SIZE) != (ssize_t)PKT_XTRA_SIZE)  //send packet info to packet0
  {
    syslog(LOG_ERR, "socket send failed (pkt info)\n");
#endif
    stopRun(2);  //SIGINT
  }
}

int main(int argc, char *argv[])
{
  unsigned char sensorId = 1;
  unsigned short dstPort = 6333;
  int goPromisc = 0;
  char strInfile[256] = "", strDestination[256] = "";
#ifdef _MSC_VER
  if (argc > 1)
  {
    if (!strcmp(argv[argc - 1], "-p"))
    {
      goPromisc = 1;
      argc--;
    }
    switch (argc)
    {
      case 4:
        if ((atoi(argv[3]) >= 1) && (atoi(argv[3]) <= 65535)) dstPort = (unsigned short)atoi(argv[3]);
        else
        {
          fprintf(stderr, "sensor0 error: port out of range (1-65535)\n");
          showUsage(argv[0]);
          return 1;
        }
      case 3: strncat(strDestination, argv[2], 255);
      case 2:
        if ((atoi(argv[1]) >= 1) && (atoi(argv[1]) <= 255)) sensorId = (unsigned char)atoi(argv[1]);
        else
        {
          fprintf(stderr, "sensor0 error: id out of range (1-255)\n");
          showUsage(argv[0]);
          return 1;
        }
      case 1: break;
      default:
        showUsage(argv[0]);
        return 1;
    }
  }
#else
  bool goDaemon = false;
  int argOpt;
  while ((argOpt = getopt(argc, argv, "i:s:h:u:pd")) != -1)
  {
    switch (argOpt)
    {
      case 'i': strncat(strInfile, optarg, 255); break;
      case 's':
        if ((atoi(optarg) >= 1) && (atoi(optarg) <= 255)) sensorId = (unsigned char)atoi(optarg);
        else
        {
          fprintf(stderr, "sensor0 error: id out of range (1-255)\n");
          showUsage(argv[0]);
          return 1;
        }
        break;
      case 'h': strncat(strDestination, optarg, 255); break;
      case 'u':
        if ((atoi(optarg) >= 1) && (atoi(optarg) <= 65535)) dstPort = (unsigned short)atoi(optarg);
        else
        {
          fprintf(stderr, "sensor0 error: port out of range (1-65535)\n");
          showUsage(argv[0]);
          return 1;
        }
        break;
      case 'p': goPromisc = 1; break;
      case 'd': goDaemon = true; break;
      default:
        showUsage(argv[0]);
        return 1;
    }
  }
#endif
  char errorBuffer[PCAP_ERRBUF_SIZE];
  if (*strInfile == '\0')
  {
    pcap_if_t *devAll, *devPcap;
    if (pcap_findalldevs(&devAll, errorBuffer) == -1)
    {
      fprintf(stderr, "sensor0 error: pcap_findalldevs() failed- %s\n", errorBuffer);
      showUsage(argv[0]);
      return 1;
    }
    fprintf(stdout, "Interface List:\n");
    int cntDev = 0, numDev;
    for (devPcap = devAll; devPcap; devPcap = devPcap->next)
    {
      fprintf(stdout, " %d  %s", ++cntDev, devPcap->name);
      if (devPcap->description) fprintf(stdout, "  :%s", devPcap->description);
      fprintf(stdout, "\n");
    }
    if (!cntDev)
    {
      fprintf(stderr, "sensor0 error: no interfaces found, are you root?\n");
      showUsage(argv[0]);
      pcap_freealldevs(devAll);
      return 1;
    }
    fprintf(stdout, "Enter the Interface Number: ");
    if (scanf("%d", &numDev) != 1)
    {
      fprintf(stderr, "sensor0 error: interface number invalid\n");
      showUsage(argv[0]);
      pcap_freealldevs(devAll);
      return 1;
    }
    if ((numDev < 1) || (numDev > cntDev))
    {
      fprintf(stderr, "sensor0 error: interface number out of range\n");
      showUsage(argv[0]);
      pcap_freealldevs(devAll);
      return 1;
    }
    for (devPcap = devAll, cntDev = 1; cntDev < numDev; cntDev++) devPcap = devPcap->next;
    strncat(strInfile, devPcap->name, 255);
    pcap_freealldevs(devAll);
  }
#ifndef _MSC_VER
  if (goDaemon)
  {
    pid_t processId = fork();
    if (processId == -1)
    {
      fprintf(stderr, "sensor0 error: fork() failed\n");
      return 1;
    }
    if (processId > 0) return 0;
    pid_t sessionId = setsid();
    if (sessionId == -1)
    {
      fprintf(stderr, "sensor0 error: setsid() failed\n");
      return 1;
    }
    umask(0);
  }
  syslog(LOG_INFO, "started\n");
#endif
  addrPacket0.sin_family = AF_INET;
  addrPacket0.sin_addr.s_addr = inet_addr(*strDestination == '\0' ? "127.0.0.1" : strDestination);
  addrPacket0.sin_port = htons(dstPort);
  if ((sockPacket0 = socket(PF_INET, SOCK_DGRAM, IPPROTO_UDP)) == -1)
  {
    fprintf(stderr, "sensor0 error: socket create failed\n");
#ifndef _MSC_VER
    syslog(LOG_ERR, "socket create failed\n");
#endif
    return 1;
  }
  int sockOpt = 1;
#ifdef _MSC_VER
  if (setsockopt(sockPacket0, SOL_SOCKET, SO_BROADCAST, (const char *)&sockOpt, sizeof(sockOpt)) == -1)  //enable UDP broadcasts
#else
  if (setsockopt(sockPacket0, SOL_SOCKET, SO_BROADCAST, &sockOpt, sizeof(sockOpt)) == -1)  //enable UDP broadcasts
#endif
  {
    fprintf(stderr, "sensor0 error: socket opt failed- broadcasts\n");
#ifndef _MSC_VER
    syslog(LOG_ERR, "socket opt failed- broadcasts\n");
#endif
    close(sockPacket0);
    return 1;
  }
  if (!(pPcap = pcap_open_offline(strInfile, errorBuffer)))  //test for file or interface input
  {
#ifndef _MSC_VER
    syslog(LOG_INFO, "pcap_open_offline() failed- %s, trying pcap_open_live()\n", errorBuffer);
#endif
    if (!(pPcap = pcap_open_live(strInfile, PACKET_MAX, goPromisc, 20, errorBuffer)))
    {
      fprintf(stderr, "sensor0 error: pcap_open_live() failed- %s, are you root?\n", errorBuffer);
#ifndef _MSC_VER
      syslog(LOG_ERR, "pcap_open_live() failed- %s, are you root?\n", errorBuffer);
#endif
      close(sockPacket0);
      return 1;
    }
    struct bpf_program bpfProgram;
    char strFilter[23];
    sprintf(strFilter, "not udp dst port %hu", dstPort);
    if (pcap_compile(pPcap, &bpfProgram, strFilter, 1, PCAP_NETMASK_UNKNOWN) == -1)
    {
      fprintf(stderr, "sensor0 error: pcap_compile() failed- %s\n", pcap_geterr(pPcap));
#ifndef _MSC_VER
      syslog(LOG_ERR, "pcap_compile() failed- %s\n", pcap_geterr(pPcap));
#endif
      pcap_close(pPcap);
      close(sockPacket0);
      return 1;
    }
    if (pcap_setfilter(pPcap, &bpfProgram) == -1)
    {
      fprintf(stderr, "sensor0 error: pcap_setfilter() failed- %s\n", pcap_geterr(pPcap));
#ifndef _MSC_VER
      syslog(LOG_ERR, "pcap_setfilter() failed- %s\n", pcap_geterr(pPcap));
#endif
      pcap_freecode(&bpfProgram);
      pcap_close(pPcap);
      close(sockPacket0);
      return 1;
    }
    pcap_freecode(&bpfProgram);
  }
#ifndef _MSC_VER
  else if (strcmp(argv[2], "-")) replayPcap = true;
#endif
  datalinkPcap = pcap_datalink(pPcap);
  if ((datalinkPcap != DLT_EN10MB) && (datalinkPcap != DLT_PPP) && (datalinkPcap != DLT_LINUX_SLL))
  {
    fprintf(stderr, "sensor0 error: interface not supported- %d\n", datalinkPcap);
#ifndef _MSC_VER
    syslog(LOG_ERR, "interface not supported- %d\n", datalinkPcap);
#endif
    pcap_close(pPcap);
    close(sockPacket0);
    return 1;
  }
  udpTrack = new UDPTrack;
#ifndef _MSC_VER
  signal(SIGINT, stopRun);  //capture ctrl+c
  signal(SIGTERM, stopRun);  //capture kill
#endif
  pcap_loop(pPcap, -1, processPacket, &sensorId);
  pcap_close(pPcap);
  close(sockPacket0);
  delete udpTrack;
#ifndef _MSC_VER
  syslog(LOG_INFO, "stopped\n");
#endif
  return 0;
}
