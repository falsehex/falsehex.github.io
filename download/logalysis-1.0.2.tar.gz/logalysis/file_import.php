<html>
<head>
<meta name='copyright' content='2012-2016 Del Castle' />
<meta charset='UTF-8' />
<meta http-equiv='content-type' content='text/html' />
<link rel='stylesheet' type='text/css' href='fx/css/logalysis.css' />

</head>
<body>

<?php

include "common.php";
session_start();
/*if (isset($_SESSION["las_last_activity"]) && ((time() - $_SESSION["las_last_activity"]) > 3600))
{
  session_unset();
  session_destroy();
} 
$_SESSION["las_last_activity"] = time();*/
if (empty($_SESSION["las_login_user_name"])) exit($login_bounce);

$job_id = (isset($_POST["job_id"]) ? $_POST["job_id"] : $_GET["job_id"]);
$ref_no = (isset($_POST["ref_no"]) ? $_POST["ref_no"] : $_GET["ref_no"]);

if (strstr($ref_no, "../")) exit(0);
if (isset($_POST["job_id"]) && is_uploaded_file($_FILES["file_name"]["tmp_name"]))
{
  $dest_dir = "files/{$ref_no}";
  if ($ref_no == "SCRATCHPAD") $dest_dir .= "/{$_SESSION["las_login_user_name"]}...dir";
  if (!file_exists($dest_dir))
  {
    if ($ref_no == "SCRATCHPAD") mkdir("files/{$ref_no}/{$_SESSION["las_login_user_name"]}", 0755, TRUE);
    mkdir($dest_dir, 0755);
  }
  move_uploaded_file($_FILES["file_name"]["tmp_name"], "{$dest_dir}/" . basename($_FILES["file_name"]["name"]));

  echo "<script type='text/javascript'>parent.frame_file_list.location.href = \"file_list.php?job_id={$job_id}&ref_no={$ref_no}\";</script>";
}

echo "<form action='file_import.php' method='POST' enctype='multipart/form-data'>";
echo "<input type='hidden' name='job_id' value='{$job_id}' />";
echo "<input type='hidden' name='ref_no' value='{$ref_no}' />";
echo "<table>";
echo "<tr><td>File</td><td><input type='file' name='file_name' size='40' /></td>";
echo "<td><input type='submit' value='Import' /></td></tr>";
echo "</table>";
echo "</form>";

?>

</body>
</html>
