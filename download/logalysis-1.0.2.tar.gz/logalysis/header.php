<html>
<head>
<meta name='copyright' content='2012-2016 Del Castle' />
<meta charset='UTF-8' />
<meta http-equiv='content-type' content='text/html' />
<link rel='stylesheet' type='text/css' href='fx/css/logalysis.css' />

<script type='text/javascript' src='fx/js/logalysis.js'></script>
<script type='text/javascript'>
function showUTC()
{
  document.getElementById("ancUt").textContent = nowUTC(true);
  setTimeout("showUTC()", 1000);
}
</script>

</head>
<body onload='showUTC();'>

<?php

include "common.php";
session_start();
if (empty($_SESSION["las_login_user_id"])) exit($login_bounce);

if (isset($_GET["action"]))
{
  $link = logalysis_db_connect();

  write_audit($link, 0, $_SESSION["las_login_user_id"], 3, "");
  session_unset();
  session_destroy();

  mysqli_close($link);

  exit($login_bounce);
}

echo "<div class='menu'>";
echo "<a id='ancUt' class='menu' style='color:#FFFFFE'></a>";
echo "<a class='menu' style='color:#BBFFBB; margin-left:64px'>LOGALYSIS &nbsp; &nbsp; &nbsp; &copy; 2012-2016 Del Castle</a>";
echo "<a id='ancLu' class='menu' style='float:right' href='header.php?action=logout'>LOGOUT {$_SESSION["las_login_user_name"]}</a>";
echo "<a class='menu' style='float:right' href='settings_layout.html' target='frame_show'>SETTINGS</a>";
echo "<a class='menu' style='float:right; margin-right:64px' href='index.php' target='_blank'>NEW WINDOW</a>";
echo "</div>";

?>

</body>
</html>
