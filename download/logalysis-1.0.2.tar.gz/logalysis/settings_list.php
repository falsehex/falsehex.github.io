<html>
<head>
<meta name='copyright' content='2012-2016 Del Castle' />
<meta charset='UTF-8' />
<meta http-equiv='content-type' content='text/html' />
<link rel='stylesheet' type='text/css' href='fx/css/logalysis.css' />

<link rel='stylesheet' type='text/css' href='fx/css/etree.css' />
<script type='text/javascript' src='fx/js/etree.js'></script>

</head>
<body>

<?php

include "common.php";
session_start();
/*if (isset($_SESSION["las_last_activity"]) && ((time() - $_SESSION["las_last_activity"]) > 3600))
{
  session_unset();
  session_destroy();
} 
$_SESSION["las_last_activity"] = time();*/
if (empty($_SESSION["las_login_user_name"])) exit($login_bounce);

$link = logalysis_db_connect();

if ($_SESSION["las_login_user_admin"])
{
  echo "<div class='menu'>";
  echo "<a class='menu' href='user_show.php' target='frame_settings_show'>NEW USER</a>";
  echo "<a class='menu' href='state_show.php' target='frame_settings_show'>NEW STATE</a>";
  echo "</div><br />";
}

echo "<script type='text/javascript'>";
echo "var etrSl = new eTree(\"etrSl\");";
$item = 0;
echo "etrSl.add(0, -1, true, \"folder\", \"SETTINGS\");";
$count = db_result($link, "SELECT COUNT(1) FROM users");
echo "etrSl.add(" . ++$item . ", 0, false, \"folder\", \"USER" . ($_SESSION["las_login_user_admin"] ? "S ({$count})" : "") . "\");";
$parent = $item;
$result = mysqli_query($link, "SELECT name, is_disabled, user_id FROM users" . ($_SESSION["las_login_user_admin"] ? "" : " WHERE user_id = {$_SESSION["las_login_user_id"]}") . " ORDER BY name");
while ($user = mysqli_fetch_row($result)) echo "etrSl.add(" . ++$item . ", {$parent}, false, \"user\", \"{$user[0]}" . ($user[1] ? " (D)" : "") . "\", \"user_show.php?user_id={$user[2]}\", \"frame_settings_show\");";
mysqli_free_result($result);
if ($_SESSION["las_login_user_admin"])
{
  $count = db_result($link, "SELECT COUNT(1) FROM states");
  echo "etrSl.add(" . ++$item . ", 0, false, \"folder\", \"STATES ({$count})\");";
  $parent = $item;
  $result = mysqli_query($link, "SELECT name, is_disabled, state_id FROM states ORDER BY position");
  while ($state = mysqli_fetch_row($result)) echo "etrSl.add(" . ++$item . ", {$parent}, false, \"tray\", \"{$state[0]}" . ($state[1] ? " (D)" : "") . "\", \"state_show.php?state_id={$state[2]}\", \"frame_settings_show\");";
  mysqli_free_result($result);
}
echo "etrSl.add(" . ++$item . ", 0, false, \"folder\", \"STATUS\");";
$parent = $item;
$files = scandir("plugins/status");
foreach ($files as &$row)
{
  if (strstr($row, ".status.php"))
  {
    $row = preg_replace("/^(.+)\.status\.php$/", "$1", $row);
    echo "etrSl.add(" . ++$item . ", {$parent}, false, \"file\", \"{$row}\", \"plugins/status/{$row}.status.php\", \"frame_settings_show\");";
  }
}
echo "etrSl.add(" . ++$item . ", 0, true, \"folder\", \"EDIT\");";
$parent = $item;
$files = scandir("plugins/edit");
foreach ($files as &$row)
{
  if ($row[0] != ".") echo "etrSl.add(" . ++$item . ", {$parent}, false, \"file\", \"{$row}\", \"file_edit.php?file_name={$row}\", \"frame_settings_show\");";
}
echo "etrSl.write();";
echo "</script>";

mysqli_close($link);

?>

</body>
</html>
