<?php

if (!isset($not_source_ip)) $not_source_ip = (isset($_GET["not_source_ip"]) ? $_GET["not_source_ip"] : "");

if (empty($nohdr)) echo "<h4>APACHE ACCESS</h4>";
echo "<table class='esort'>";
echo "<tr><th></th><th>Time</th><th>Client IP</th><th>Ident</th><th>User</th><th>Request</th><th>Status</th><th>Size</th><th>Referer</th><th>User-Agent</th></tr>";
$count = 0;
$apache_logs = scandir("/var/log/apache2");
natsort($apache_logs);
$apache_logs = array_reverse($apache_logs);
foreach ($apache_logs as &$file)
{
  if (preg_match("/^access\.log/", $file))
  {
    $apache_access = gzopen("/var/log/apache2/{$file}", "r");
    while ($line = gzgets($apache_access, 4096))
    {
      $row = preg_split("/\s\"([^\"]+)\"|\s/", $line, -1, PREG_SPLIT_NO_EMPTY | PREG_SPLIT_DELIM_CAPTURE);
      $row[4] = preg_replace("/^\[(.+)/", "$1", $row[3]) . " " . preg_replace("/(.+)\]$/", "$1", $row[4]);
      for ($cnt = 3; $cnt > 0; $cnt--) $row[$cnt] = $row[$cnt - 1];
      $row[0] = strtotime($row[4]);
      unset($row[4]);
      $process = TRUE;
      if ($start_time && ($row[0] < strtotime($start_time))) $process = FALSE;
      if ($process && $finish_time && ($row[0] > strtotime($finish_time))) $process = FALSE;
      if ($process && $source_ip)
      {
        if (!strstr($row[1], $source_ip)) $process = FALSE;
        if ($not_source_ip) $process = !$process;
      }
      if ($process && $char_4_255 && !stristr($row[5], $char_4_255)) $process = FALSE;
      if ($process)
      {
        $row[0] = date("Y-m-d H:i:s", $row[0]);
        if ($action) $save[] = array($row[0], NULL, $row[6], $row[7], NULL, NULL, NULL, $row[3], NULL, $row[2], $row[5], $row[8], $row[9], NULL, $row[1], NULL, NULL, NULL, NULL);
        echo "<tr onclick='txtBold(this.style);'><td>" . ++$count . "</td>";
        $row[1] = "<a class='action' href='javascript:popUp(\"host_show.php?host_ip={$row[1]}\");'>{$row[1]}</a>";
        $row[7] = format_bytes($row[7]);
        foreach ($row as &$cell) echo "<td>{$cell}</td>";
        echo "</tr>";
        if ($count == $limit) break;
      }
    }
    gzclose($apache_access);
    if ($count == $limit) break;
  }
}
echo "</table>";

?>
