<html>
<head>
<meta name='copyright' content='2012-2016 Del Castle' />
<meta charset='UTF-8' />
<meta http-equiv='content-type' content='text/html' />
<link rel='stylesheet' type='text/css' href='fx/css/logalysis.css' />

<script type='text/javascript' src='fx/js/edate.js'></script>

<script type='text/javascript' src='fx/js/logalysis.js'></script>

</head>
<body>

<?php

include "common.php";
session_start();
/*if (isset($_SESSION["las_last_activity"]) && ((time() - $_SESSION["las_last_activity"]) > 3600))
{
  session_unset();
  session_destroy();
} 
$_SESSION["las_last_activity"] = time();*/
if (empty($_SESSION["las_login_user_name"])) exit($login_bounce);
$_SESSION["las_menu_tab"] = 0;

$login_user_id = $_SESSION["las_login_user_id"];
$job_id = (isset($_POST["job_id"]) && is_numeric($_POST["job_id"]) ? $_POST["job_id"] : (isset($_GET["job_id"]) && is_numeric($_GET["job_id"]) ? $_GET["job_id"] : 0));
$ref_no = (isset($_POST["ref_no"]) ? $_POST["ref_no"] : (isset($_GET["ref_no"]) ? $_GET["ref_no"] : ""));

$link = logalysis_db_connect();

if (isset($_POST["job_id"]))
{
  $report = (isset($_POST["report"]) ? $_POST["report"] : "");
  $hours = (is_numeric($_POST["hours"]) ? $_POST["hours"] : $_POST["old_hours"]);
  $minutes = (is_numeric($_POST["minutes"]) ? $_POST["minutes"] : $_POST["old_minutes"]);
  $state_id = (is_numeric($_POST["state_id"]) ? $_POST["state_id"] : $_POST["old_state_id"]);
  $priority_id = (is_numeric($_POST["priority_id"]) ? $_POST["priority_id"] : $_POST["old_priority_id"]);
  $user_id = (is_numeric($_POST["user_id"]) ? $_POST["user_id"] : $_POST["old_user_id"]);
  $sensor = $_POST["sensor"];
  $label = $_POST["label"];
  $comments = $_POST["comments"];
  $event_time = $_POST["event_time"];
  $protocol = $_POST["protocol"];
  $source_ip = $_POST["source_ip"];
  $source_port = (is_numeric($_POST["source_port"]) ? $_POST["source_port"] : $_POST["old_source_port"]);
  $target_ip = $_POST["target_ip"];
  $target_port = (is_numeric($_POST["target_port"]) ? $_POST["target_port"] : $_POST["old_target_port"]);
  if ($job_id)
  {
    if ($state_id != $_POST["old_state_id"])
    {
      $sql = "UPDATE jobs SET state_id = {$state_id}" . (get_state_name($link, $state_id) == "CLOSED" ? ", close_time = UTC_TIMESTAMP(), close_user_id = {$login_user_id}" : ", close_time = NULL, close_user_id = 0") . " WHERE job_id = {$job_id}";
      mysqli_query($link, $sql);
      write_audit($link, $job_id, $login_user_id, 9, $sql);
    }
    if ($user_id != $_POST["old_user_id"])
    {
      $sql = "UPDATE jobs SET assign_user_id = {$user_id} WHERE job_id = {$job_id}";
      mysqli_query($link, $sql);
      write_audit($link, $job_id, $login_user_id, 10, $sql);
    }
    $extra = ($report != $_POST["old_report"] ? " report = " . ($report ? "TRUE" : "FALSE") : "");
    if (($hours != $_POST["old_hours"]) || ($minutes != $_POST["old_minutes"])) $extra .= ($extra ? "," : "") . " spent = " . (($hours * 3600) + ($minutes * 60));
    if ($priority_id != $_POST["old_priority_id"]) $extra .= ($extra ? "," : "") . " priority_id = {$priority_id}";
    if ($sensor != $_POST["old_sensor"]) $extra .= ($extra ? "," : "") . " sensor = '" . addslashes($sensor) . "'";
    if ($label != $_POST["old_label"]) $extra .= ($extra ? "," : "") . " label = '" . addslashes($label) . "'";
    if ($comments != $_POST["old_comments"]) $extra .= ($extra ? "," : "") . " comments = '" . addslashes($comments) . "'";
    if ($event_time != $_POST["old_event_time"]) $extra .= ($extra ? "," : "") . " event_time = " . ($event_time == "" ? "NULL" : "'" . addslashes($event_time) . "'");
    if ($protocol != $_POST["old_protocol"]) $extra .= ($extra ? "," : "") . " protocol = '" . addslashes($protocol) . "'";
    if ($source_ip != $_POST["old_source_ip"]) $extra .= ($extra ? "," : "") . " source_ip = '" . addslashes($source_ip) . "'";
    if ($source_port != $_POST["old_source_port"]) $extra .= ($extra ? "," : "") . " source_port = {$source_port}";
    if ($target_ip != $_POST["old_target_ip"]) $extra .= ($extra ? "," : "") . " target_ip = '" . addslashes($target_ip) . "'";
    if ($target_port != $_POST["old_target_port"]) $extra .= ($extra ? "," : "") . " target_port = {$target_port}";
    if ($extra)
    {
      $sql = "UPDATE jobs SET{$extra} WHERE job_id = {$job_id}";
      mysqli_query($link, $sql);
      write_audit($link, $job_id, $login_user_id, 11, $sql);
    }
  }
  else
  {
    $sql = "INSERT INTO jobs VALUES(0, NULL, UTC_TIMESTAMP(), {$login_user_id}, NULL, 0, " . (($hours * 3600) + ($minutes * 60)) . ", {$state_id}, {$priority_id}, {$user_id}, '" . addslashes($sensor) . "', '" . addslashes($label) . "', '" . addslashes($comments) . "', " . ($event_time == "" ? "NULL" : "'" . addslashes($event_time) . "'") . ", '" . addslashes($protocol) . "', '" . addslashes($source_ip) . "', " . ($source_port == "" ? "NULL" : $source_port) . ", '" . addslashes($target_ip) . "', " . ($target_port == "" ? "NULL" : $target_port) . ", " . ($report ? "TRUE" : "FALSE") . ")";
    mysqli_query($link, $sql);
    $job_id = mysqli_insert_id($link);
    $ref_date = db_result($link, "SELECT DATE_FORMAT(create_time, '%Y%m%d') FROM jobs WHERE job_id = {$job_id}");
    $ref_day = db_result($link, "SELECT COUNT(1) FROM jobs WHERE DATE_FORMAT(create_time, '%Y%m%d') = '{$ref_date}' AND job_id <= {$job_id}");
    mysqli_query($link, "UPDATE jobs SET ref_day = {$ref_day} WHERE job_id = {$job_id}");
    $ref_no = "{$system}-{$ref_date}-" . str_pad($ref_day, $ref_pad, "0", STR_PAD_LEFT);
    write_audit($link, $job_id, $login_user_id, 8, $sql);

    echo "<script type='text/javascript'>top.frame_menu_main.location.href = \"menu_main.php?job_id={$job_id}&ref_no={$ref_no}\";</script>";
  }

  echo "<script type='text/javascript'>top.frame_job_list.location.reload();</script>";
}

echo "<div class='menu'>";
echo "<a class='menu' href='#' onclick='this.style.display = \"none\"; visState(\"ancPw\", 1); document.forms[0].submit();'>SAVE" . ($job_id ? "" : " NEW") . "</a>";
if ($job_id)
{
  $details = db_fetch_row($link, "SELECT spent, report, state_id, priority_id, assign_user_id, sensor, label, comments, create_user_id, create_time, close_user_id, close_time, event_time, protocol, source_ip, source_port, target_ip, target_port FROM jobs WHERE job_id = {$job_id}");
  echo "<a class='menu' href='log_layout.php?job_id={$job_id}&ref_no={$ref_no}&search=" . urlencode(";{$details[12]};{$details[12]};;;;;;;;;;;;;{$details[14]};{$details[15]};{$details[16]};{$details[17]}") . "' target='frame_show'>SEARCH LOGS</a>";
  echo "<a class='menu' href='file_layout.php?job_id={$job_id}&ref_no={$ref_no}&search=" . urlencode(";{$details[12]};{$details[12]};{$details[14]};{$details[15]};{$details[16]};{$details[17]}") . "' target='frame_show'>GENERATE FILE</a>";
  echo "<a class='menu' href='audit_show.php?job_id={$job_id}'>AUDIT</a>";
}
else if (isset($_GET["details"]))
{
  $details = explode(";", $_GET["details"]);
  if (!$details[4]) $details[4] = $login_user_id;
}
else $details = array(0, 0, 1, 4, $login_user_id, "", "", "", "", "", "", "", "", "", "", "", "", "");
echo "<a id='ancPw' class='menu' style='color:#FF9999; visibility:hidden'>PLEASE WAIT...</a>";
echo "</div><br />";

echo "<script type='text/javascript'>top.frame_queue_list.location.href = \"queue_list.php?state_id={$details[2]}\";</script>";

echo "<form action='details_show.php' method='POST'>";
echo "<input type='hidden' name='job_id' value='{$job_id}' />";
echo "<table>";
echo "<tr><td>Reference</td><td><input type='text' name='ref_no' size='32' readonly='readonly' value='{$ref_no}' />";
echo "&nbsp;&nbsp;&nbsp;Hours <input type='text' name='hours' size='7' value='" . floor($details[0] / 3600) . "' />";
echo "<input type='hidden' name='old_hours' value='" . floor($details[0] / 3600) . "' />";
echo "&nbsp;&nbsp;Mins <input type='text' name='minutes' size='7' value='" . ceil(($details[0] % 3600) / 60) . "' />";
echo "<input type='hidden' name='old_minutes' value='" . ceil(($details[0] % 3600) / 60) . "' />";
echo "&nbsp;&nbsp;<input type='checkbox' name='report' value='on'" . ($details[1] ? " checked='checked'" : "") . " />{$lbl_report}</td></tr>";
echo "<input type='hidden' name='old_report' value='" . ($details[1] ? "on" : "") . "' />";
echo "<tr><td>Status</td><td><select name='state_id'>";
$result = mysqli_query($link, "SELECT state_id, name, position, is_disabled FROM states ORDER BY position");
while ($row = mysqli_fetch_row($result))
{
  echo "<option value='{$row[0]}'";
  if ($row[0] == $details[2])
  {
    echo " selected";
    $state_name = $row[1];
    $position = $row[2];
  }
  echo ">{$row[1]}" . ($row[3] ? " (D)" : "") . "</option>";
}
mysqli_free_result($result);
echo "</select>";
if ($job_id) echo "&nbsp;&nbsp;&nbsp;<input type='button' value='" . ($position < 100 ? "Raise Change" : "Complete") . "' onclick='popUp(\"note_show.php?job_id={$job_id}&note_txt=" . ($position < 100 ? "change_details" : strtolower(strtr($state_name, " ", "_"))) . ".change\");' />";
echo "</td></tr>";
echo "<input type='hidden' name='old_state_id' value='{$details[2]}' />";
echo "<tr><td>Priority</td><td><select name='priority_id'>";
$result = mysqli_query($link, "SELECT * FROM priorities");
while ($row = mysqli_fetch_row($result))
{
  echo "<option value='{$row[0]}'";
  if ($row[0] == $details[3]) echo " selected";
  echo ">{$row[1]}</option>";
}
mysqli_free_result($result);
echo "</select></td></tr>";
echo "<input type='hidden' name='old_priority_id' value='{$details[3]}' />";
echo "<tr><td>Assigned</td><td><select name='user_id'>";
echo "<option value='-1'";
if ($details[4] == -1) echo " selected";
echo ">{$system}</option>";
$result = mysqli_query($link, "SELECT user_id, name, is_disabled FROM users");
while ($row = mysqli_fetch_row($result))
{
  echo "<option value='{$row[0]}'";
  if ($row[0] == $details[4]) echo " selected";
  echo ">{$row[1]}" . ($row[2] ? " (D)" : "") . "</option>";
}
mysqli_free_result($result);
echo "</select></td></tr>";
echo "<input type='hidden' name='old_user_id' value='{$details[4]}' />";
echo "<tr><td>Sensor</td><td><input type='text' name='sensor' size='82' maxlength='64' value='{$details[5]}' /></td></tr>";
echo "<input type='hidden' name='old_sensor' value='{$details[5]}' />";
echo "<tr><td>Label</td><td><input type='text' name='label' size='82' maxlength='255' value='{$details[6]}' /></td></tr>";
echo "<input type='hidden' name='old_label' value='{$details[6]}' />";
echo "<tr><td>Comments</td><td><textarea name='comments' cols='80' rows='6'>{$details[7]}</textarea></td></tr>";
echo "<input type='hidden' name='old_comments' value='{$details[7]}' />";
echo "<tr><td>Creator</td><td><input type='text' size='82' readonly='readonly' value='" . get_user_name($link, $details[8]) . "' /></td></tr>";
echo "<tr><td>Created</td><td><input type='text' size='21' readonly='readonly' value='{$details[9]}' /></td></tr>";
echo "<tr><td>Closer</td><td><input type='text' size='82' readonly='readonly' value='" . get_user_name($link, $details[10]) . "' /></td></tr>";
echo "<tr><td>Closed</td><td><input type='text' size='21' readonly='readonly' value='{$details[11]}' /></td></tr>";
echo "<tr><td>Event Time</td><td><input class='edate' type='text' name='event_time' size='21' maxlength='19' value='{$details[12]}' />";
echo "<input type='button' value='@' title='Now' onclick='event_time.value = nowUTC(true);' /></td></tr>";
echo "<input type='hidden' name='old_event_time' value='{$details[12]}' />";
echo "<tr><td>Protocol</td><td><input type='text' name='protocol' size='7' maxlength='5' value='{$details[13]}' /></td></tr>";
echo "<input type='hidden' name='old_protocol' value='{$details[13]}' />";
echo "<tr><td>Source IP</td><td><input type='text' name='source_ip' size='82' maxlength='39' value='{$details[14]}' /></td></tr>";
echo "<input type='hidden' name='old_source_ip' value='{$details[14]}' />";
echo "<tr><td>Port</td><td><input type='text' name='source_port' size='7' maxlength='5' value='{$details[15]}' /></td></tr>";
echo "<input type='hidden' name='old_source_port' value='{$details[15]}' />";
echo "<tr><td>Target IP</td><td><input type='text' name='target_ip' size='82' maxlength='39' value='{$details[16]}' /></td></tr>";
echo "<input type='hidden' name='old_target_ip' value='{$details[16]}' />";
echo "<tr><td>Port</td><td><input type='text' name='target_port' size='7' maxlength='5' value='{$details[17]}' /></td></tr>";
echo "<input type='hidden' name='old_target_port' value='{$details[17]}' />";
echo "</table>";
echo "</form>";

mysqli_close($link);

?>

</body>
</html>
