<?php

include "plugins/misc/snort.php";
include "plugins/cred/snort.cred.php";

$link = logalysis_db_connect();

echo "<script type='text/javascript'>";
echo "function snlJob(objTr) { aryTd = objTr.getElementsByTagName(\"td\"); parent.location.href = \"details_show.php?details=\" + escape(\"0;0;1;4;{$login_user_id};\" + aryTd[3].textContent + \";Snort Alert: \" + aryTd[4].textContent.replace(/'/g, \"\\\"\") + \";GID/SID: \" + aryTd[5].textContent + \"\\nClassification: \" + aryTd[11].textContent + \";;;;;\" + aryTd[1].textContent + \";\" + aryTd[6].textContent + \";\" + aryTd[7].textContent + \";\" + aryTd[8].textContent + \";\" + aryTd[9].textContent + \";\" + aryTd[10].textContent); }";
echo "</script>";

if (empty($nohdr)) echo "<h4>SNORT</h4>";
echo "<table class='esort'>";
echo "<tr><th></th><th>Time</th><th>Priority</th><th>Sensor</th><th>Alert</th><th>GID/SID</th><th>Protocol</th><th>Source IP</th><th>Port</th><th>Target IP</th><th>Port</th><th>Classification</th><th>EID</th><th>Actions</th></tr>";
$count = 0;
$result = mysqli_query($link, "SELECT time_1, num_1, char_3_255, char_4_255, num_2, num_3, protocol, source_ip, source_port, target_ip, target_port, char_1_64, num_4, data FROM events WHERE log_id = {$log_id} ORDER BY time_1");
while ($row = mysqli_fetch_row($result))
{
  $sensor_id = preg_replace("/^(\d+):[^!]+$/", "$1", $row[2]);
  echo "<tr onclick='txtBold(this.style);'><td>" . ++$count . "</td>";
  $row[1] = snort_priority($row[1], FALSE, FALSE);
  $row[4] = (($row[4] == 1) || ($row[4] == 3) ? "<a class='action' href='javascript:popUp(\"{$snort_www_host}/snort_rule.php?sid={$row[5]}\");'>{$row[4]}:{$row[5]}</a>" : "{$row[4]}:{$row[5]}");
  unset($row[5]);
  $file_id = "{$sensor_id};{$row[12]};{$row[6]};{$row[8]};{$row[10]}";
  $row[6] = protocol_name($row[6]);
  $row[13] = ($row[13] ? "<a class='action' href='pcap_get.php?plugin=Snort&file_id={$file_id}'>PCAP</a> <a class='action' href='file_layout.php?job_id={$job_id}&ref_no={$ref_no}&search=Snort;{$row[0]};{$row[0]};{$row[7]};{$row[8]};{$row[9]};{$row[10]}&file_id={$file_id}' target='frame_show'>FILE</a> " : "") . "<a class='action' href='javascript:void(0);' onclick='snlJob(this.parentNode.parentNode);'>JOB</a>";
  $row[7] = "<a class='action' href='javascript:popUp(\"host_show.php?host_ip={$row[7]}\");'>{$row[7]}</a>";
  $row[9] = "<a class='action' href='javascript:popUp(\"host_show.php?host_ip={$row[9]}\");'>{$row[9]}</a>";
  foreach ($row as &$cell) echo "<td>{$cell}</td>";
  echo "</tr>";
}
mysqli_free_result($result);
echo "</table>";

mysqli_close($link);

?>
