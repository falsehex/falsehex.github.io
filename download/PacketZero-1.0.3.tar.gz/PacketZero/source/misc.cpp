/* misc.cpp - 24 Jan 21
   PacketZero - 3D Network Monitor
   Copyright 2006-2021 Del Castle  */

#include <arpa/inet.h>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>

#include "misc.h"

//add extension to file
void addExtension(char *filename, const char *ext)
{
  if (((strlen(filename) + strlen(ext)) < 256) && !strstr(filename, ext)) strcat(filename, ext);
}

//create directory file list
void createFileList(const char *filename, const char *path, const char *ext)
{
  FILE *fileList;
  if ((fileList = fopen(filename, "w")))
  {
    dirent **listFiles;
    int numFiles = scandir(path, &listFiles, regularFile, alphasort);
    for (int cntFile = 0; cntFile < numFiles; cntFile++)
    {
      if ((listFiles[cntFile]->d_name[0] != '.') && strstr(listFiles[cntFile]->d_name, ext)) fprintf(fileList, "%s\n", listFiles[cntFile]->d_name);  //don't show hidden files
      free(listFiles[cntFile]);
    }
    free(listFiles);
    fclose(fileList);
  }
}

//protocol number to text
char *decodeProtocol(int protocol, char *buffer)
{
  switch (protocol)
  {
    case IPPROTO_ICMP: strncpy(buffer, "ICMP", 5); break;
    case IPPROTO_IGMP: strncpy(buffer, "IGMP", 5); break;
    case IPPROTO_TCP: strncpy(buffer, "TCP", 4); break;
    case IPPROTO_UDP: strncpy(buffer, "UDP", 4); break;
    case IPPROTO_ARP: strncpy(buffer, "ARP", 4); break;
    case IPPROTO_FRAG: strncpy(buffer, "FRAG", 5); break;
    default: sprintf(buffer, "%d", protocol);
  }
  return buffer;
}

//escape quotes in CSV strings
void escapeQuotes(const char *text, char *buffer)
{
  for (int cntChar = 0; text[cntChar] != '\0'; cntChar++)
  {
    if (text[cntChar] == '\"') strcat(buffer, "\"");
    sprintf(buffer, "%s%c", buffer, text[cntChar]);
  }
}

//format bytes using prefix
char *formatBytes(unsigned long long bytes, char *buffer)
{
  unsigned char cntPrefix;
  double fractionPart = 0.0;
  char txtPrefix[7][3] = {"B", "kB", "MB", "GB", "TB", "PB", "EB"};
  for (cntPrefix = 0; (bytes > 1023) && (cntPrefix < 6); bytes /= 1024, cntPrefix++) fractionPart = (bytes % 1024) / 1024.0;
  sprintf(buffer, "%.2f %s", bytes + fractionPart, txtPrefix[cntPrefix]);
  return buffer;
}

//get data directory
char *getPath(const char *filename, char *buffer)
{
#ifdef __APPLE__
  sprintf(buffer, "%s/Library/Application Support/PacketZero/%s", getenv("HOME"), filename);
#else
  sprintf(buffer, "%s/.packet0/%s", getenv("HOME"), filename);
#endif
  return buffer;
}

//check if an IP address is in a CIDR net
bool inNet(const char *net, in_addr ip)
{
  in_addr_t netMask = 0;
  char netTemp[19], *pPrefix;
  strncpy(netTemp, net, 19);
  if (!(pPrefix = strchr(netTemp, '/'))) return false;
  *pPrefix = '\0';
  if (atoi(++pPrefix)) netMask = htonl(0xFFFFFFFF << (32 - atoi(pPrefix)));
  return ((inet_addr(netTemp) & netMask) == (ip.s_addr & netMask));
}

//convert string to lowercase
char *lowerStr(const char *text, char *buffer)
{
  for (int cntChar = 0; (buffer[cntChar] = (char)tolower(text[cntChar])) && (text[cntChar] != '\0'); cntChar++);  //nothing
  return buffer;
}

//check for regular file
int regularFile(const dirent *entry)
{
  return (entry->d_type == DT_REG);
}

//square function
double sqr(double val)
{
  return (val * val);
}

//check for controls file, create it & data directory
void checkControls(char *buffer)
{
  FILE *fileControls;
  struct stat statControls;
  if (stat(getPath("controls.txt", buffer), &statControls)) mkdir(getPath("", buffer), S_IRWXU | S_IRGRP | S_IXGRP | S_IROTH | S_IXOTH);  //drwxr-xr-x
  else if (statControls.st_size == 2063) return;  //1.0.0
  if ((fileControls = fopen(getPath("controls.txt", buffer), "w")))
  {
    fputs("Left Mouse Button\tSelect Host\n", fileControls);
    fputs("\tClick-and-Drag to Select Multiple Hosts\n", fileControls);
    fputs("\tClick Selected Host to Toggle Persistant IP/Name\n", fileControls);
    fputs("Middle Mouse Button\tClick-and-Drag to Change View\n", fileControls);
    fputs("Right Mouse Button\tShow Menu\n", fileControls);
    fputs("Mouse Wheel\tMove Up/Down\n", fileControls);
    fputs("Up/Down\tMove Forward/Back\n", fileControls);
    fputs("Left/Right\tMove Left/Right\n", fileControls);
    fputs("Shift + Move\tMove Faster\n",fileControls);
    fputs("Home\tRecall Home View\n", fileControls);  //10
    fputs("Ctrl + Home\tRecall Alternate Home View\n", fileControls);
    fputs("Ctrl + F1-F4\tRecall View Position 1-4\n", fileControls);
    fputs("Ctrl\tMultiple Select\n", fileControls);
    fputs("Ctrl + A\tSelect All Hosts\n", fileControls);
    fputs("Ctrl + S\tInvert Selection\n", fileControls);
    fputs("Q/E\tMove Selection Up/Down\n", fileControls);
    fputs("W/S\tMove Selection Forward/Back\n", fileControls);
    fputs("A/D\tMove Selection Left/Right\n", fileControls);
    fputs("F\tFind Hosts\n", fileControls);
    fputs("Tab\tSelect Next Host in Selection\n", fileControls);  //20
    fputs("Ctrl + Tab\tSelect Previous Host in Selection\n", fileControls);
    fputs("T\tToggle Persistant IP/Name for Selection\n", fileControls);
    fputs("C\tCycle Show IP - IP/Name - Name Only\n", fileControls);
    fputs("M\tMake Host\n", fileControls);
    fputs("N\tEdit Hostname for Selected Host\n", fileControls);
    fputs("Ctrl + N\tSelect All Named Hosts\n", fileControls);
    fputs("R\tEdit Remarks for Selected Host\n", fileControls);
    fputs("L\tPress Twice with Different Selected Hosts for Link Line\n", fileControls);
    fputs("Ctrl + L\tDelete Link Line (2nd Selected Host, Press L on 1st)\n", fileControls);
    fputs("Y\tAutomatic Link Lines for All Hosts\n", fileControls);  //30
    fputs("Ctrl + Y\tToggle Automatic Link Lines for New Hosts [L]\n", fileControls);
    fputs("J\tAutomatic Link Lines for Selection\n", fileControls);
    fputs("Ctrl + J\tStop Automatic Link Lines for Selection\n", fileControls);
    fputs("Ctrl + R\tDelete Link Lines for All Hosts\n", fileControls);
    fputs("P\tShow Packets for Selection\n", fileControls);
    fputs("Ctrl + P\tStop Showing Packets for Selection\n", fileControls);
    fputs("U\tShow Packets for All Hosts\n", fileControls);
    fputs("Ctrl + U\tToggle Show Packets for New Hosts [P]\n", fileControls);
    fputs("F1-F4\tShow Packets from Sensor 1-4\n", fileControls);
    fputs("F5\tShow Packets from All Sensors\n", fileControls);  //40
    fputs("-  +\tChange Sensor to Show Packets from\n", fileControls);
    fputs("B\tToggle Show Simulated Broadcasts [B]\n", fileControls);
    fputs("V\tToggle Show Packet Destination Port\n", fileControls);
    fputs("Z\tToggle Fast Packets [F]\n", fileControls);
    fputs("K\tPackets Off\n", fileControls);
    fputs("Page Down\tRecord Packet Traffic\n", fileControls);
    fputs("Insert\tReplay Recorded Packet Traffic\n", fileControls);
    fputs("Page Up\tSkip to Next Packet during Replay Traffic\n", fileControls);
    fputs("End\tStop Record/Replay of Packet Traffic\n", fileControls);
    fputs("F7\tOpen Packet Traffic File...\n", fileControls);  //50
    fputs("F8\tSave Packet Traffic File As...\n", fileControls);
    fputs("Space\tToggle Pause Animation\n", fileControls);
    fputs("Ctrl + K\tAcknowledge All Anomalies\n", fileControls);
    fputs("Ctrl + X\tCut Input Box Text\n", fileControls);
    fputs("Ctrl + C\tCopy Input Box Text\n", fileControls);
    fputs("Ctrl + V\tPaste Input Box Text\n", fileControls);
    fputs("O\tToggle Show OSD\n", fileControls);
    fputs("I\tShow Selected Host Information\n", fileControls);
    fputs("G\tShow Selection Information\n", fileControls);
    fputs("X\tToggle Fullscreen\n", fileControls);  //60
    fputs("H\tShow Help\n", fileControls);
    fputs("Ctrl + Q\tQuit\n", fileControls);
    fclose(fileControls);
  }
}
