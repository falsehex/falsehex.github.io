/* llist-m.cpp - 01 Sep 15
   Linked List Multi
   Copyright 2006-2015 Del Castle  */

#include <pthread.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "llist-m.h"

pthread_mutex_t mtxSafe = PTHREAD_MUTEX_INITIALIZER;

LinkedList::Item::Item(void *data, size_t num, Item *prev)
{
  Data = malloc(num);
  memcpy(Data, data, num);
  Next = 0;
  Prev = prev;
}

LinkedList::Item::~Item()
{
  free(Data);
}

LinkedList::LinkedList()
{
  pFront = 0;
  pBack = 0;
  pItem[0] = 0;
  pItem[1] = 0;
  pItem[2] = 0;
  pItem[3] = 0;
  cntItems = 0;
}

unsigned int LinkedList::Items()
{
  return cntItems;
}

void *LinkedList::Write(unsigned char ptr, void *data, size_t num)
{
  pthread_mutex_lock(&mtxSafe);
  pItem[ptr] = new Item(data, num, pBack);
  if (pBack) pBack->Next = pItem[ptr];
  else pFront = pItem[ptr];
  pBack = pItem[ptr];
  cntItems++;
  pthread_mutex_unlock(&mtxSafe);
  return pItem[ptr]->Data;
}

void LinkedList::Start(unsigned char ptr)
{
  pItem[ptr] = pFront;
}

void LinkedList::End(unsigned char ptr)
{
  pItem[ptr] = pBack;
}

void *LinkedList::Read(unsigned char ptr)
{
  if (pItem[ptr]) return pItem[ptr]->Data;
  return 0;
}

void LinkedList::Next(unsigned char ptr)
{
  if (pItem[ptr]) pItem[ptr] = pItem[ptr]->Next;
}

void LinkedList::Prev(unsigned char ptr)
{
  if (pItem[ptr]) pItem[ptr] = pItem[ptr]->Prev;
}

void *LinkedList::Find(unsigned int item)
{
  Item *pTemp = pFront;
  for (unsigned int cntItem = 1; cntItem < item; cntItem++)
  {
    if (pTemp) pTemp = pTemp->Next;
    else return 0;
  }
  if (pTemp) return pTemp->Data;
  return 0;
}

void LinkedList::Free(unsigned char ptr)
{
  pItem[ptr] = 0;
}

void LinkedList::Delete(unsigned char ptr)
{
  pthread_mutex_lock(&mtxSafe);
  cntItems--;
  Item *pTemp = pItem[ptr];
  pItem[ptr] = pItem[ptr]->Next;
  if (pTemp->Prev) pTemp->Prev->Next = pTemp->Next;
  else pFront = pTemp->Next;
  if (pTemp->Next) pTemp->Next->Prev = pTemp->Prev;
  else pBack = pTemp->Prev;
  pthread_mutex_unlock(&mtxSafe);
  while ((pItem[2] == pTemp) || (pItem[3] == pTemp)) usleep(100);
  delete pTemp;
}

LinkedList::~LinkedList()
{
  pthread_mutex_destroy(&mtxSafe);
}
