<html>
<head>
<meta name='copyright' content='2012-2016 Del Castle' />
<meta charset='UTF-8' />
<meta http-equiv='content-type' content='text/html' />
<link rel='stylesheet' type='text/css' href='fx/css/logalysis.css' />

<link rel='stylesheet' type='text/css' href='fx/css/etree.css' />
<script type='text/javascript' src='fx/js/etree.js'></script>

</head>
<body>

<?php

include "common.php";
session_start();
/*if (isset($_SESSION["las_last_activity"]) && ((time() - $_SESSION["las_last_activity"]) > 3600))
{
  session_unset();
  session_destroy();
} 
$_SESSION["las_last_activity"] = time();*/
if (empty($_SESSION["las_login_user_name"])) exit($login_bounce);

$state_id = (is_numeric($_GET["state_id"]) ? $_GET["state_id"] : 0);
$user_id = (isset($_GET["user_id"]) && is_numeric($_GET["user_id"]) ? $_GET["user_id"] : 0);
$find_job = (isset($_GET["find_job"]) ? $_GET["find_job"] : "");

$link = logalysis_db_connect();

echo "<div class='menu'>";
echo "<a class='menu' href='#' onclick='var strFd = prompt(\"Enter Search Text\", \"{$find_job}\"); if (strFd) location.href = \"job_list.php?state_id={$state_id}&user_id={$user_id}&find_job=\" + escape(strFd.toLowerCase());'>SEARCH" . ($user_id ? " " . get_user_name($link, $user_id) : "") . "</a>";
echo "</div><br />";

echo "<script type='text/javascript'>";
echo "var etrJl = new eTree(\"etrJl\");";
$item = 0;
if ($find_job)
{
  $nodes = "";
  $ref_date = preg_replace("/^(\d{6}).*/", "$1", $find_job, 1, $count);
  $extra = ($count ? "DATE_FORMAT(create_time, '%Y%m') = '{$ref_date}'" : "(LOWER(sensor) LIKE '%" . addslashes($find_job) . "%' OR LOWER(label) LIKE '%" . addslashes($find_job) . "%' OR LOWER(comments) LIKE '%" . addslashes($find_job) . "%' OR LOWER(source_ip) LIKE '%" . addslashes($find_job) . "%' OR LOWER(target_ip) LIKE '%" . addslashes($find_job) . "%' OR job_id IN (SELECT job_id FROM notes WHERE LOWER(remarks) LIKE LOWER('%" . addslashes($find_job) . "%') GROUP BY job_id))");
  if ($user_id) $extra .= " AND assign_user_id = {$user_id}";
  $result = mysqli_query($link, "SELECT DATE_FORMAT(create_time, '%Y%m%d'), ref_day, label, job_id FROM jobs WHERE {$extra} ORDER BY create_time DESC, ref_day DESC");
  while ($job = mysqli_fetch_row($result))
  {
    $ref_no = "{$system}-{$job[0]}-" . str_pad($job[1], $ref_pad, "0", STR_PAD_LEFT);
    $label = "{$ref_no} " . addslashes($job[2]);
    if (!$count || (stristr($ref_no, $find_job))) $nodes .= "etrJl.add(" . ++$item . ", 0, false, \"list\", \"{$label}\", \"menu_main.php?job_id={$job[3]}&ref_no={$ref_no}&find_job=" . urlencode($find_job) . "\", \"frame_menu_main\", \"{$label}\");";
  }
  mysqli_free_result($result);
  echo "etrJl.add(0, -1, true, \"folder\", \"SEARCH" . ($user_id ? " " . get_user_name($link, $user_id) : "") . ": {$find_job} ({$item})\");";
  echo $nodes;
}
else
{
  echo "etrJl.add(0, -1, true, \"folder\", \"" . get_state_name($link, $state_id) . " " . get_user_name($link, $user_id) . "\");";
  $extra = ($user_id ? " AND assign_user_id = {$user_id}" : "");
  $result1 = mysqli_query($link, "SELECT * FROM priorities");
  while ($priority = mysqli_fetch_row($result1))
  {
    $count = db_result($link, "SELECT COUNT(1) FROM jobs WHERE state_id = {$state_id} AND priority_id = {$priority[0]}{$extra}");
    if ($count)
    {
      echo "etrJl.add(" . ++$item . ", 0, true, \"folder\", \"{$priority[1]} ({$count})\");";
      $parent = $item;
      $result2 = mysqli_query($link, "SELECT DATE_FORMAT(create_time, '%Y%m%d'), ref_day, label, job_id FROM jobs WHERE state_id = {$state_id} AND priority_id = {$priority[0]}{$extra} ORDER BY create_time DESC, ref_day DESC");
      while ($job = mysqli_fetch_row($result2))
      {
        $ref_no = "{$system}-{$job[0]}-" . str_pad($job[1], $ref_pad, "0", STR_PAD_LEFT);
        $label = "{$ref_no} " . addslashes($job[2]);
        echo "etrJl.add(" . ++$item . ", {$parent}, false, \"list\", \"{$label}\", \"menu_main.php?job_id={$job[3]}&ref_no={$ref_no}\", \"frame_menu_main\", \"{$label}\");";
      }
      mysqli_free_result($result2);
    }
  }
  mysqli_free_result($result1);
}
echo "etrJl.write();";
echo "</script>";

mysqli_close($link);

?>

</body>
</html>
