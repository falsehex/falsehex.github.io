<?php

include "plugins/cred/snort.cred.php";

$link = mysqli_connect($snort_db_host, $snort_db_user, $snort_db_pass, $snort_db_name);
if (!$link) die("Error: mysql db {$snort_db_name} connect failed");

$part = explode(";", $file_id);
$dump = db_result($link, "SELECT UNHEX(data_payload) FROM data WHERE sid = {$part[0]} AND cid = {$part[1]}");
$file_dump = fopen("{$file_name}.dump", "w");
fwrite($file_dump, $dump);
fclose($file_dump);
if ($part[2] == 6) $extra = " -T {$part[3]},{$part[4]}";  //TCP
else if ($part[2] == 17) $extra = " -u {$part[3]},{$part[4]}";  //UDP
else $extra = " -i 1";  //IP
exec("od -Ax -tx1 -v \"{$file_name}.dump\" | text2pcap{$extra} - \"{$file_name}.pcap\"");
unlink("{$file_name}.dump");
$file_name .= ".pcap";

mysqli_close($link);

?>
