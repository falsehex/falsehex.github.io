/* etree-mod.js - Version 1.0m  22 Dec 16
   eTree - HTML Tree Menu (MODIFIED)
   Copyright 2012-2016 Del Castle
*/

var aryNodes = [];
var imgPath = "img/";

function padNode(id, pad, end)
{
  var strHtml = "";
  if (pad.length)
  {
    pad[pad.length - 1] = (id == end ? "end" : "join");
    for (var cnt in pad) strHtml += "<img src='" + imgPath + pad[cnt] + ".png' />";
    if (id == end) pad[pad.length - 1] = null;
  }
  return strHtml;
}

function dragImage(evt)
{
  evt.dataTransfer.setData("inid", evt.target.id);
}

function allowDrop(evt)
{
  evt.preventDefault();
}

function removeNode(id)
{
  for (var cnt = 1; cnt < aryNodes.length; cnt++)
  {
    if (aryNodes[cnt].pid == id) removeNode(cnt);
  }
  aryNodes[id].pid = -2;
}

function dropImage(evt)
{
  evt.preventDefault();
  var inid = evt.dataTransfer.getData("inid");
  if (inid)
  {
    if (evt.target.id == -1) removeNode(inid);
    else
    {
      aryNodes[inid].pid = evt.target.id;
      aryNodes[evt.target.id].open = true;
    }
    reloadTree();
  }
}

function showFolder(id)
{
  var styFolder = document.getElementById("show" + id).style;
  document.getElementById(id).src = imgPath + (styFolder.display == "none" ? "open" : "closed") + ".png";
  styFolder.display = (styFolder.display == "none" ? "block" : "none");
}

function updateTree(id, opt, val)
{
  switch (opt)
  {
    case 0: aryNodes[id].logic = val; break;
    case 1: aryNodes[id].item = val; break;
    case 2: aryNodes[id].fields = val; break;
    case 3: aryNodes[id].type = val; break;
    case 4: aryNodes[id].value = val; break;
    case 5: aryNodes[id].comment = val; break;
  }
}

function dataNode(id)
{
  var cnt;
  var cntFields = 0;
  var strHtml = "<span>";
  strHtml += "<input type='hidden' name='node' value='" + id + "' />";
  strHtml += "<input type='hidden' name='parent' value='" + aryNodes[id].pid + "' />";
  strHtml += "<input type='hidden' name='inid' value='" + aryNodes[id].inid + "' />";
  if ((aryNodes[id].logic == "AND") || (aryNodes[id].logic == "OR") )
  {
    if (id) strHtml += "<select name='item' onchange='updateTree(" + id + ", 0, this.options[this.selectedIndex].value);'><option" + (aryNodes[id].logic == "AND" ? " selected" : "") + ">AND</option><option" + (aryNodes[id].logic == "OR" ? " selected" : "") + ">OR</option></select>";
    else strHtml += "&nbsp;OR<input type='hidden' name='item' value='OR' />";
    for (cnt = 0; cnt < 5; cnt++) strHtml += "<input type='hidden' name='item' />";
  }
  else
  {
    strHtml += "<select name='item' onchange='updateTree(" + id + ", 1, this.options[this.selectedIndex].value); changeItems(this);'>";
    for (cnt = 0; cnt < iocTerms.length; cnt++)
    {
      strHtml += "<option value='" + iocTerms[cnt][0] + "'" + (iocTerms[cnt][0] == aryNodes[id].item ? " selected" : "") + ">" + iocTerms[cnt][0].replace("Item", "") + "</option>";
      if (iocTerms[cnt][0] == aryNodes[id].item) cntFields = cnt;
    }
    strHtml += "</select>&nbsp;<select name='item' onchange='updateTree(" + id + ", 2, this.options[this.selectedIndex].value);'>";
    for (cnt = 1; cnt < iocTerms[cntFields].length; cnt++) strHtml += "<option" + (iocTerms[cntFields][cnt] == aryNodes[id].fields ? " selected" : "") + ">" + iocTerms[cntFields][cnt] + "</option>";
    strHtml += "</select>&nbsp;";
    strHtml += "<select name='item' onchange='updateTree(" + id + ", 0, this.options[this.selectedIndex].value);'><option" + (aryNodes[id].logic == "is" ? " selected" : "") + ">is</option><option value='isnot'" + (aryNodes[id].logic == "isnot" ? " selected" : "") + ">is not</option><option" + (aryNodes[id].logic == "contains" ? " selected" : "") + ">contains</option><option value='containsnot'" + (aryNodes[id].logic == "containsnot" ? " selected" : "") + ">contains not</option></select>&nbsp;";
    strHtml += "<select name='item' onchange='updateTree(" + id + ", 3, this.options[this.selectedIndex].value);'><option" + (aryNodes[id].type == "string" ? " selected" : "") + ">string</option><option" + (aryNodes[id].type == "int" ? " selected" : "") + ">int</option><option" + (aryNodes[id].type == "date" ? " selected" : "") + ">date</option><option" + (aryNodes[id].type == "IP" ? " selected" : "") + ">IP</option><option" + (aryNodes[id].type == "md5" ? " selected" : "") + ">md5</option><option" + (aryNodes[id].type == "sha1" ? " selected" : "") + ">sha1</option></select>&nbsp;&nbsp;";
    strHtml += "<input type='text' name='item' size='" + (aryNodes[id].value.length ? aryNodes[id].value.length + 10 : 32) + "' value='" + aryNodes[id].value.replace(/'/g, "&apos;") + "' onchange='updateTree(" + id + ", 4, this.value);' />";
    strHtml += "<input type='text' name='item' size='" + (aryNodes[id].comment.length ? aryNodes[id].comment.length + 10 : 32) + "' value='" + aryNodes[id].comment.replace(/'/g, "&apos;") + "' onchange='updateTree(" + id + ", 5, this.value);' />";
  }
  strHtml += "</span>";
  return strHtml;
}

function lastChild(id)
{
  var idLast = 0;
  for (var cnt = 1; cnt < aryNodes.length; cnt++)
  {
    if (aryNodes[cnt].pid == id) idLast = cnt;
  }
  return idLast;
}

function writeNode(pid, pad, end, pend)
{
  var strHtml = "";
  if (pid != -1)
  {
    strHtml += "<div>";
    strHtml += padNode(pid, pad, pend);
    if (pad.length) pad[pad.length - 1] = (pad[pad.length - 1] ? "line" : "blank");
    strHtml += "<img id='" + pid + "' src='" + imgPath + (aryNodes[pid].open ? "open" : "closed") + ".png' draggable='true' ondragstart='dragImage(event);' ondragover='allowDrop(event);' ondrop='dropImage(event);' onclick='showFolder(" + pid + ");' />";
    strHtml += dataNode(pid);
    strHtml += "</div>";
    pad.push("");
    strHtml += "<div id='show" + pid + "' style='display:" + (aryNodes[pid].open ? "block" : "none") + "'>";
  }
  var idLast;
  for (var cnt = 0; cnt < aryNodes.length; cnt++)
  {
    if (aryNodes[cnt].pid == pid)
    {
      if ((idLast = lastChild(cnt))) strHtml += writeNode(cnt, pad, idLast, end);
      else
      {
        strHtml += padNode(cnt, pad, end);
        strHtml += "<img id='" + cnt + "' src='" + imgPath + aryNodes[cnt].img + ".png' draggable='true' ondragstart='dragImage(event);'" + (aryNodes[cnt].img == "folder" ? " ondragover='allowDrop(event);' ondrop='dropImage(event);'" : "") + " />";
        strHtml += dataNode(cnt);
        strHtml += "<br />";
      }
    }
  }
  if (pid != -1)
  {
    strHtml += "</div>";
    pad.pop();
  }
  return strHtml;
}

function createNode(pid, open, img, inid, logic, item, fields, type, value, comment)
{
  this.pid = pid;
  this.open = open;
  this.img = img;
  this.inid = inid;
  this.logic = logic;
  this.item = item;
  this.fields = fields;
  this.type = type;
  this.value = value;
  this.comment = comment;
}

function addTree(pid, open, img, inid, logic, item, fields, type, value, comment)
{
  aryNodes.push(new createNode(pid, open, img, inid, logic, item, fields, type, value, comment));
  if (pid != -1) aryNodes[pid].open = true;
}

function writeTree()
{
  var aryPad = [];
  document.write("<img id='-1' style='position:fixed;right:0' src='" + imgPath + "bin.png' ondragover='allowDrop(event);' ondrop='dropImage(event);' />");
  document.write("<div id='etree' class='etree'>");
  document.write(writeNode(-1, aryPad, 0, 0));
  document.write("</div>");
}

function reloadTree()
{
  var aryPad = [];
  document.getElementById("etree").innerHTML = writeNode(-1, aryPad, 0, 0);
}
