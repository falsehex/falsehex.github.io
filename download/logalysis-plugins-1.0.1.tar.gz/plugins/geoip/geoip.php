<?php

function geo_lookup($ip, $full)
{
  $val = shell_exec("perl -e \"print unpack 'N', pack 'C4', split '\.', '{$ip}'\"");
  $geo_csv = fopen("plugins/geoip/GeoIPCountryWhois.csv", "r");
  while ($line = fgets($geo_csv))
  {
    $row = preg_split("/\"([^\"]*)\"|,/", $line, -1, PREG_SPLIT_NO_EMPTY | PREG_SPLIT_DELIM_CAPTURE);
    if (($row[2] <= $val) && ($row[3] >= $val))
    {
      fclose($geo_csv);
      return ($full ? "{$row[4]};" : "") . trim($row[5]);
    }
  }
  fclose($geo_csv);
  return "";
}

function geo_coord($loc)
{
  $geo_csv = fopen("plugins/geoip/GeoCountryLoc.csv", "r");
  while ($line = fgets($geo_csv))
  {
    $row = preg_split("/,/", $line);
    if ($row[0] == $loc)
    {
      fclose($geo_csv);
      return "{$row[1]}," . trim($row[2]);
    }
  }
  fclose($geo_csv);
  return "-60.0,-150.0";
}

?>
