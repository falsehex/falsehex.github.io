<html>
<head>
<meta name='copyright' content='2012-2016 Del Castle' />
<meta charset='UTF-8' />
<meta http-equiv='content-type' content='text/html' />

<?php

echo "<frameset cols='260,*' border='4px'>";
echo "<frame name='frame_note_list' src='note_list.php?job_id={$_GET["job_id"]}' />";
echo "<frame name='frame_note_show' src='blank.html' />";
echo "</frameset>";

?>

</head>
</html>
