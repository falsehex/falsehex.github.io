<?php

$link = logalysis_db_connect();

if (empty($nohdr)) echo "<h4>LOGALYSIS AUDIT</h4>";
echo "<table class='esort'>";
echo "<tr><th></th><th>Time</th><th>User</th><th>Job</th><th>Action</th><th>Details</th></tr>";
$count = 0;
$extra = ($start_time ? " WHERE save_time >= '" . addslashes($start_time) . "'" : "");
if ($finish_time) $extra .= ($extra ? " AND" : " WHERE") . " save_time <= '" . addslashes($finish_time) . "'";
$result = mysqli_query($link, "SELECT save_time, save_user_id, job_id, action, details FROM trail{$extra} ORDER BY save_time LIMIT {$limit}");
while ($row = mysqli_fetch_row($result))
{
  echo "<tr onclick='txtBold(this.style);'><td>" . ++$count . "</td>";
  $row[1] = get_user_name($link, $row[1]);
  if (preg_match("/user_id = (\d+)/", $row[4], $matches)) $row[4] = preg_replace("/user_id = \d+/", "user_id = " . get_user_name($link, $matches[1]), $row[4]);
  if (preg_match("/state_id = (\d+)/", $row[4], $matches)) $row[4] = preg_replace("/state_id = \d+/", "state_id = " . get_state_name($link, $matches[1]), $row[4]);
  foreach ($row as &$cell) echo "<td>{$cell}</td>";
  echo "</tr>";
}
mysqli_free_result($result);
echo "</table>";

mysqli_close($link);

?>
