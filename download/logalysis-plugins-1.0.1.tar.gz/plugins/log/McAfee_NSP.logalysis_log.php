<?php

include "plugins/misc/mcafee_nsp.php";
include "plugins/cred/mcafee_nsp.cred.php";

$link = logalysis_db_connect();

echo "<script type='text/javascript'>";
echo "function textLog() { var aryTd, aryTr = document.getElementsByTagName(\"tr\"), winTl = popUp(\"\"); winTl.document.write(\"<pre>\"); for (var cnt = 0; cnt < aryTr.length; cnt++) { aryTd = aryTr[cnt].getElementsByTagName(\"td\"); if (aryTd[0]) winTl.document.write(aryTd[1].textContent + \"\\t\" + aryTd[6].textContent + \"\\t\" + aryTd[8].textContent + \"\\t\" + aryTd[9].textContent + \"\\t\" + aryTd[10].textContent + \"\\t\" + aryTd[11].textContent + \"\\t\" + aryTd[12].textContent + \"\\n\"); } winTl.document.write(\"</pre>\"); }";
echo "function mnlJob(objTr) { aryTd = objTr.getElementsByTagName(\"td\"); parent.location.href = \"details_show.php?details=\" + escape(\"0;0;1;4;{$login_user_id};\" + aryTd[4].textContent + \";McAfee NSP Alert: \" + aryTd[6].textContent.replace(/'/g, \"\\\"\") + \";Detection: \" + aryTd[5].textContent + \"\\nAID: \" + aryTd[7].textContent + \"\\nCategory: \" + aryTd[13].textContent + \"\\nResult: \" + aryTd[3].textContent + \";;;;;\" + aryTd[1].textContent + \";\" + aryTd[8].textContent + \";\" + aryTd[9].textContent + \";\" + aryTd[10].textContent + \";\" + aryTd[11].textContent + \";\" + aryTd[12].textContent); }";
echo "</script>";

if (empty($nohdr)) echo "<h4>MCAFEE NSP</h4>";
echo "<table class='esort'>";
echo "<tr><th></th><th>Time</th><th>Priority</th><th>Result</th><th>Sensor</th><th>Detection</th><th>Alert</th><th>AID</th><th>Protocol</th><th>Source IP</th><th>Port</th><th>Target IP</th><th>Port</th><th>Category</th><th>Subcategory</th><th>EID</th><th>Actions</th></tr>";
$count = 0;
$result = mysqli_query($link, "SELECT time_1, num_1, char_1_64, char_3_255, char_2_64, char_4_255, num_2, protocol, source_ip, source_port, target_ip, target_port, char_5_255, char_6_255, num_3, num_4 FROM events WHERE log_id = {$log_id} ORDER BY time_1");
while ($row = mysqli_fetch_row($result))
{
  echo "<tr onclick='txtBold(this.style);'><td>" . ++$count . "</td>";
  $row[1] = mcafee_nsp_priority($row[1], FALSE, FALSE);
  $row[6] = "0x" . dechex($row[6]);
  $row[6] = "<a class='action' href='javascript:popUp(\"{$mcafee_nsp_www_host}/intruvert/attackEncyclopedia/en/docs/{$row[6]}.html\");'>{$row[6]}</a>";
  $row[7] = protocol_name($row[7]);
  $row[15] = ($row[15] ? "<a class='action' href='pcap_get.php?plugin=McAfee_NSP&file_id={$row[15]}'>PCAP</a> <a class='action' href='file_layout.php?job_id={$job_id}&ref_no={$ref_no}&search=McAfee_NSP;{$row[0]};{$row[0]};{$row[8]};{$row[9]};{$row[10]};{$row[11]}&file_id={$row[15]}' target='frame_show'>FILE</a> " : "") . "<a class='action' href='javascript:void(0);' onclick='mnlJob(this.parentNode.parentNode);'>JOB</a>";
  $row[8] = "<a class='action' href='javascript:popUp(\"host_show.php?host_ip={$row[8]}\");'>{$row[8]}</a>";
  $row[10] = "<a class='action' href='javascript:popUp(\"host_show.php?host_ip={$row[10]}\");'>{$row[10]}</a>";
  foreach ($row as &$cell) echo "<td>{$cell}</td>";
  echo "</tr>";
}
mysqli_free_result($result);
echo "</table>";

mysqli_close($link);

?>
