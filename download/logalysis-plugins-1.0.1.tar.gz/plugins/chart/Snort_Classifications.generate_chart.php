<?php

include "plugins/cred/snort.cred.php";

$link = mysqli_connect($snort_db_host, $snort_db_user, $snort_db_pass, $snort_db_name);
if (!$link) die("Error: mysql db {$snort_db_name} connect failed");

if (!isset($shape)) $shape = (isset($_POST["shape"]) ? $_POST["shape"] : "");
if (!isset($show_vals)) $show_vals = (isset($_POST["show_vals"]) ? $_POST["show_vals"] : "");

$table = "<table id='snort_classifications_{$shape}_table' class='chart'><tr><th class='chart'></th><th class='chart'>Classification</th><th class='chart'>Events</th></tr>";
$count = 0;
$extra = ($start_time ? " WHERE timestamp >= '{$start_time}'" : "");
if ($finish_time) $extra .= ($extra ? " AND" : " WHERE") . " timestamp <= '{$finish_time}'";
unset($classifications);
$result = mysqli_query($link, "SELECT signature, COUNT(1) FROM event{$extra} GROUP BY signature");
while ($row = mysqli_fetch_row($result))
{
  $row[0] = db_result($link, "SELECT sig_class_name FROM sig_class WHERE sig_class_id = (SELECT sig_class_id FROM signature WHERE sig_id = {$row[0]})");
  if (isset($classifications[$row[0]])) $classifications[$row[0]] += $row[1];
  else $classifications[$row[0]] = $row[1];
}
mysqli_free_result($result);
if (isset($classifications))
{
  arsort($classifications);
  foreach ($classifications as $key => &$val)
  {
    $table .= "<tr><td class='chart'>" . ++$count . "</td>";
    $table .= "<td class='chart'>{$key}</td>";
    $table .= "<td class='chart'>{$val}</td></tr>";
    if ($count == $limit) break;
  }
}
$table .= "</table>";
if ($count)
{
  if (empty($nohdr)) echo "<h4>SNORT TOP {$limit} CLASSIFICATIONS<br />" . ($start_time ? date("d-m-Y H:i:s", strtotime($start_time)) . " -" : "") . ($finish_time ? "- " . date("d-m-Y H:i:s", strtotime($finish_time)) : "") . "</h4>";
  if (empty($nogfx)) echo "<canvas id='snort_classifications_{$shape}_canvas' width='640' height='320' ondblclick='window.open(this.toDataURL());'></canvas>";
  echo $table;

  if (empty($nogfx)) echo "<script type='text/javascript'>{$shape}Chart(\"snort_classifications_{$shape}\", 0, 2" . ($shape == "vbar" ? ", \"{$show_vals}\"" : "") . ");</script>";
}
else echo "<h5>NO EVENTS FOUND!</h5>";

mysqli_close($link);

?>
