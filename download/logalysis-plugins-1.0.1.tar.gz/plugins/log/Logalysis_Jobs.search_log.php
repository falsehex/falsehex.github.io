<?php

echo "<input type='hidden' name='nosave' value='true' />";
echo "<p>Limit <input type='text' name='limit' size='7' maxlength='5' value='{$limit}' /></p>";
search_time($search[1], $search[2]);
echo "<p><input type='checkbox' name='report' />{$lbl_report}</p>"

?>
