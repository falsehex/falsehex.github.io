#!/bin/bash

if [ -f "${1}" ]
then
  if [ ! -d "${1}...dir" ]; then
    mkdir "${1}...dir"
  fi
  tcpflow -cr "${1}" | foremost -i - -t all -o "${1}...dir"
  if [ `ls -1 "${1}...dir" | wc -l` -eq 0 ]; then
    rm -rf "${1}...dir"
  fi
fi
