<html>
<head>
<meta name='copyright' content='2012-2016 Del Castle' />
<meta charset='UTF-8' />
<meta http-equiv='content-type' content='text/html' />
<link rel='stylesheet' type='text/css' href='fx/css/logalysis.css' />

<script type='text/javascript'>
var cntRt = "";

function showCount()
{
  if (document.getElementById("ancCt").textContent == cntRt) document.getElementById("ancCt").textContent = "";
  cntRt = document.getElementById("ancCt").textContent;
  setTimeout("showCount()", 2000);
}
</script>

</head>
<body onload='showCount();'>

<?php

session_start();

$job_id = (isset($_GET["job_id"]) ? $_GET["job_id"] : 0);

if ($job_id)
{
  $ref_no = $_GET["ref_no"];
  $tabs = array("details_show.php?job_id={$job_id}&ref_no={$ref_no}", "note_layout.php?job_id={$job_id}", "log_layout.php?job_id={$job_id}&ref_no={$ref_no}", "file_layout.php?job_id={$job_id}&ref_no={$ref_no}");

  if (empty($_GET["action"]))
  {
    echo "<script type='text/javascript'>top.frame_show.location.href = \"";
    if (($ref_no == "SCRATCHPAD") && ($_SESSION["las_menu_tab"] < 2)) $_SESSION["las_menu_tab"] = 2;
    echo $tabs[$_SESSION["las_menu_tab"]];
    echo "\";</script>";
  }
}

echo "<div class='menu'>";
if ($job_id)
{
  if ($job_id != 1)  //SCRATCHPAD
  {
    echo "<a class='menu' href='{$tabs[0]}' target='frame_show'>DETAILS</a>";
    echo "<a class='menu' href='{$tabs[1]}' target='frame_show'>NOTES</a>";
  }
  echo "<a class='menu' href='{$tabs[2]}' target='frame_show'>LOGS</a>";
  echo "<a class='menu' href='{$tabs[3]}' target='frame_show'>FILES</a>";
  echo "<a class='menu' style='color:#FFFFFE; float:right'>{$ref_no}</a>";
}
echo "<a class='fmenu' href='chart_layout.html' target='frame_show'>CHARTS</a>";
echo "<a class='fmenu' href='report_search.php' target='frame_show'>REPORTS</a>";
echo "<a class='fmenu' href='host_show.php' target='frame_show'>HOSTS</a>";
echo "<a class='fmenu' href='realtime_show.php' target='frame_show'>REAL-TIME</a>";
echo "<a id='ancCt' class='menu' style='color:#BBFFBB'></a>";
echo "</div>";

?>

</body>
</html>
