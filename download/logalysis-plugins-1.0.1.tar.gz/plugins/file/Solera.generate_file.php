<?php

include "plugins/cred/solera.cred.php";

$pattern = "/(\d{4})-(\d{2})-(\d{2}) (\d{2}):(\d{2}):(\d{2})/";
$replace = "$2.$3.$1.$4.$5.$6";
if ($search[3] && $search[5]) $extra = "/ipv4_address/{$search[3]}_and_{$search[5]}";
else if ($search[3]) $extra = "/ipv4_address/{$search[3]}";
else if ($search[5]) $extra = "/ipv4_address/{$search[5]}";
if ($search[4] && $search[6]) $extra .= "/tcp_port/{$search[4]}_and_{$search[6]}";
else if ($search[4]) $extra .= "/tcp_port/{$search[4]}";
else if ($search[6]) $extra .= "/tcp_port/{$search[6]}";
$file_name .= ".pcap";
exec("wget --no-check-certificate -O \"{$file_name}\" \"{$solera_www_host}/ws/pcap?method=deepsee&user={$solera_www_user}&password={$solera_www_pass}&path=/timespan/" . preg_replace($pattern, $replace, $search[1]) . "." . preg_replace($pattern, $replace, $search[2]) . "{$extra}\"");

?>
