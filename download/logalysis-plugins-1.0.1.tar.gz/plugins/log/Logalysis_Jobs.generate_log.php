<?php

$link = logalysis_db_connect();

if (!isset($report)) $report = (isset($_GET["report"]) ? $_GET["report"] : "");

if (empty($nohdr)) echo "<h4>LOGALYSIS JOBS</h4>";
echo "<table class='esort'>";
echo "<tr><th></th><th>Reference</th><th>Created</th><th>Label</th><th>Priority</th><th>Status</th><th>Closed</th></tr>";
$count = 0;
$extra = " WHERE job_id != 1";
if ($start_time) $extra .= " AND create_time >= '" . addslashes($start_time) . "'";
if ($finish_time) $extra .= " AND create_time <= '" . addslashes($finish_time) . "'";
if ($report) $extra .= " AND report = TRUE";
$result = mysqli_query($link, "SELECT ref_day, create_time, label, priority_id, state_id, close_time FROM jobs{$extra} ORDER BY create_time, ref_day LIMIT {$limit}");
while ($row = mysqli_fetch_row($result))
{
  echo "<tr onclick='txtBold(this.style);'><td>" . ++$count . "</td>";
  $row[0] = "{$system}-" . date("Ymd", strtotime($row[1])) . "-" . str_pad($row[0], $ref_pad, "0", STR_PAD_LEFT);
  $row[3] = db_result($link, "SELECT name FROM priorities WHERE priority_id = {$row[3]}");
  $row[4] = get_state_name($link, $row[4]);
  foreach ($row as &$cell) echo "<td>{$cell}</td>";
  echo "</tr>";
}
mysqli_free_result($result);
echo "</table>";

mysqli_close($link);

?>
