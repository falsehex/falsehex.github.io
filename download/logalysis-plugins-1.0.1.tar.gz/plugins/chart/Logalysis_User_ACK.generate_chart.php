<?php

$link = logalysis_db_connect();

if (!isset($shape)) $shape = (isset($_POST["shape"]) ? $_POST["shape"] : "");
if (!isset($show_vals)) $show_vals = (isset($_POST["show_vals"]) ? $_POST["show_vals"] : "");

$table = "<table id='logalysis_user_ack_{$shape}_table' class='chart'><tr><th class='chart'></th><th class='chart'>User</th><th class='chart'>ACK</th><th class='chart'>Time</th></tr>";
$count = 0;
unset($users);
$logalysis_logs = scandir("/var/log/logalysis");
foreach ($logalysis_logs as &$file)
{
  if (preg_match("/^ack\.log/", $file))
  {
    $ack_log = gzopen("/var/log/logalysis/{$file}", "r");
    while ($line = gzgets($ack_log, 4096))
    {
      $row = preg_split("/\s\"([^\"]*)\"|\s/", $line, -1, PREG_SPLIT_NO_EMPTY | PREG_SPLIT_DELIM_CAPTURE);
      $process = TRUE;
      if ($start_time && ($row[0] < strtotime($start_time))) $process = FALSE;
      if ($process && $finish_time && ($row[0] > strtotime($finish_time))) $process = FALSE;
      if ($process)
      {
        if (isset($users[$row[1]]))
        {
          if ($row[2] == "ACK") $users[$row[1]][0]++;
          $users[$row[1]][1] += $row[7];
        }
        else $users[$row[1]] = array(($row[2] == "ACK" ? 1 : 0), $row[7]);
      }
    }
    gzclose($ack_log);
  }
}
if (isset($users))
{
  ksort($users);
  foreach ($users as $key => &$val)
  {
    $actual = db_result($link, "SELECT actual FROM users WHERE name = '{$key}'");
    if ($actual) $key = $actual;
    $val[1] = date("z\D G\H i\M", $val[1]);
    $table .= "<tr><td class='chart'>" . ++$count . "</td>";
    $table .= "<td class='chart'>{$key}</td>";
    $table .= "<td class='chart'>{$val[0]}</td>";
    $table .= "<td class='chart'>{$val[1]}</td></tr>";
  }
}
$table .= "</table>";
if ($count)
{
  if (empty($nohdr)) echo "<h4>LOGALYSIS USER ACK<br />" . ($start_time ? date("d-m-Y H:i:s", strtotime($start_time)) . " -" : "") . ($finish_time ? "- " . date("d-m-Y H:i:s", strtotime($finish_time)) : "") . "</h4>";
  if (empty($nogfx)) echo "<canvas id='logalysis_user_ack_{$shape}_canvas' width='640' height='320' ondblclick='window.open(this.toDataURL());'></canvas>";
  echo $table;

  if (empty($nogfx)) echo "<script type='text/javascript'>{$shape}Chart(\"logalysis_user_ack_{$shape}\", 0, 2" . ($shape == "vbar" ? ", \"{$show_vals}\"" : "") . ");</script>";
}
else echo "<h5>NO EVENTS FOUND!</h5>";

mysqli_close($link);

?>
