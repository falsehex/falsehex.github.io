<?php

include "plugins/log/Apache_Access.generate_log.php";

echo "<hr />";

include "plugins/log/Snort.generate_log.php";

?>
