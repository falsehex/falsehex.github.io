<?php

include "plugins/cred/mcafee_nsp.cred.php";

$link = mysqli_connect($mcafee_nsp_db_host, $mcafee_nsp_db_user, $mcafee_nsp_db_pass, $mcafee_nsp_db_name);
if (!$link) die("Error: mysql db {$mcafee_nsp_db_name} connect failed");

$count = 0;
$pcap_files = "";
$part = explode(";", $file_id);
$result1 = mysqli_query($link, "SELECT packetLogId FROM iv_alert WHERE state = {$part[3]} AND attackIdRef = '{$part[0]}' AND sourceIPAddr = '{$part[1]}' AND UNIX_TIMESTAMP(creationTime) <= {$part[2]}");
while ($plog = mysqli_fetch_row($result1))
{
  if ($plog[0])
  {
    $result2 = mysqli_query($link, "SELECT packetData FROM iv_packetlog WHERE packetLogId = {$plog[0]} ORDER BY creationSeqNumber");
    while ($pdmp = mysqli_fetch_row($result2))
    {
      $pcap_name = "{$file_name}_" . ++$count . ".pcap";
      $file_dump = fopen("{$file_name}.dump", "w");
      fwrite($file_dump, $pdmp[0]);
      fclose($file_dump);
      exec("od -Ax -tx1 -v \"{$file_name}.dump\" | text2pcap - \"{$pcap_name}\"");
      unlink("{$file_name}.dump");
      if (file_exists($pcap_name)) $pcap_files .= "\"{$pcap_name}\" ";
    }
    mysqli_free_result($result2);
  }
}
mysqli_free_result($result1);
$file_name .= ".pcap";
exec("mergecap -w \"{$file_name}\" {$pcap_files}");
exec("rm -f {$pcap_files}");

mysqli_close($link);

?>
