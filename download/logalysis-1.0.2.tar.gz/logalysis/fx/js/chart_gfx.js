/* Copyright 2012-2016 Del Castle */

clrFn = ["#FF3300", "#F43300", "#FF6600", "#F46600", "#FF9900", "#F49900", "#FFCC00", "#F4CC00", "#FFFF00", "#F4FF00"];
clrMb = ["#000000", "#FF7F00", "#007FFF", "#7F7F00", "#7F007F", "#007F7F", "#7F7F7F"];
clrPi = ["#FF3300", "#FF6600", "#FF9900", "#FFCC00", "#FFFF00", "#006300", "#008A00", "#00B100", "#00D800", "#00FF00", "#0033FF", "#0066FF", "#0099FF", "#00CCFF", "#00FFFF"];
clrVb = ["#3030FF", "#4040FF", "#5050FF", "#6060FF", "#7070FF", "#8080FF", "#9090FF", "#A0A0FF", "#B0B0FF", "#C0C0FF"];

function funChart(objs, key, value)
{
  var cnvFn = document.getElementById(objs + "_canvas");
  var ctxCv = cnvFn.getContext("2d");
  var aryTr = document.getElementById(objs + "_table").getElementsByTagName("tr");
  var cnt, aryTd, aryKy = [], aryVl = [];
  for (cnt = 0; cnt < aryTr.length; cnt++)
  {
    aryTd = aryTr[cnt].getElementsByTagName("td");
    aryKy.push(aryTd[key].textContent);
    aryVl.push(aryTd[value].textContent);
  }
  var centre = cnvFn.width / 2;
  var padding = 100;
  var wchunk = (cnvFn.width - (centre + padding)) / aryKy.length;
  var hchunk = (cnvFn.height - 60) / aryKy.length;
  ctxCv.fillStyle = "white";
  ctxCv.fillRect(0, 0, cnvFn.width, cnvFn.height);
  ctxCv.strokeStyle = "black";
  for (cnt = 0; cnt < aryKy.length; cnt++)
  {
    ctxCv.lineWidth = 2;
    ctxCv.beginPath();
    ctxCv.moveTo((wchunk * (cnt + 1)) + padding, (hchunk * (cnt + 1)) + 40);
    ctxCv.lineTo((wchunk * cnt) + padding, (hchunk * cnt) + 40);
    ctxCv.lineTo(cnvFn.width - ((wchunk * cnt) + padding), (hchunk * cnt) + 40);
    ctxCv.lineTo(cnvFn.width - ((wchunk * (cnt + 1)) + padding), (hchunk * (cnt + 1)) + 40);
    ctxCv.stroke();
    ctxCv.fillStyle = clrFn[cnt * 2];
    ctxCv.fill();
    ctxCv.save();
    ctxCv.scale(10, 1);
    ctxCv.lineWidth = 1;
    ctxCv.beginPath();
    ctxCv.arc(centre / 10, (hchunk * cnt) + 40, (centre - ((wchunk * cnt) + padding + 3)) / 10, 0, Math.PI * 2, false);
    ctxCv.stroke();
    ctxCv.fillStyle = clrFn[(cnt * 2) + 1];
    ctxCv.fill();
    ctxCv.restore();
    ctxCv.font = "Bold 12px Tahoma, Geneva, sans-serif";
    ctxCv.fillStyle = "black";
    ctxCv.fillText(aryKy[cnt], centre - ((aryKy[cnt].length * 7.3) / 2), (hchunk * cnt * 0.935) + (hchunk / 2) + 38);
    ctxCv.font = "11px Tahoma, Geneva, sans-serif";
    ctxCv.fillText(aryVl[cnt], centre - ((aryVl[cnt].length * 5.3) / 2), (hchunk * cnt * 0.935) + (hchunk / 2) + 54);
  }
  ctxCv.lineWidth = 2;
  ctxCv.strokeRect(0, 0, cnvFn.width, cnvFn.height);
}

function lineChart(objs, key, value)
{
  var cnvLn = document.getElementById(objs + "_canvas");
  var ctxCv = cnvLn.getContext("2d");
  var aryTr = document.getElementById(objs + "_table").getElementsByTagName("tr");
  var cnt, val, maxi = 5, aryTd, aryKy = [], aryVl = [];
  for (cnt = 1; cnt < aryTr.length; cnt++)
  {
    aryTd = aryTr[cnt].getElementsByTagName("td");
    aryKy.push(parseFloat(aryTd[key].textContent));
    val = parseFloat(aryTd[value].textContent);
    if (val > maxi) maxi = val;
    aryVl.push(val);
  }
  var width = (cnvLn.width - 40) / aryVl.length;
  val = maxi + (maxi % 5 ? 5 - (maxi % 5) : 0);
  var height = (cnvLn.height - 20) / val;
  ctxCv.fillStyle = "white";
  ctxCv.fillRect(0, 0, cnvLn.width, cnvLn.height);
  ctxCv.font = "9px Tahoma, Geneva, sans-serif";
  ctxCv.strokeStyle = "#AAAAAA";
  ctxCv.fillStyle = "black";
  for (cnt = 0; cnt < 5; cnt++)
  {
    ctxCv.beginPath();
    ctxCv.moveTo(0, (cnt * 60) + 20);
    ctxCv.lineTo((cnvLn.width - 40) + 3, (cnt * 60) + 20);
    ctxCv.stroke();
    ctxCv.fillText(val - (val * cnt * 0.2), (cnvLn.width - 40) + 5, (cnt * 60) + 23);
  }
  for (cnt = 0; cnt < aryVl.length; cnt++)
  {
    ctxCv.beginPath();
    ctxCv.moveTo(width * (cnt + 1), 0);
    ctxCv.lineTo(width * (cnt + 1), cnvLn.height);
    ctxCv.stroke();
    if (aryKy.length <= 31) ctxCv.fillText(aryKy[cnt], (width * cnt) + 4, 13);
  }
  ctxCv.strokeStyle = "crimson";
  ctxCv.lineWidth = 2;
  ctxCv.beginPath();  
  for (cnt = 0; cnt < aryVl.length; cnt++)
  {
    if (cnt) ctxCv.lineTo((width * cnt) + (width / 2), cnvLn.height - (height * aryVl[cnt]));
    else ctxCv.moveTo((width * cnt) + (width / 2), cnvLn.height - (height * aryVl[cnt]));
  }
  ctxCv.stroke();
  ctxCv.strokeStyle = "black";
  ctxCv.strokeRect(0, 0, cnvLn.width, cnvLn.height);
}

function mapChart(objs, coord, value)
{
  var cnvMp = document.getElementById(objs + "_canvas");
  var ctxCv = cnvMp.getContext("2d");
  var aryTr = document.getElementById(objs + "_table").getElementsByTagName("tr");
  var width = cnvMp.width / 360;
  var height = cnvMp.height / 180;
  var bubble, aryTd, aryCd
  var imgBg = new Image();
  imgBg.src = "plugins/geoip/map.jpg";
  imgBg.onload = function()
  {
    ctxCv.drawImage(imgBg, 0, 0, cnvMp.width, cnvMp.height);
    ctxCv.fillStyle = "red";
    for (var cnt = 1; cnt < aryTr.length; cnt++)
    {
      aryTd = aryTr[cnt].getElementsByTagName("td");
      aryCd = aryTd[coord].textContent.split(",");
      bubble = parseFloat(aryTd[value].textContent) / 10;
      if (bubble < 4) bubble = 4;
      else if (bubble > 16) bubble = 16;
      ctxCv.beginPath();
      ctxCv.arc(width * (180 + parseFloat(aryCd[1])), height * (90 - parseFloat(aryCd[0])), bubble, 0, Math.PI * 2, false);
      ctxCv.fill();
    }
  }
}

function mbarChart(objs, show)
{
  var cnvMb = document.getElementById(objs + "_canvas");
  var ctxCv = cnvMb.getContext("2d");
  var aryTr = document.getElementById(objs + "_table").getElementsByTagName("tr");
  var cnt, vcnt, val, maxi = 5, aryTd, aryKy = [], aryVl = [];
  aryVl.push(0);
  for (cnt = 1; cnt < aryTr.length; cnt++)
  {
    aryTd = aryTr[cnt].getElementsByTagName("td");
    aryKy.push(aryTd[0].textContent);
    for (vcnt = 1; vcnt < aryTd.length; vcnt++)
    {
      val = parseFloat(aryTd[vcnt].textContent);
      if (val > maxi) maxi = val;
      aryVl.push(val);
    }
    aryVl.push(0);
  }
  var width = (cnvMb.width - 40) / aryVl.length;
  val = maxi + (maxi % 5 ? 5 - (maxi % 5) : 0);
  var height = (cnvMb.height - 60) / val;
  var aryTh = aryTr[0].getElementsByTagName("th");
  ctxCv.fillStyle = "white";
  ctxCv.fillRect(0, 0, cnvMb.width, cnvMb.height);
  ctxCv.font = "9px Tahoma, Geneva, sans-serif";
  ctxCv.strokeStyle = "#AAAAAA";
  ctxCv.fillStyle = "black";
  for (cnt = 0; cnt < 6; cnt++)
  {
    ctxCv.beginPath();
    ctxCv.moveTo(0, (cnt * 60) + 20);
    ctxCv.lineTo((cnvMb.width - 40) + 3, (cnt * 60) + 20);
    ctxCv.stroke();
    ctxCv.fillText(val - (val * cnt * 0.2), (cnvMb.width - 40) + 5, (cnt * 60) + 23);
  }
  for (cnt = 0; cnt < aryVl.length; cnt++)
  {
    ctxCv.strokeStyle = "#AAAAAA";
    ctxCv.beginPath();
    ctxCv.moveTo(width * (cnt + 1), (cnt % aryTh.length ? 20 : 0));
    ctxCv.lineTo(width * (cnt + 1), cnvMb.height - 40);
    ctxCv.stroke();
    if (!((cnt - 1) % aryTh.length))
    {
      ctxCv.fillStyle = "black";
      ctxCv.fillText(aryKy[(cnt - 1) / aryTh.length], (width * cnt) + 4, 13);
    }
    if (aryVl[cnt])
    {
      ctxCv.fillStyle = clrMb[cnt % aryTh.length];
      ctxCv.fillRect(width * cnt, (cnvMb.height - 40) - (height * aryVl[cnt]), width, height * aryVl[cnt]);
      ctxCv.strokeStyle = "black";
      ctxCv.strokeRect(width * cnt, (cnvMb.height - 40) - (height * aryVl[cnt]), width, height * aryVl[cnt]);
      ctxCv.fillStyle = "black";
      if (show) ctxCv.fillText(aryVl[cnt], (width * cnt) + 4, ((height * aryVl[cnt]) > ((cnvMb.height - 60) / 2) ? cnvMb.height - 28 : cnvMb.height - 45) - (height * aryVl[cnt]));
    }
  }
  for (cnt = 1; cnt < aryTh.length; cnt++)
  {
    ctxCv.fillStyle = clrMb[cnt];
    ctxCv.fillRect(((cnt - 1) * 90) + 30, cnvMb.height - 27, 14, 14);
    ctxCv.fillStyle = "black";
    ctxCv.fillText(aryTh[cnt].textContent, ((cnt - 1) * 90) + 50, cnvMb.height - 16);
  }
  ctxCv.strokeStyle = "black";
  ctxCv.lineWidth = 2;
  ctxCv.strokeRect(0, 0, cnvMb.width, cnvMb.height);
}

function pieChart(objs, key, value)
{
  var cnvPi = document.getElementById(objs + "_canvas");
  var ctxCv = cnvPi.getContext("2d");
  var aryTr = document.getElementById(objs + "_table").getElementsByTagName("tr");
  var cnt, val, total = 0, aryTd, aryKy = [], aryVl = [];
  for (cnt = 1; cnt < aryTr.length; cnt++)
  {
    aryTd = aryTr[cnt].getElementsByTagName("td");
    aryKy.push(aryTd[key].textContent);
    val = parseFloat(aryTd[value].textContent);
    total += val;
    aryVl.push(val);
  }
  var centre = [(cnvPi.width / 2) + 60, ((cnvPi.height - 20) / 2) + 10];
  var radius = Math.min(cnvPi.width, cnvPi.height - 20) / 2;
  var pos = 0;
  ctxCv.fillStyle = "white";
  ctxCv.fillRect(0, 0, cnvPi.width, cnvPi.height);
  ctxCv.font = "11px Tahoma, Geneva, sans-serif";
  for (cnt = 0; cnt < aryVl.length; cnt++)
  {
    val = aryVl[cnt] / total;
    ctxCv.beginPath();
    ctxCv.arc(centre[0], centre[1], radius, Math.PI * ((pos * 2) - 0.5), Math.PI * (((pos + val) * 2) - 0.5), false);
    ctxCv.lineTo(centre[0], centre[1]);
    ctxCv.closePath();
    ctxCv.fillStyle = clrPi[cnt % clrPi.length];
    ctxCv.fill();
    if (cnt < 15)
    {
      ctxCv.fillRect(30, (cnt * 20) + 10, 14, 14);
      ctxCv.fillStyle = "black";
      ctxCv.fillText(aryKy[cnt], 50, ((cnt + 1) * 20) + 1);
      ctxCv.fillText(parseFloat(val * 100).toFixed(2) + "%", 80, ((cnt + 1) * 20) + 1);
    }
    pos += val;
  }
  ctxCv.strokeStyle = "black";
  ctxCv.lineWidth = 2;
  ctxCv.strokeRect(0, 0, cnvPi.width, cnvPi.height);
}

function vbarChart(objs, key, value, show)
{
  var cnvVb = document.getElementById(objs + "_canvas");
  var ctxCv = cnvVb.getContext("2d");
  var aryTr = document.getElementById(objs + "_table").getElementsByTagName("tr");
  var cnt, val, maxi = 5, aryTd, aryKy = [], aryVl = [];
  for (cnt = 1; cnt < aryTr.length; cnt++)
  {
    aryTd = aryTr[cnt].getElementsByTagName("td");
    aryKy.push(parseFloat(aryTd[key].textContent));
    val = parseFloat(aryTd[value].textContent);
    if (val > maxi) maxi = val;
    aryVl.push(val);
  }
  var width = (cnvVb.width - 40) / aryVl.length;
  val = maxi + (maxi % 5 ? 5 - (maxi % 5) : 0);
  var height = (cnvVb.height - 20) / val;
  ctxCv.fillStyle = "white";
  ctxCv.fillRect(0, 0, cnvVb.width, cnvVb.height);
  ctxCv.font = "9px Tahoma, Geneva, sans-serif";
  ctxCv.strokeStyle = "#AAAAAA";
  ctxCv.fillStyle = "black";
  for (cnt = 0; cnt < 5; cnt++)
  {
    ctxCv.beginPath();
    ctxCv.moveTo(0, (cnt * 60) + 20);
    ctxCv.lineTo((cnvVb.width - 40) + 3, (cnt * 60) + 20);
    ctxCv.stroke();
    ctxCv.fillText(val - (val * cnt * 0.2), (cnvVb.width - 40) + 5, (cnt * 60) + 23);
  }
  for (cnt = 0; cnt < aryVl.length; cnt++)
  {
    ctxCv.strokeStyle = "#AAAAAA";
    ctxCv.beginPath();
    ctxCv.moveTo(width * (cnt + 1), 0);
    ctxCv.lineTo(width * (cnt + 1), cnvVb.height);
    ctxCv.stroke();
    if (aryKy.length <= 31)
    {
      ctxCv.fillStyle = "black";
      ctxCv.fillText(aryKy[cnt], (width * cnt) + 4, 13);
    }
    ctxCv.fillStyle = clrVb[cnt % clrVb.length];
    ctxCv.fillRect(width * cnt, cnvVb.height - (height * aryVl[cnt]), width, height * aryVl[cnt]);
    ctxCv.strokeStyle = "black";
    ctxCv.strokeRect(width * cnt, cnvVb.height - (height * aryVl[cnt]), width, height * aryVl[cnt]);
    ctxCv.fillStyle = "black";
    if (show && aryVl[cnt]) ctxCv.fillText(aryVl[cnt], (width * cnt) + 4, ((height * aryVl[cnt]) > ((cnvVb.height - 20) / 2) ? cnvVb.height + 12 : cnvVb.height - 5) - (height * aryVl[cnt]));
  }
  ctxCv.strokeStyle = "black";
  ctxCv.lineWidth = 2;
  ctxCv.strokeRect(0, 0, cnvVb.width, cnvVb.height);
}
