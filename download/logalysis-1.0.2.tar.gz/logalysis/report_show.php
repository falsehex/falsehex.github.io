<?php
/* Copyright 2012-2016 Del Castle */

include "common.php";
session_start();
/*if (isset($_SESSION["las_last_activity"]) && ((time() - $_SESSION["las_last_activity"]) > 3600))
{
  session_unset();
  session_destroy();
} 
$_SESSION["las_last_activity"] = time();*/
if (empty($_SESSION["las_login_user_name"])) exit($login_bounce);
date_default_timezone_set("UTC");

$start_time = (isset($_POST["start_time"]) ? $_POST["start_time"] : "");
$finish_time = (isset($_POST["finish_time"]) ? $_POST["finish_time"] : "");

include "plugins/report/{$_POST["plugin"]}.generate_report.php";

//generate report requires <script type='text/javascript' src='fx/js/chart_gfx.js'></script>

?>
