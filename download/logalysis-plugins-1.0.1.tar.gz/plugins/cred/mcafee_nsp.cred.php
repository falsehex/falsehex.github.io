<?php

$mcafee_nsp_db_host = "127.0.0.1";
$mcafee_nsp_db_user = "logalysis";
$mcafee_nsp_db_pass = "P@55w0rd";
$mcafee_nsp_db_name = "lf";

$mcafee_nsp_www_host = "https://127.0.0.1";

?>
