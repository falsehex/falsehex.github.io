<?php

echo "<p>Limit <input type='text' name='limit' size='7' maxlength='5' value='{$limit}' /></p>";
search_time($search[1], $search[2]);
echo "<p>Client IP<br /><input type='text' name='source_ip' size='17' maxlength='15' value='{$search[15]}' /><input type='checkbox' name='not_source_ip' />NOT<br />";
echo "Request<br /><input type='text' name='char_4_255' size='26' maxlength='255' value='{$search[11]}' /></p>";

?>
