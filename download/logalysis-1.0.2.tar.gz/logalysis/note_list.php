<html>
<head>
<meta name='copyright' content='2012-2016 Del Castle' />
<meta charset='UTF-8' />
<meta http-equiv='content-type' content='text/html' />
<link rel='stylesheet' type='text/css' href='fx/css/logalysis.css' />

<link rel='stylesheet' type='text/css' href='fx/css/etree.css' />
<script type='text/javascript' src='fx/js/etree.js'></script>

<script type='text/javascript' src='fx/js/logalysis.js'></script>

</head>
<body>

<?php

include "common.php";
session_start();
/*if (isset($_SESSION["las_last_activity"]) && ((time() - $_SESSION["las_last_activity"]) > 3600))
{
  session_unset();
  session_destroy();
} 
$_SESSION["las_last_activity"] = time();*/
if (empty($_SESSION["las_login_user_name"])) exit($login_bounce);
$_SESSION["las_menu_tab"] = 1;

$job_id = (is_numeric($_GET["job_id"]) ? $_GET["job_id"] : 0);

$link = logalysis_db_connect();

echo "<div class='menu'>";
echo "<a class='menu' onmouseover='visState(\"dvsTp\", 1);'>NEW NOTE</a>";
echo "</div><br />";

echo "<script type='text/javascript'>";
echo "var etrNl = new eTree(\"etrNl\");";
$item = 0;
$count = db_result($link, "SELECT COUNT(1) FROM notes WHERE job_id = {$job_id}");
echo "etrNl.add(0, -1, true, \"folder\", \"NOTES ({$count})\", \"note_show.php?job_id={$job_id}&note_id=-1\", \"frame_note_show\");";
$result = mysqli_query($link, "SELECT save_time, save_user_id, note_type, note_id FROM notes WHERE job_id = {$job_id} ORDER BY save_time");
while ($note = mysqli_fetch_row($result)) echo "etrNl.add(" . ++$item . ", 0, false, \"file\", \"{$note[0]} " . get_user_name($link, $note[1]) . ($note[2] ? " ({$note[2][0]})" : "") . "\", \"note_show.php?job_id={$job_id}&note_id={$note[3]}\", \"frame_note_show\");";
mysqli_free_result($result);
echo "etrNl.write();";
echo "</script>";

echo "<div id='dvsTp' style='visibility:hidden' onmouseover='visState(\"dvsTp\", 1);' onmouseout='visState(\"dvsTp\", 0);'>";
echo "<div class='menu' style='width:auto'><a class='menu' href='note_show.php?job_id={$job_id}' target='frame_note_show'>NEW NOTE</a></div>";
$count = 0;
$note_plugins = scandir("plugins/note");
foreach ($note_plugins as &$row)
{
  if (strstr($row, ".note.txt") && !strstr($row, ".change.note.txt"))
  {
    $txt = preg_replace("/^(.+)\.note\.txt$/", "$1", $row);
    $row = preg_replace("/^.+\.(.+)\.note\.txt$/", "$1", $row);
    echo "<div class='menu' style='top:". (++$count * 20) . "px'><a class='menu' href='note_show.php?job_id={$job_id}&note_txt={$txt}' target='frame_note_show'>" . strtoupper(strtr($row, "_", " ")) . "</a></div>";
  }
}
echo "</div>";

mysqli_close($link);

?>

</body>
</html>
