<?php

$auto_ack = array(
"1:12345 => any",
"1:23456 => any"
);

?>
