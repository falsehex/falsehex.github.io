<?php

include "plugins/cred/snort.cred.php";

$link = mysqli_connect($snort_db_host, $snort_db_user, $snort_db_pass, $snort_db_name);
if (!$link) die("Error: mysql db {$snort_db_name} connect failed");

if (!isset($shape)) $shape = (isset($_POST["shape"]) ? $_POST["shape"] : "");
if (!isset($show_vals)) $show_vals = (isset($_POST["show_vals"]) ? $_POST["show_vals"] : "");

$table = "<table id='snort_daily_events_{$shape}_table' class='chart'><tr><th class='chart'>Day</th><th class='chart'>Events</th></tr>";
if (!$start_time) $start_time = date("Y-m-d 00:00:00", strtotime("-1 month"));
if (!$finish_time) $finish_time = date("Y-m-d 00:00:00", strtotime("+1 day"));
$ptr_time = strtotime($start_time);
while (date("ymd", $ptr_time) < date("ymd", strtotime($finish_time)))
{
  $day = date("d-m-Y", $ptr_time);
  $num = db_result($link, "SELECT COUNT(1) FROM event WHERE DATE_FORMAT(timestamp, '%d-%m-%Y') = '{$day}'");
  $table .= "<tr><td class='chart'>{$day}</td>";
  $table .= "<td class='chart'>{$num}</td></tr>";
  $ptr_time += 60 * 60 * 24;
}
$table .= "</table>";
if (isset($day))
{
  if (empty($nohdr)) echo "<h4>SNORT DAILY EVENTS<br />" . date("d-m-Y", strtotime($start_time)) . " - " . date("d-m-Y", strtotime("{$finish_time} -1 day")) . "</h4>";
  if (empty($nogfx)) echo "<canvas id='snort_daily_events_{$shape}_canvas' width='640' height='320' ondblclick='window.open(this.toDataURL());'></canvas>";
  echo $table;

  if (empty($nogfx)) echo "<script type='text/javascript'>{$shape}Chart(\"snort_daily_events_{$shape}\", 0, 1" . ($shape == "vbar" ? ", \"{$show_vals}\"" : "") . ");</script>";
}
else echo "<h5>NO EVENTS FOUND!</h5>";

mysqli_close($link);

?>
