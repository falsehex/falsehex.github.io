<?php

$solera_www_host = "https://127.0.0.1";
$solera_www_user = "admin";
$solera_www_pass = "Solera";

?>
