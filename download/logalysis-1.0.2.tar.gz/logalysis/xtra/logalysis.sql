#Copyright 2012-2016 Del Castle

#DROP DATABASE logalysis;

#USE mysql;

#DELETE FROM user WHERE User = 'logalysis';

#DELETE FROM db WHERE User = 'logalysis';

CREATE DATABASE logalysis;

GRANT ALL ON logalysis.* TO 'logalysis'@'localhost' IDENTIFIED BY 'P@55w0rd';

USE logalysis;

CREATE TABLE states (state_id INT AUTO_INCREMENT PRIMARY KEY,
                     name VARCHAR(32),
                     position INT,
                     is_disabled BOOLEAN);
INSERT INTO states VALUES(0, 'OPEN', 1, FALSE);
INSERT INTO states VALUES(0, 'CLOSED', 2, FALSE);

CREATE TABLE priorities (priority_id INT AUTO_INCREMENT PRIMARY KEY,
                         name VARCHAR(32));
INSERT INTO priorities VALUES(0, 'EXTREME');
INSERT INTO priorities VALUES(0, 'HIGH');
INSERT INTO priorities VALUES(0, 'MEDIUM');
INSERT INTO priorities VALUES(0, 'LOW');
INSERT INTO priorities VALUES(0, 'NONE');

CREATE TABLE users (user_id INT AUTO_INCREMENT PRIMARY KEY,
                    name VARCHAR(32),
                    actual VARCHAR(40),
                    roles VARCHAR(64),
                    hash VARCHAR(40),
                    hash_time DATETIME,
                    attempts INT,
                    is_admin BOOLEAN,
                    is_disabled BOOLEAN);
INSERT INTO users VALUES(0, 'admin', 'Administrator', 'ADMIN', '2731312823b829db5b0e6688806ae073a0e3d467', 0, 0, TRUE, FALSE);
#obvious

CREATE TABLE jobs (job_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                   ref_day SMALLINT UNSIGNED,
                   create_time DATETIME,
                   create_user_id INT,
                   close_time DATETIME,
                   close_user_id INT,
                   spent INT,
                   state_id INT,
                   priority_id INT,
                   assign_user_id INT,
                   sensor VARCHAR(64),
                   label VARCHAR(255),
                   comments TEXT,
                   event_time DATETIME,
                   protocol VARCHAR(5),
                   source_ip VARCHAR(39),
                   source_port SMALLINT UNSIGNED,
                   target_ip VARCHAR(39),
                   target_port SMALLINT UNSIGNED,
                   report BOOLEAN);
INSERT INTO jobs VALUES(0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

CREATE TABLE notes (note_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                    job_id BIGINT UNSIGNED,
                    save_time DATETIME,
                    save_user_id INT,
                    note_type VARCHAR(32),
                    remarks MEDIUMTEXT);

CREATE TABLE logs (log_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                   job_id BIGINT UNSIGNED,
                   save_time DATETIME,
                   save_user_id INT,
                   log_type VARCHAR(32),
                   start_time VARCHAR(19),
                   finish_time VARCHAR(19),
                   num_1 BIGINT,
                   num_2 BIGINT,
                   num_3 BIGINT,
                   num_4 BIGINT,
                   num_5 BIGINT,
                   char_1_64 VARCHAR(64),
                   char_2_64 VARCHAR(64),
                   char_3_255 VARCHAR(255),
                   char_4_255 VARCHAR(255),
                   char_5_255 VARCHAR(255),
                   char_6_255 VARCHAR(255),
                   protocol VARCHAR(5),
                   source_ip VARCHAR(39),
                   source_port SMALLINT UNSIGNED,
                   target_ip VARCHAR(39),
                   target_port SMALLINT UNSIGNED);

CREATE TABLE events (event_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                     log_id BIGINT UNSIGNED,
                     time_1 DATETIME,
                     time_2 DATETIME,
                     num_1 BIGINT,
                     num_2 BIGINT,
                     num_3 BIGINT,
                     num_4 BIGINT,
                     num_5 BIGINT,
                     char_1_64 VARCHAR(64),
                     char_2_64 VARCHAR(64),
                     char_3_255 VARCHAR(255),
                     char_4_255 VARCHAR(255),
                     char_5_255 VARCHAR(255),
                     char_6_255 VARCHAR(255),
                     protocol VARCHAR(5),
                     source_ip VARCHAR(39),
                     source_port SMALLINT UNSIGNED,
                     target_ip VARCHAR(39),
                     target_port SMALLINT UNSIGNED,
                     data BOOLEAN);

CREATE TABLE hosts (host_ip VARCHAR(42) PRIMARY KEY,
                    name VARCHAR(64),
                    category VARCHAR(16),
                    location VARCHAR(64),
                    details VARCHAR(255),
                    mod_time DATETIME);

CREATE TABLE trail (entry_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                    job_id BIGINT UNSIGNED,
                    save_time DATETIME,
                    save_user_id INT,
                    action VARCHAR(32),
                    details TEXT);
