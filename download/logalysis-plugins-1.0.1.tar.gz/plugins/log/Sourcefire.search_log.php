<?php

echo "<p>Limit <input type='text' name='limit' size='7' maxlength='5' value='{$limit}' /></p>";
search_time($search[1], $search[2]);
echo "<p>Source IP / Port<br /><input type='text' name='source_ip' size='17' maxlength='15' value='{$search[15]}' />";
echo "<input type='text' name='source_port' size='7' maxlength='5' value='{$search[16]}' /><br />";
echo "Target IP / Port<br /><input type='text' name='target_ip' size='17' maxlength='15' value='{$search[17]}' />";
echo "<input type='text' name='target_port' size='7' maxlength='5' value='{$search[18]}' /></p>";
echo "<p>GID:SID <input type='text' name='num_2' size='4' maxlength='10' value='{$search[4]}' />:<input type='text' name='num_3' size='10' maxlength='10' value='{$search[5]}' /></p>";
echo "<p>EID <input type='text' name='num_4' size='12' maxlength='10' value='{$search[6]}' /></p>";

?>
