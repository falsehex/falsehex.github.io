<html>
<head>
<meta charset='UTF-8' />
<meta http-equiv='content-type' content='text/html' />
<link rel='stylesheet' type='text/css' href='fx/css/logalysis.css' />

</head>
<body>

<?php

echo "<pre>";
echo "FILE:      GeoIPCountryWhois.csv";
echo "\nMODIFIED:  " . date("r", filemtime("../geoip/GeoIPCountryWhois.csv"));
echo "\nSIZE:      " . filesize("../geoip/GeoIPCountryWhois.csv");
echo "\nMD5SUM:    " . md5_file("../geoip/GeoIPCountryWhois.csv");
echo "\nSHA1SUM:   " . sha1_file("../geoip/GeoIPCountryWhois.csv");
echo "\n\nFILE:      GeoCountryLoc.csv";
echo "\nMODIFIED:  " . date("r", filemtime("../geoip/GeoCountryLoc.csv"));
echo "\nSIZE:      " . filesize("../geoip/GeoCountryLoc.csv");
echo "\nMD5SUM:    " . md5_file("../geoip/GeoCountryLoc.csv");
echo "\nSHA1SUM:   " . sha1_file("../geoip/GeoCountryLoc.csv");
echo "</pre>";

?>

</body>
</html>
