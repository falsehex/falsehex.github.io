/* glue.h - 26 May 16
   GL User Experience
   Copyright 2006-2016 Del Castle  */

#include <sys/time.h>

#include "llist-m.h"

//SDL_Keycode
#define GL_KEY_BACKSP  8
#define GL_KEY_TAB     9
#define GL_KEY_SPACE   32
#define GL_KEY_DEL     127
#define GL_KEY_TIDLE   126
#define GL_KEY_RIGHT   1073741903
#define GL_KEY_LEFT    1073741904

//selection value
#define GLUE_TITLE_BAR      0x01
#define GLUE_RESIZE         0x02
#define GLUE_RESIZE_RIGHT   0x03
#define GLUE_RESIZE_BOTTOM  0x04
#define GLUE_BAR_RIGHT      0x05
#define GLUE_BAR_BOTTOM     0x06
#define GLUE_SCROLL_START   0x07
#define GLUE_SCROLL_UP      0x08
#define GLUE_SCROLL_DOWN    0x09
#define GLUE_SCROLL_LEFT    0x0A
#define GLUE_SCROLL_RIGHT   0x0B
#define GLUE_CHECK_BOX      0x0C
#define GLUE_INPUT_TEXT     0x0D
#define GLUE_LIST_ITEM      0x0E
#define GLUE_MENU_ITEM      0x0F
#define GLUE_OK             0x10
#define GLUE_CLOSE          0x11
#define GLUE_CUSTOM         0x12

const int OBJ_ID = 100;

struct font_info
{
  int Width, Height, PadX, PadY;
  unsigned int GLList;
};

void initFont();
void setFont(int font);
int fontHeight();
void drawChar(unsigned char ch);
void drawString(const unsigned char *text);
void destroyFont();

//convert timeval to time in milliseconds
unsigned long long milliTime(const timeval *val);

//return length of string
int lenStr(const char *text);

//2D GUI
class GLue
{
  private:
    struct glue_window  //window object
    {
      unsigned char Object;  //GLUE_WINDOW
      bool Close, Resize;  //show close, resize object
      int Id, Parent, Left, Top, Width, Height, MinWidth, MinHeight, Bar;
      char Text[64];  //title bar
    } *lastWindow;  //last window created
    struct glue_bitmap  //bitmap object
    {
      unsigned char Object;  //GLUE_BITMAP
      glue_window *Parent;  //parent window object
      const unsigned char *Gfx;
      unsigned char Red, Green, Blue;
      int Left, Top;
    };
    struct glue_button  //button object
    {
      unsigned char Object;  //GLUE_BUTTON
      glue_window *Parent;  //parent window object
      bool Align, Defalt;  //align top-left, default
      int Left, Top, Value;  //selection value
      char Text[32];
    };
    struct glue_check  //check object
    {
      unsigned char Object;  //GLUE_CHECK
      glue_window *Parent;  //parent window object
      bool Checked;
      int Id, Left, Top;
    };
    struct glue_input  //input object
    {
      unsigned char Object;  //GLUE_INPUT
      glue_window *Parent;  //parent window object
      bool Lower, Digits;  //lowercase, digits only
      int Id, Left, Top, Width, Cursor, First, Max;  //width in characters, cursor position, first character to show, maximum characters
      char Text[256];
    } *activeInput;  //last input created
    struct glue_label  //label object
    {
      unsigned char Object;  //GLUE_LABEL
      glue_window *Parent;  //parent window object
      int Id, Left, Top;
      char Text[256];
    };
    struct glue_list  //list object
    {  //1st members must match glue_view
      unsigned char Object;  //GLUE_LIST
      glue_window *Parent;  //parent window object
      int Id, Left, Top, Right, Bottom, RowsBefore, RowsAfter, RowsStep, ColsBefore, ColsAfter, ColsStep;
      glue_input *Input;  //linked input object
      char Text[256], Filename[256];  //file to list
    };
    struct glue_view  //view object
    {
      unsigned char Object;  //GLUE_VIEW
      glue_window *Parent;  //parent window object
      int Id, Left, Top, Right, Bottom, RowsBefore, RowsAfter, RowsStep, ColsBefore, ColsAfter, ColsStep, Tab;  //tab spacing
      char Filename[256];  //file to view
    };
    struct glue_menu  //menu object
    {
      unsigned char Object;  //GLUE_MENU
      glue_menu *Parent;  //parent menu object
      int Id, Left, Top, Width, Value;
      char Text[64];
    } *activeMenu;
    size_t szWindow, szBitmap, szButton, szCheck, szInput, szLabel, szList, szView, szMenu;
    int objId, objSelected, activeScroll, stateMenu, winWidth, winHeight, mouseX, mouseY;  //input object with focus (for keys), scroll object with focus (for mouse wheel)
    unsigned int listGfx;
    LinkedList GLueLL;
    void Reset();
    bool MouseOver(int left, int top, int right, int bottom);
    void DrawWindow(const glue_window *window);
    void DrawBitmap(const glue_bitmap *bitmap);
    void DrawButton(const glue_button *button);
    void DrawCheck(const glue_check *check);
    void DrawInput(glue_input *input);
    void DrawLabel(const glue_label *label);
    void DrawScroll(glue_view *view, int left, int top, int right, int bottom, bool focus);
    void DrawList(glue_list *list);
    void DrawView(glue_view *view);
    void DrawMenu(glue_menu *menu);
    void ScrollCalc(int *direction, int *opposite, int step);
    void DestroyWindow(const glue_window *window);
  public:
    GLue();
    ~GLue();
    bool On();
    void CreateWindow(int left, int top, int width, int height, const char *text, bool close = true, bool resize = false);
    void AddBitmap(int left, int top, int offsetx, int offsety, unsigned char red, unsigned char green, unsigned char blue, const unsigned char *gfx);
    void AddButton(int left, int top, int value, const char *text, bool align = true, bool defalt = false);
    int AddCheck(int left, int top, bool checked);
    int AddInput(int left, int top, int width, int max, const char *text, bool lower = false, bool digits = false);
    int AddLabel(int left, int top, const char *text);
    void AddList(int left, int top, int right, int bottom, const char *filename);
    void AddView(int left, int top, int right, int bottom, int tab, const char *filename);
    void AddMenu(int id, const char *text, int value);
    int Draw();
    int DefaultButton();
    bool GetChecked(int id);
    char *GetInputText(int id = 0);
    void PutInputText(const char *text, int id = 0);
    void PutLabelText(const char *text, int id);
    int GetSelected();
    void ScreenSize(int width, int height);
    void Scroll(int scroll = GLUE_SCROLL_START, int step = 0);
    int MouseButton(bool up);
    void MouseMotion(int x, int y);
    void MouseMove(int val, int x, int y);
    void Key(int key, bool shift);
    void Close(bool all = true);
};
