<?php

echo "<html>";
echo "<head>";
echo "<link rel='stylesheet' type='text/css' href='plugins/report/Snort_Signatures.css' />";
echo "<script type='text/javascript' src='fx/js/chart_gfx.js'></script>";
echo "</head>";
echo "<body>";
echo "<h1>Test Report</h1>";
echo "<h2>1. Network Attack Analysis</h2>";
echo "<h3>1.1 Snort</h3>";

$limit = 10;

$shape = "vbar";
include "plugins/chart/Snort_Alerts.generate_chart.php";

echo "<div class='break'></div>";
echo "<h3>Create your report template in MS Word, save it as HTML, charts and tables can be added dynamically here.</h3>";

$shape = "pie";
include "plugins/chart/Snort_Alerts.generate_chart.php";

echo "</body>";
echo "</html>";

?>
