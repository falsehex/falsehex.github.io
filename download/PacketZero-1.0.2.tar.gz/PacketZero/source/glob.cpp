/* glob.cpp - 01 Sep 15
   PacketZero - 3D Network Monitor
   Copyright 2006-2015 Del Castle  */

#define GL_GLEXT_PROTOTYPES

#ifdef __APPLE__
#include <OpenGL/gl.h>
#else
#include <GL/gl.h>
#endif

#include "glob.h"
#include "misc.h"

GLob::GLob()
{
  glob_cross tCross =
  {
    {
      { 640.0, 0.0,    4.0},  //vertex
      { 640.0, 0.0,    8.0},
      {   8.0, 0.0,    8.0},
      {   8.0, 0.0,  640.0},
      {   4.0, 0.0,  640.0},
      {   4.0, 0.0,    4.0},
      {   8.0, 0.0,    4.0},
      {  -4.0, 0.0,    4.0},
      {  -4.0, 0.0,  640.0},
      {  -8.0, 0.0,  640.0},
      {  -8.0, 0.0,    8.0},
      {-640.0, 0.0,    8.0},
      {-640.0, 0.0,    4.0},
      {  -8.0, 0.0,    4.0},
      {  -4.0, 0.0, -640.0},
      {  -4.0, 0.0,   -4.0},
      {  -8.0, 0.0,   -4.0},
      {-640.0, 0.0,   -4.0},
      {-640.0, 0.0,   -8.0},
      {  -8.0, 0.0,   -8.0},
      {  -8.0, 0.0, -640.0},
      {   8.0, 0.0, -640.0},
      {   8.0, 0.0,   -8.0},
      { 640.0, 0.0,   -8.0},
      { 640.0, 0.0,   -4.0},
      {   8.0, 0.0,   -4.0},
      {   4.0, 0.0,   -4.0},
      {   4.0, 0.0, -640.0}
    },
    {
      {clrGrey[0], clrGrey[1], clrGrey[2]},  //colour
      {clrGrey[0], clrGrey[1], clrGrey[2]},
      {clrGrey[0], clrGrey[1], clrGrey[2]},
      {clrGrey[0], clrGrey[1], clrGrey[2]},
      {clrGrey[0], clrGrey[1], clrGrey[2]},
      {clrGrey[0], clrGrey[1], clrGrey[2]},
      {clrGrey[0], clrGrey[1], clrGrey[2]},
      {clrBlueCross[0], clrBlueCross[1], clrBlueCross[2]},
      {clrBlueCross[0], clrBlueCross[1], clrBlueCross[2]},
      {clrBlueCross[0], clrBlueCross[1], clrBlueCross[2]},
      {clrBlueCross[0], clrBlueCross[1], clrBlueCross[2]},
      {clrBlueCross[0], clrBlueCross[1], clrBlueCross[2]},
      {clrBlueCross[0], clrBlueCross[1], clrBlueCross[2]},
      {clrBlueCross[0], clrBlueCross[1], clrBlueCross[2]},
      {clrGreenCross[0], clrGreenCross[1], clrGreenCross[2]},
      {clrGreenCross[0], clrGreenCross[1], clrGreenCross[2]},
      {clrGreenCross[0], clrGreenCross[1], clrGreenCross[2]},
      {clrGreenCross[0], clrGreenCross[1], clrGreenCross[2]},
      {clrGreenCross[0], clrGreenCross[1], clrGreenCross[2]},
      {clrGreenCross[0], clrGreenCross[1], clrGreenCross[2]},
      {clrGreenCross[0], clrGreenCross[1], clrGreenCross[2]},
      {clrRedCross[0], clrRedCross[1], clrRedCross[2]},
      {clrRedCross[0], clrRedCross[1], clrRedCross[2]},
      {clrRedCross[0], clrRedCross[1], clrRedCross[2]},
      {clrRedCross[0], clrRedCross[1], clrRedCross[2]},
      {clrRedCross[0], clrRedCross[1], clrRedCross[2]},
      {clrRedCross[0], clrRedCross[1], clrRedCross[2]},
      {clrRedCross[0], clrRedCross[1], clrRedCross[2]}
    },
    {
      { 0,  1,  2,  6},  //index
      { 6,  3,  4,  5},
      { 7,  8,  9, 13},
      {13, 10, 11, 12},
      {14, 15, 16, 20},
      {19, 16, 17, 18},
      {21, 25, 26, 27},
      {23, 24, 25, 22}
    }
  };
  oCross = tCross;
  glob_host tHost =
  {
    {
      { 0.0, 10.0,  0.0},  //vertex
      { 3.0,  8.0,  3.0},
      {-3.0,  8.0,  3.0},
      {-3.0,  8.0, -3.0},
      { 3.0,  8.0, -3.0},
      { 3.0,  2.0,  3.0},
      {-3.0,  2.0,  3.0},
      {-3.0,  2.0, -3.0},
      { 3.0,  2.0, -3.0},
      { 0.0,  0.0,  0.0}
    },
    {
      {clrGreyBright[0], clrGreyBright[1], clrGreyBright[2]},  //colour
      {180, 180, 180},
      {160, 160, 160},
      {140, 140, 140},
      {120, 120, 120},
      {100, 100, 100},
      {80,  80,  80},
      {60,  60,  60},
      {50,  50,  50},
      {50,  50,  50}
    },
    {
      {clrOrange[0], clrOrange[1], clrOrange[2]},  //colour
      {200, 150, 50},
      {180, 130, 50},
      {160, 110, 50},
      {140, 90,  50},
      {120, 70,  50},
      {100, 50,  50},
      {80,  50,  50},
      {60,  50,  50},
      {50,  50,  50}
    },
    {
      {clrYellow[0], clrYellow[1], clrYellow[2]},  //colour
      {180, 180, 50},
      {160, 160, 50},
      {140, 140, 50},
      {120, 120, 50},
      {100, 100, 50},
      {80,  80,  50},
      {60,  60,  50},
      {50,  50,  50},
      {50,  50,  50}
    },
    {
      {clrFluro[0], clrFluro[1], clrFluro[2]},  //colour
      {150, 200, 50},
      {130, 180, 50},
      {110, 160, 50},
      {90,  140, 50},
      {70,  120, 50},
      {50,  100, 50},
      {50,  80,  50},
      {50,  60,  50},
      {50,  50,  50}
    },
    {
      {clrGreen[0], clrGreen[1], clrGreen[2]},  //colour
      {50, 180, 50},
      {50, 160, 50},
      {50, 140, 50},
      {50, 120, 50},
      {50, 100, 50},
      {50, 80,  50},
      {50, 60,  50},
      {50, 50,  50},
      {50, 50,  50}
    },
    {
      {clrMint[0], clrMint[1], clrMint[2]},  //colour
      {50, 200, 150},
      {50, 180, 130},
      {50, 160, 110},
      {50, 140, 90},
      {50, 120, 70},
      {50, 100, 50},
      {50, 80,  50},
      {50, 60,  50},
      {50, 50,  50}
    },
    {
      {clrAqua[0], clrAqua[1], clrAqua[2]},  //colour
      {50, 180, 180},
      {50, 160, 160},
      {50, 140, 140},
      {50, 120, 120},
      {50, 100, 100},
      {50, 80,  80},
      {50, 60,  60},
      {50, 50,  50},
      {50, 50,  50}
    },
    {
      {clrSky[0], clrSky[1], clrSky[2]},  //colour
      {50, 150, 200},
      {50, 130, 180},
      {50, 110, 160},
      {50, 90,  140},
      {50, 70,  120},
      {50, 50,  100},
      {50, 50,  80},
      {50, 50,  60},
      {50, 50,  50}
    },
    {
      {clrPurple[0], clrPurple[1], clrPurple[2]},  //colour
      {150, 50, 200},
      {130, 50, 180},
      {110, 50, 160},
      {90,  50, 140},
      {70,  50, 120},
      {50,  50, 100},
      {50,  50, 80},
      {50,  50, 60},
      {50,  50, 50}
    },
    {
      {clrViolet[0], clrViolet[1], clrViolet[2]},  //colour
      {180, 50, 180},
      {160, 50, 160},
      {140, 50, 140},
      {120, 50, 120},
      {100, 50, 100},
      {80,  50, 80},
      {60,  50, 60},
      {50,  50, 50},
      {50,  50, 50}
    },
    {
      {clrRedBright[0], clrRedBright[1], clrRedBright[2]},  //colour
      {235, 50, 50},
      {215, 50, 50},
      {195, 50, 50},
      {175, 50, 50},
      {155, 50, 50},
      {135, 50, 50},
      {115, 50, 50},
      {95,  50, 50},
      {75,  50, 50}
    },
    {
      {clrRed[0], clrRed[1], clrRed[2]},  //colour
      {180, 50, 50},
      {160, 50, 50},
      {140, 50, 50},
      {120, 50, 50},
      {100, 50, 50},
      {80,  50, 50},
      {60,  50, 50},
      {50,  50, 50},
      {50,  50, 50}
    },
    {
      {0, 1, 2},  //index
      {0, 2, 3},
      {0, 3, 4},
      {0, 4, 1},
      {1, 5, 6},
      {2, 6, 7},
      {3, 7, 8},
      {4, 8, 5},
      {5, 9, 6},
      {7, 9, 8},
      {1, 2, 6},
      {2, 3, 7},
      {3, 4, 8},
      {4, 1, 5},
      {6, 9, 7},
      {8, 9, 5}
    }
  };
  oHost = tHost;
  glob_cluster tCluster =
  {
    {
      { 0.0, 10.0,  0.0},  //vertex
      { 3.0,  8.0,  3.0},
      {-3.0,  8.0,  3.0},
      {-3.0,  8.0, -3.0},
      { 3.0,  8.0, -3.0},
      { 0.0,  5.0,  0.0},
      { 3.0,  2.0,  3.0},
      {-3.0,  2.0,  3.0},
      {-3.0,  2.0, -3.0},
      { 3.0,  2.0, -3.0},
      { 0.0,  0.0,  0.0}
    },
    {
      {clrRed[0], clrRed[1], clrRed[2]},  //colour
      {clrYellow[0], clrYellow[1], clrYellow[2]},
      {clrGreen[0], clrGreen[1], clrGreen[2]},
      {clrYellow[0], clrYellow[1], clrYellow[2]},
      {clrGreen[0], clrGreen[1], clrGreen[2]},
      {clrRed[0], clrRed[1], clrRed[2]},
      {clrYellow[0], clrYellow[1], clrYellow[2]},
      {clrGreen[0], clrGreen[1], clrGreen[2]},
      {clrYellow[0], clrYellow[1], clrYellow[2]},
      {clrGreen[0], clrGreen[1], clrGreen[2]},
      {clrRed[0], clrRed[1], clrRed[2]}
    },
    {
      {clrRedBright[0], clrRedBright[1], clrRedBright[2]},  //colour
      {clrRed[0], clrRed[1], clrRed[2]},
      {clrRedCross[0], clrRedCross[1], clrRedCross[2]},
      {clrRed[0], clrRed[1], clrRed[2]},
      {clrRedCross[0], clrRedCross[1], clrRedCross[2]},
      {clrRed[0], clrRed[1], clrRed[2]},
      {clrYellow[0], clrYellow[1], clrYellow[2]},
      {clrGreen[0], clrGreen[1], clrGreen[2]},
      {clrYellow[0], clrYellow[1], clrYellow[2]},
      {clrGreen[0], clrGreen[1], clrGreen[2]},
      {clrRed[0], clrRed[1], clrRed[2]}
    },
    {
      {0,  1, 2},  //index
      {0,  2, 3},
      {0,  3, 4},
      {0,  4, 1},
      {1,  5, 2},
      {3,  5, 4},
      {5,  6, 7},
      {5,  7, 8},
      {5,  8, 9},
      {5,  9, 6},
      {6, 10, 7},
      {8, 10, 9},
      {2,  5, 3},
      {4,  5, 1},
      {7, 10, 8},
      {9, 10, 6}
    }
  };
  oCluster = tCluster;
  glob_packet tPacket =
  {
    {
      { 1.0, 6.0,  1.0},  //vertex
      {-1.0, 6.0,  1.0},
      {-1.0, 6.0, -1.0},
      { 1.0, 6.0, -1.0},
      { 1.0, 4.0,  1.0},
      {-1.0, 4.0,  1.0},
      {-1.0, 4.0, -1.0},
      { 1.0, 4.0, -1.0}
    },
    {
      {0, 1, 2},  //index
      {2, 3, 0},
      {0, 4, 5},
      {1, 5, 6},
      {2, 6, 7},
      {3, 7, 4},
      {0, 1, 5},
      {1, 2, 6},
      {2, 3, 7},
      {3, 0, 4},
      {4, 5, 6},
      {6, 7, 4}
    }
  };
  oPacket = tPacket;
  glob_active tActive =
  {
    {
      { 0.5,  0.5,  0.5},  //vertex
      {-0.5,  0.5,  0.5},
      {-0.5,  0.5, -0.5},
      { 0.5,  0.5, -0.5},
      { 0.5, -0.5,  0.5},
      {-0.5, -0.5,  0.5},
      {-0.5, -0.5, -0.5},
      { 0.5, -0.5, -0.5}
    },
    {
      {0, 1, 2},  //index
      {2, 3, 0},
      {0, 4, 5},
      {1, 5, 6},
      {2, 6, 7},
      {3, 7, 4}
    }
  };
  oActive = tActive;
  glob_anomaly tAnomaly =
  {
    {
      {(float)-0.4, (float) 0.7, (float) 0.4},  //vertex
      {(float)-0.4, (float) 0.7, (float)-0.4},  //xcode gives warning if not float
      {(float)-0.7, (float) 0.0, (float)-0.7},
      {(float)-0.4, (float)-0.7, (float)-0.4},
      {(float)-0.4, (float)-0.7, (float) 0.4},
      {(float)-0.7, (float) 0.0, (float) 0.7},
      {(float) 0.4, (float) 0.7, (float) 0.4},
      {(float) 0.4, (float) 0.7, (float)-0.4},
      {(float) 0.7, (float) 0.0, (float)-0.7},
      {(float) 0.4, (float)-0.7, (float)-0.4},
      {(float) 0.4, (float)-0.7, (float) 0.4},
      {(float) 0.7, (float) 0.0, (float) 0.7}
    }
  };
  oAnomaly = tAnomaly;
  szCrossVertex = sizeof(oCross.Vertex);
  szHostVertex = sizeof(oHost.Vertex);
  szHostColor = sizeof(oHost.Color);
  szClusterVertex = sizeof(oCluster.Vertex);
  szClusterColor = sizeof(oCluster.Color);
  glGenBuffersARB(11, (unsigned int *)&vboId);
  glBindBufferARB(GL_ARRAY_BUFFER_ARB, vboId[0]);  //vertex & colour
  glBufferDataARB(GL_ARRAY_BUFFER_ARB, sizeof(oCross.Vertex) + sizeof(oCross.Color), 0, GL_STATIC_DRAW_ARB);
  glBufferSubDataARB(GL_ARRAY_BUFFER_ARB, 0, sizeof(oCross.Vertex), oCross.Vertex);
  glBufferSubDataARB(GL_ARRAY_BUFFER_ARB, sizeof(oCross.Vertex), sizeof(oCross.Color), oCross.Color);
  glBindBufferARB(GL_ELEMENT_ARRAY_BUFFER_ARB, vboId[1]);  //index
  glBufferDataARB(GL_ELEMENT_ARRAY_BUFFER_ARB, sizeof(oCross.Quad), oCross.Quad, GL_STATIC_DRAW_ARB);
  glBindBufferARB(GL_ARRAY_BUFFER_ARB, vboId[2]);  //vertex & colour
  glBufferDataARB(GL_ARRAY_BUFFER_ARB, sizeof(oHost.Vertex) + (sizeof(oHost.Color) * 12), 0, GL_STATIC_DRAW_ARB);
  glBufferSubDataARB(GL_ARRAY_BUFFER_ARB, 0, sizeof(oHost.Vertex), oHost.Vertex);
  glBufferSubDataARB(GL_ARRAY_BUFFER_ARB, sizeof(oHost.Vertex), sizeof(oHost.Color), oHost.Color);
  glBufferSubDataARB(GL_ARRAY_BUFFER_ARB, sizeof(oHost.Vertex) + sizeof(oHost.Color), sizeof(oHost.Color), oHost.ColorOrange);
  glBufferSubDataARB(GL_ARRAY_BUFFER_ARB, sizeof(oHost.Vertex) + (sizeof(oHost.Color) * 2), sizeof(oHost.Color), oHost.ColorYellow);
  glBufferSubDataARB(GL_ARRAY_BUFFER_ARB, sizeof(oHost.Vertex) + (sizeof(oHost.Color) * 3), sizeof(oHost.Color), oHost.ColorFluro);
  glBufferSubDataARB(GL_ARRAY_BUFFER_ARB, sizeof(oHost.Vertex) + (sizeof(oHost.Color) * 4), sizeof(oHost.Color), oHost.ColorGreen);
  glBufferSubDataARB(GL_ARRAY_BUFFER_ARB, sizeof(oHost.Vertex) + (sizeof(oHost.Color) * 5), sizeof(oHost.Color), oHost.ColorMint);
  glBufferSubDataARB(GL_ARRAY_BUFFER_ARB, sizeof(oHost.Vertex) + (sizeof(oHost.Color) * 6), sizeof(oHost.Color), oHost.ColorAqua);
  glBufferSubDataARB(GL_ARRAY_BUFFER_ARB, sizeof(oHost.Vertex) + (sizeof(oHost.Color) * 7), sizeof(oHost.Color), oHost.ColorSky);
  glBufferSubDataARB(GL_ARRAY_BUFFER_ARB, sizeof(oHost.Vertex) + (sizeof(oHost.Color) * 8), sizeof(oHost.Color), oHost.ColorPurple);
  glBufferSubDataARB(GL_ARRAY_BUFFER_ARB, sizeof(oHost.Vertex) + (sizeof(oHost.Color) * 9), sizeof(oHost.Color), oHost.ColorViolet);
  glBufferSubDataARB(GL_ARRAY_BUFFER_ARB, sizeof(oHost.Vertex) + (sizeof(oHost.Color) * 10), sizeof(oHost.Color), oHost.ColorRedBright);
  glBufferSubDataARB(GL_ARRAY_BUFFER_ARB, sizeof(oHost.Vertex) + (sizeof(oHost.Color) * 11), sizeof(oHost.Color), oHost.ColorRed);
  glBindBufferARB(GL_ELEMENT_ARRAY_BUFFER_ARB, vboId[3]);  //index
  glBufferDataARB(GL_ELEMENT_ARRAY_BUFFER_ARB, sizeof(oHost.Tri), oHost.Tri, GL_STATIC_DRAW_ARB);
  glBindBufferARB(GL_ARRAY_BUFFER_ARB, vboId[4]);  //vertex & colour
  glBufferDataARB(GL_ARRAY_BUFFER_ARB, sizeof(oCluster.Vertex) + (sizeof(oCluster.Color) * 2), 0, GL_STATIC_DRAW_ARB);
  glBufferSubDataARB(GL_ARRAY_BUFFER_ARB, 0, sizeof(oCluster.Vertex), oCluster.Vertex);
  glBufferSubDataARB(GL_ARRAY_BUFFER_ARB, sizeof(oCluster.Vertex), sizeof(oCluster.Color), oCluster.Color);
  glBufferSubDataARB(GL_ARRAY_BUFFER_ARB, sizeof(oCluster.Vertex) + sizeof(oCluster.Color), sizeof(oCluster.Color), oCluster.ColorRed);
  glBindBufferARB(GL_ELEMENT_ARRAY_BUFFER_ARB, vboId[5]);  //index
  glBufferDataARB(GL_ELEMENT_ARRAY_BUFFER_ARB, sizeof(oCluster.Tri), oCluster.Tri, GL_STATIC_DRAW_ARB);
  glBindBufferARB(GL_ARRAY_BUFFER_ARB, vboId[6]);  //vertex
  glBufferDataARB(GL_ARRAY_BUFFER_ARB, sizeof(oPacket.Vertex), oPacket.Vertex, GL_STATIC_DRAW_ARB);
  glBindBufferARB(GL_ELEMENT_ARRAY_BUFFER_ARB, vboId[7]);  //index
  glBufferDataARB(GL_ELEMENT_ARRAY_BUFFER_ARB, sizeof(oPacket.Tri), oPacket.Tri, GL_STATIC_DRAW_ARB);
  glBindBufferARB(GL_ARRAY_BUFFER_ARB, vboId[8]);  //vertex
  glBufferDataARB(GL_ARRAY_BUFFER_ARB, sizeof(oActive.Vertex), oActive.Vertex, GL_STATIC_DRAW_ARB);
  glBindBufferARB(GL_ELEMENT_ARRAY_BUFFER_ARB, vboId[9]);  //index
  glBufferDataARB(GL_ELEMENT_ARRAY_BUFFER_ARB, sizeof(oActive.Tri), oActive.Tri, GL_STATIC_DRAW_ARB);
  glBindBufferARB(GL_ARRAY_BUFFER_ARB, vboId[10]);  //vertex
  glBufferDataARB(GL_ARRAY_BUFFER_ARB, sizeof(oAnomaly.Vertex), oAnomaly.Vertex, GL_STATIC_DRAW_ARB);
}

//draw cross object
void GLob::DrawCross()
{
  glBindBufferARB(GL_ARRAY_BUFFER_ARB, vboId[0]);
  glBindBufferARB(GL_ELEMENT_ARRAY_BUFFER_ARB, vboId[1]);
  glEnableClientState(GL_VERTEX_ARRAY);
  glVertexPointer(3, GL_FLOAT, 0, 0);
  glEnableClientState(GL_COLOR_ARRAY);
  glColorPointer(3, GL_UNSIGNED_BYTE, 0, (void *)szCrossVertex);
  glDrawElements(GL_QUADS, 32, GL_UNSIGNED_BYTE, 0);
  glDisableClientState(GL_COLOR_ARRAY);
  glDisableClientState(GL_VERTEX_ARRAY);
  glBindBufferARB(GL_ELEMENT_ARRAY_BUFFER_ARB, 0);
  glBindBufferARB(GL_ARRAY_BUFFER_ARB, 0);
}

//draw host object
void GLob::DrawHost(unsigned char color, unsigned char green, unsigned char blue, bool render)
{
  glBindBufferARB(GL_ARRAY_BUFFER_ARB, vboId[2]);
  glBindBufferARB(GL_ELEMENT_ARRAY_BUFFER_ARB, vboId[3]);
  glEnableClientState(GL_VERTEX_ARRAY);
  glVertexPointer(3, GL_FLOAT, 0, 0);
  if (render)
  {
    glColor3ub(clrBlack[0], clrBlack[1], clrBlack[2]);
    glDrawElements(GL_LINE_STRIP, 30, GL_UNSIGNED_BYTE, 0);
    glEnableClientState(GL_COLOR_ARRAY);
    glColorPointer(3, GL_UNSIGNED_BYTE, 0, (void *)(szHostVertex + (color * szHostColor)));
  }
  else glColor3ub(color, green, blue);  //red
  glDrawElements(GL_TRIANGLES, 48, GL_UNSIGNED_BYTE, 0);
  glDisableClientState(GL_COLOR_ARRAY);
  glDisableClientState(GL_VERTEX_ARRAY);
  glBindBufferARB(GL_ELEMENT_ARRAY_BUFFER_ARB, 0);
  glBindBufferARB(GL_ARRAY_BUFFER_ARB, 0);
}

//draw cluster object
void GLob::DrawCluster(bool selected)
{
  glBindBufferARB(GL_ARRAY_BUFFER_ARB, vboId[4]);
  glBindBufferARB(GL_ELEMENT_ARRAY_BUFFER_ARB, vboId[5]);
  glEnableClientState(GL_VERTEX_ARRAY);
  glVertexPointer(3, GL_FLOAT, 0, 0);
  glColor3ub(clrBlack[0], clrBlack[1], clrBlack[2]);
  glDrawElements(GL_LINE_STRIP, 36, GL_UNSIGNED_BYTE, 0);
  glEnableClientState(GL_COLOR_ARRAY);
  glColorPointer(3, GL_UNSIGNED_BYTE, 0, (void *)(szClusterVertex + (selected ? szClusterColor : 0)));
  glDrawElements(GL_TRIANGLES, 48, GL_UNSIGNED_BYTE, 0);
  glDisableClientState(GL_COLOR_ARRAY);
  glDisableClientState(GL_VERTEX_ARRAY);
  glBindBufferARB(GL_ELEMENT_ARRAY_BUFFER_ARB, 0);
  glBindBufferARB(GL_ARRAY_BUFFER_ARB, 0);
}

//draw packet object
void GLob::DrawPacket(unsigned char red, unsigned char green, unsigned char blue)
{
  glBindBufferARB(GL_ARRAY_BUFFER_ARB, vboId[6]);
  glBindBufferARB(GL_ELEMENT_ARRAY_BUFFER_ARB, vboId[7]);
  glEnableClientState(GL_VERTEX_ARRAY);
  glVertexPointer(3, GL_FLOAT, 0, 0);
  glColor3ub(clrBlack[0], clrBlack[1], clrBlack[2]);
  glDrawElements(GL_LINE_STRIP, 18, GL_UNSIGNED_BYTE, 0);
  glColor3ub(red, green, blue);
  glDrawElements(GL_TRIANGLES, 36, GL_UNSIGNED_BYTE, 0);
  glDisableClientState(GL_VERTEX_ARRAY);
  glBindBufferARB(GL_ELEMENT_ARRAY_BUFFER_ARB, 0);
  glBindBufferARB(GL_ARRAY_BUFFER_ARB, 0);
}

//draw alert object
void GLob::DrawAlert(bool active)
{
  if (active)
  {
    glBindBufferARB(GL_ARRAY_BUFFER_ARB, vboId[8]);
    glBindBufferARB(GL_ELEMENT_ARRAY_BUFFER_ARB, vboId[9]);
    glEnableClientState(GL_VERTEX_ARRAY);
    glVertexPointer(3, GL_FLOAT, 0, 0);
    glDrawElements(GL_LINE_STRIP, 18, GL_UNSIGNED_BYTE, 0);
    glDisableClientState(GL_VERTEX_ARRAY);
    glBindBufferARB(GL_ELEMENT_ARRAY_BUFFER_ARB, 0);
    glBindBufferARB(GL_ARRAY_BUFFER_ARB, 0);
  }
  else
  {
    glBindBufferARB(GL_ARRAY_BUFFER_ARB, vboId[10]);
    glEnableClientState(GL_VERTEX_ARRAY);
    glVertexPointer(3, GL_FLOAT, 0, 0);
    glDrawArrays(GL_LINE_LOOP, 0, 6);
    glDrawArrays(GL_LINE_LOOP, 6, 6);
    glDisableClientState(GL_VERTEX_ARRAY);
    glBindBufferARB(GL_ARRAY_BUFFER_ARB, 0);
  }
}

//draw link object
void GLob::DrawLink(int x1, int y1, int z1, int x2, int y2, int z2)
{
  glColor3ub(clrGreyDull[0], clrGreyDull[1], clrGreyDull[2]);
  glBegin(GL_LINES);
    glVertex3i(x1, y1, z1);
    glVertex3i(x2, y2, z2);
  glEnd();
}

GLob::~GLob()
{
  glDeleteBuffersARB(11, (unsigned int *)&vboId);
}
