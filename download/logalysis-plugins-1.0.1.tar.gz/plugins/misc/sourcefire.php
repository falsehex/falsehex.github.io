<?php

$sourcefire_result = array("No", "Yes", "Would Have");

$sourcefire_classification = array("",
"Not Suspicious Traffic",
"Unknown Traffic",
"Potentially Bad Traffic",
"Attempted Information Leak",
"Information Leak",
"Large Scale Information Leak",
"Attempted Denial of Service",
"Denial of Service",
"Attempted User Privilege Gain",
"Unsuccessful User Privilege Gain",
"Successful User Privilege Gain",
"Attempted Administrator Privilege Gain",
"Successful Administrator Privilege Gain",
"Decode of an RPC Query",
"Executable Code was Detected",
"A Suspicious String was Detected",
"A Suspicious Filename was Detected",
"An Attempted Login Using a Suspicious Username was Detected",
"A System Call was Detected",
"A TCP Connection was Detected",
"A Network Trojan was Detected",
"A Client was Using an Unusual Port",
"Detection of a Network Scan",
"Detection of a Denial of Service Attack",
"Detection of a Non-Standard Protocol or Event",
"Generic Protocol Command Decode",
"Access to a Potentially Vulnerable Web Application",
"Web Application Attack",
"Misc Activity",
"Misc Attack",
"Generic ICMP Event",
"Pornography was Detected",
"Potential Corporate Policy Violation",
"Attempt to Login By a Default Username and Password",
"Sensitive Data",
"Known client side exploit attempt",
"Known malicious file or file based exploit",
"Known malware command and control traffic"
);

$sourcefire_impact = array("",
"Vulnerable",
"Potentially Vulnerable",
"Currently Not Vulnerable",
"Unknown Target",
"Unknown"
);

function sourcefire_priority($val, $short, $tick)
{
  if (!$val) $val = 3;
  if ($tick) $val += 3;
  switch ($val)
  {
    case 1: case 4: return ($short ? "{$val} H" : "High");
    case 2: case 5: return ($short ? "{$val} M" : "Medium");
    case 3: case 6: return ($short ? "{$val} L" : "Low");
    default: return $val;
  }
}

?>
