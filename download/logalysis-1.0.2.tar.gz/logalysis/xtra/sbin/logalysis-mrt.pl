#!/usr/bin/perl -w
# Version 1.0
# Copyright 2012-2016 Del Castle

use strict;
use threads;
use IO::Socket;

my $listen = IO::Socket::INET->new(LocalPort => 8,
                                   Listen => 100,
                                   ReuseAddr => 1) or die "socket error\n";
my %clients :shared;

sub process_client
{
  my $client = shift;
  my $alert = <$client>;
  if ($alert && ($alert =~ /^logalysis;.+;.+;\d+;.*;.*;\d+$/))
  {
    my @data = split(';', $alert);
    my $file_name = "/var/www/logalysis/files/RT_Messages/${data[1]}";
    unless (-e $file_name)
    {
      open(my $file, ">${file_name}");
      print $file "${data[2]}*${data[3]}*${data[4]}*${data[5]}*${data[6]}*\n";
      close($file);
    }
  }
  close($client);
}

while (my $accept = $listen->accept)
{
  async(\&process_client, $accept)->detach;
}
