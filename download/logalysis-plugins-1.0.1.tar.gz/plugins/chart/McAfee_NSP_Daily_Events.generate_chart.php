<?php

include "plugins/cred/mcafee_nsp.cred.php";

$link = mysqli_connect($mcafee_nsp_db_host, $mcafee_nsp_db_user, $mcafee_nsp_db_pass, $mcafee_nsp_db_name);
if (!$link) die("Error: mysql db {$mcafee_nsp_db_name} connect failed");

if (!isset($shape)) $shape = (isset($_POST["shape"]) ? $_POST["shape"] : "");
if (!isset($blocked)) $blocked = (isset($_POST["blocked"]) ? $_POST["blocked"] : 0);
if (!isset($show_vals)) $show_vals = (isset($_POST["show_vals"]) ? $_POST["show_vals"] : "");

$table = "<table id='mcafee_nsp_daily_events_{$shape}_{$blocked}_table' class='chart'><tr><th class='chart'>Day</th><th class='chart'>Events</th></tr>";
$extra = " AND alertDuration = 0";
if (!$start_time) $start_time = date("Y-m-d 00:00:00", strtotime("-1 month"));
if (!$finish_time) $finish_time = date("Y-m-d 00:00:00", strtotime("+1 day"));
if ($blocked) $extra .= " AND resultSetValue " . ($blocked == "yes" ? ">" : "<") . " 700";
$ptr_time = strtotime($start_time);
while (date("ymd", $ptr_time) < date("ymd", strtotime($finish_time)))
{
  $day = date("d-m-Y", $ptr_time);
  $num = db_result($link, "SELECT COUNT(1) FROM iv_alert WHERE DATE_FORMAT(creationTime, '%d-%m-%Y') = '{$day}'{$extra}");
  $table .= "<tr><td class='chart'>{$day}</td>";
  $table .= "<td class='chart'>{$num}</td></tr>";
  $ptr_time += 60 * 60 * 24;
}
$table .= "</table>";
if (isset($day))
{
  if (empty($nohdr)) echo "<h4>MCAFEE NSP DAILY EVENTS<br />" . date("d-m-Y", strtotime($start_time)) . " - " . date("d-m-Y", strtotime("{$finish_time} -1 day")) . "</h4>";
  if (empty($nogfx)) echo "<canvas id='mcafee_nsp_daily_events_{$shape}_{$blocked}_canvas' width='640' height='320' ondblclick='window.open(this.toDataURL());'></canvas>";
  echo $table;

  if (empty($nogfx)) echo "<script type='text/javascript'>{$shape}Chart(\"mcafee_nsp_daily_events_{$shape}_{$blocked}\", 0, 1" . ($shape == "vbar" ? ", \"{$show_vals}\"" : "") . ");</script>";
}
else echo "<h5>NO EVENTS FOUND!</h5>";

mysqli_close($link);

?>
