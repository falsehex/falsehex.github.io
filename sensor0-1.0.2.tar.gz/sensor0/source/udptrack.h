/* udptrack.h - 01 Sep 15
   PacketZero - 3D Network Monitor
   Copyright 2006-2015 Del Castle  */

#include "common.h"
#include "llist-s.h"

enum udp_kind { UDP_New, UDP_Service, UDP_Stream };  //UDP packet kind

class UDPTrack
{
  private:
    struct udp_track
    {  //1st members used with memcmp
      in_addr SrcIP, DstIP;
      unsigned short SrcPort, DstPort;
      bool Stream;
      time_t Timeout;
    };
    size_t szTrack;
    LinkedList TracksLL;  //dynamic data struct for UDP packet tracking
    void DestroyTracks();
  public:
    UDPTrack();
    ~UDPTrack();
    udp_kind Kind(const packet_info *packet);
};
