<html>
<head>
<meta name='copyright' content='2012-2016 Del Castle' />
<meta charset='UTF-8' />
<meta http-equiv='content-type' content='text/html' />

<?php

include "common.php";
session_start();
/*if (isset($_SESSION["las_last_activity"]) && ((time() - $_SESSION["las_last_activity"]) > 3600))
{
  session_unset();
  session_destroy();
} 
$_SESSION["las_last_activity"] = time();*/
if (empty($_SESSION["las_login_user_name"])) exit("</head><body>{$login_bounce}");
date_default_timezone_set("UTC");

$ackn = (isset($_GET["ackn"]) ? $_GET["ackn"] : "");

while (file_get_contents("files/realtime.lock") && ((time() - filemtime("files/realtime.lock")) < 30)) sleep(1);
file_put_contents("files/realtime.lock", "1");
if ($ackn)
{
  $realtime_plugins = scandir("plugins/realtime");
  foreach ($realtime_plugins as &$row)
  {
    if (strstr($row, ".realtime.php")) include "plugins/realtime/{$row}";
  }
  exec("rm -f \"files/realtime.html\"");
  echo "<script type='text/javascript'>parent.cntRt = -5;</script></head><body>";
}
else
{
  echo "<link rel='stylesheet' type='text/css' href='fx/css/logalysis.css' />";
  echo "<script type='text/javascript' src='fx/js/esort.js'></script>";
  echo "<script type='text/javascript' src='fx/js/logalysis.js'></script>";
  echo "<script type='text/javascript'>";
  echo "var cntRt = -30;";
  echo "function showCount()";
  echo "{";
  echo "if (cntRt) top.frame_menu_main.document.getElementById(\"ancCt\").textContent = cntRt++;";
  echo "else location.href = \"realtime_show.php\";";
  echo "setTimeout(\"showCount()\", 1000);";
  echo "}";
  echo "</script>";

  echo "</head>";
  echo "<body onload='document.getElementsByTagName(\"th\")[0].onclick(); showCount();'>";

  if (file_exists("files/realtime.html") && ((time() - filemtime("files/realtime.html")) < 30)) echo file_get_contents("files/realtime.html");
  else
  {
    ob_start();

    echo "<table id='tblRt' class='esort' onclick='if (cntRt <= 0) cntRt = 1; window.stop();'>";
    echo "<tr><th>P</th><th>Time</th><th>Type</th><th>Alert</th><th>Source</th><th>#</th><th>Actions</th></tr>";
    $count = 0;
    $realtime_plugins = scandir("plugins/realtime");
    foreach ($realtime_plugins as &$row)
    {
      if (strstr($row, ".realtime.php")) include "plugins/realtime/{$row}";
    }
    echo "</table>";
    if (!$count)
    {
      echo "<h5 style='position:fixed; top:5px'>NO REAL-TIME EVENTS!</h5>";

      echo "<script type='text/javascript'>visState(\"tblRt\", 0);</script>";
    }

    file_put_contents("files/realtime.html", ob_get_contents());
    ob_end_flush();
  }
}
file_put_contents("files/realtime.lock", "0");

?>

</body>
</html>
