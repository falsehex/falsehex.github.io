<html>
<head>
<meta name='copyright' content='2012-2016 Del Castle' />
<meta charset='UTF-8' />
<meta http-equiv='content-type' content='text/html' />
<meta http-equiv='refresh' content='300; url=queue_list.php' />
<link rel='stylesheet' type='text/css' href='fx/css/logalysis.css' />

<link rel='stylesheet' type='text/css' href='fx/css/etree.css' />
<script type='text/javascript' src='fx/js/etree.js'></script>

</head>
<body>

<div class='menu'>
  <a class='menu' href='details_show.php' target='frame_show'>NEW JOB</a>
  <a class='menu' href='queue_list.php'>REFRESH</a>
</div><br />

<?php

include "common.php";
session_start();
/*if (isset($_SESSION["las_last_activity"]) && ((time() - $_SESSION["las_last_activity"]) > 3600))
{
  session_unset();
  session_destroy();
} 
$_SESSION["las_last_activity"] = time();*/
if (empty($_SESSION["las_login_user_name"])) exit($login_bounce);

$state_id = (isset($_GET["state_id"]) && is_numeric($_GET["state_id"]) ? $_GET["state_id"] : 1);

$link = logalysis_db_connect();

echo "<script type='text/javascript'>";
echo "var etrQl = new eTree(\"etrQl\");";
$item = -1;
$result1 = mysqli_query($link, "SELECT state_id, name FROM states WHERE is_disabled = FALSE ORDER BY position");
while ($state = mysqli_fetch_row($result1))
{
  $count = db_result($link, "SELECT COUNT(1) FROM jobs WHERE state_id = {$state[0]}");
  echo "etrQl.add(" . ++$item . ", -1, " . ($state[0] == $state_id ? "true" : "false") . ", \"folder\", \"{$state[1]} ({$count})\", \"job_list.php?state_id={$state[0]}\", \"frame_job_list\");";
  if ($count)
  {
    $parent = $item;
    $count = db_result($link, "SELECT COUNT(1) FROM jobs WHERE state_id = {$state[0]} AND assign_user_id = -1");
    if ($count) echo "etrQl.add(" . ++$item . ", {$parent}, false, \"user\", \"{$system} ({$count})\", \"job_list.php?state_id={$state[0]}&user_id=-1\", \"frame_job_list\");";
    $result2 = mysqli_query($link, "SELECT user_id, name FROM users WHERE user_id IN (SELECT assign_user_id FROM jobs WHERE state_id = {$state[0]} GROUP BY assign_user_id)");
    while ($user = mysqli_fetch_row($result2))
    {
      $count = db_result($link, "SELECT COUNT(1) FROM jobs WHERE state_id = {$state[0]} AND assign_user_id = {$user[0]}");
      echo "etrQl.add(" . ++$item . ", {$parent}, false, \"user\", \"{$user[1]} ({$count})\", \"job_list.php?state_id={$state[0]}&user_id={$user[0]}\", \"frame_job_list\");";
    }
    mysqli_free_result($result2);
  }
}
mysqli_free_result($result1);
echo "etrQl.add(" . ++$item . ", -1, false, \"pencil\", \"SCRATCHPAD\", \"menu_main.php?job_id=1&ref_no=SCRATCHPAD\", \"frame_menu_main\");";
echo "etrQl.write();";
echo "</script>";

mysqli_close($link);

?>

</body>
</html>
