/* objects.cpp - 24 Jan 21
   PacketZero - 3D Network Monitor
   Copyright 2006-2021 Del Castle  */

#include <arpa/inet.h>
#ifdef __APPLE__
#include <OpenGL/gl.h>
#else
#include <GL/gl.h>
#endif
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "objects.h"
#include "glue.h"
#include "misc.h"

Objects::Objects()
{
  szHost = sizeof(obj_host);
  szPacket = sizeof(obj_packet);
  szAlert = sizeof(obj_alert);
  szLink = sizeof(obj_link);
  szNetPos = sizeof(net_pos);
  newFrame = 0;
  SelectedHost = 0;
  LinkHost = 0;
}

//create alert
void Objects::CreateAlert(alert_kind kind, obj_host *host, unsigned char protocol)
{
  if (kind != Alert_Anomaly)
  {
    obj_alert *pAlert;
    AlertsLL.End(0);
    while ((pAlert = (obj_alert *)AlertsLL.Read(0)))
    {
      if (pAlert->Host == host)
      {
        if (!pAlert->Kind && !kind)
        {
          pAlert->Protocol = protocol;
          pAlert->Duration = 7;  //reset label time
          return;
        }
        else if (pAlert->Duration == 7) return;  //remove duplicates
      }
      AlertsLL.Prev(0);
    }
  }
  obj_alert oAlert = {kind, protocol, 7, newFrame, host};
  AlertsLL.Write(0, &oAlert, szAlert);
}

//draw hosts
void Objects::DrawHosts(bool second, obj_prefs *prefs)
{
  bool noActiveLabel = (prefs->HostActive != Active_Label);
  if (second) prefs->Anomaly = false;
  if (SelectedHost)  //draw selected host
  {
    glPushMatrix();
    glTranslatef(SelectedHost->X, SelectedHost->Y, SelectedHost->Z);
    if (SelectedHost->Cluster) obj3D.DrawCluster(true);  //bright red selected cluster object
    else obj3D.DrawHost(10, 0, 0, true);  //bright red selected host object
    glPopMatrix();
    if (noActiveLabel && (SelectedHost->Label || prefs->HostLabel) && ((prefs->LabelText != Text_Name) || (*SelectedHost->Hostname != '\0')))  //draw host IP/name
    {
      glColor3ub(clrWhite[0], clrWhite[1], clrWhite[2]);
      glRasterPos3i(SelectedHost->X, SelectedHost->Y + 11, SelectedHost->Z);
      drawString((const unsigned char *)((*SelectedHost->Hostname != '\0') && prefs->LabelText ? SelectedHost->Hostname : inet_ntoa(SelectedHost->HostIP)));
    }
  }
  obj_host *pHost;
  HostsLL.Start(0);
  while ((pHost = (obj_host *)HostsLL.Read(0)))
  {
    if (pHost->Ready)
    {
      if (pHost->Active)
      {
        pHost->Visible = 10;
        pHost->Active = 0;
      }
      if ((pHost != SelectedHost) && ((prefs->HostActive != Active_Show) || pHost->Visible || pHost->Selected || pHost->Anomaly))  //draw host
      {
        glPushMatrix();
        glTranslatef(pHost->X, pHost->Y, pHost->Z);
        if (pHost->Cluster) obj3D.DrawCluster(false);  //cluster object
        else if (pHost->Selected) obj3D.DrawHost(11, 0, 0, true);  //red selection host object
        else obj3D.DrawHost(pHost->Color, 0, 0, true);  //coloured host object
        glPopMatrix();
        if (noActiveLabel && !pHost->Cluster && (pHost->Label || (prefs->HostLabel == Label_All) || ((prefs->HostLabel == Label_Selection) && pHost->Selected))
          && ((prefs->LabelText != Text_Name) || (*pHost->Hostname != '\0')))  //draw host IP/name
        {
          glColor3ub(clrWhite[0], clrWhite[1], clrWhite[2]);
          glRasterPos3i(pHost->X, pHost->Y + 11, pHost->Z);
          drawString((const unsigned char *)((*pHost->Hostname != '\0') && prefs->LabelText ? pHost->Hostname : inet_ntoa(pHost->HostIP)));
        }
      }
      if (second)
      {
        if (pHost->Anomaly)
        {
          prefs->Anomaly = true;
          CreateAlert(Alert_Anomaly, pHost, 248);  //create anomaly alert
        }
        if (pHost->Visible) pHost->Visible--;
      }
    }
    else
    {
      DetectCluster(0, pHost);
      pHost->Ready = 1;
    }
    HostsLL.Next(0);
  }
}

//draw packets
void Objects::DrawPackets(bool animate, obj_prefs *prefs)
{
  double packetSpeed = (prefs->FastPackets ? 2.0 : 1.0) * MOVE_SIZE, moveSteps;
  char strDstPort[6];
  obj_packet *pPacket;
  PacketsLL.Start(0);
  while ((pPacket = (obj_packet *)PacketsLL.Read(0)))
  {
    if (pPacket->Frame == newFrame) break;
    moveSteps = sqrt(sqr(pPacket->X - pPacket->DstHost->X) + sqr(pPacket->Y - pPacket->DstHost->Y) + sqr(pPacket->Z - pPacket->DstHost->Z)) / packetSpeed;  //constant speed for all packets
    if (animate && (moveSteps < 1.0))
    {
      if (prefs->HostActive)
      {
        CreateAlert((prefs->HostActive == Active_Label ? Alert_Label : Alert_Active), pPacket->DstHost, pPacket->Protocol);  //on-active create alert
        if (prefs->HostActive == Active_Show) pPacket->DstHost->Visible = 10;
        else if (prefs->HostActive == Active_Select) pPacket->DstHost->Selected = 1;
      }
      PacketsLL.Delete(0);
    }
    else
    {
      glPushMatrix();
      glTranslated(pPacket->X, pPacket->Y, pPacket->Z);
      switch (pPacket->Protocol)
      {
        case IPPROTO_ICMP: obj3D.DrawPacket(clrRed[0], clrRed[1], clrRed[2]); break;  //ICMP red packet object
        case IPPROTO_TCP: obj3D.DrawPacket(clrGreen[0], clrGreen[1], clrGreen[2]); break;  //TCP green packet object
        case IPPROTO_UDP: obj3D.DrawPacket(clrBlue[0], clrBlue[1], clrBlue[2]); break;  //UDP blue packet object
        case IPPROTO_ARP: obj3D.DrawPacket(clrYellow[0], clrYellow[1], clrYellow[2]); break;  //ARP yellow packet object
        default: obj3D.DrawPacket(clrGrey[0], clrGrey[1], clrGrey[2]);  //other grey packet object
      }
      glPopMatrix();
      if (prefs->PortText)  //show packet destination port
      {
        sprintf(strDstPort, "%hu", pPacket->DstPort);
        glColor3ub(clrWhite[0], clrWhite[1], clrWhite[2]);
        glRasterPos3d(pPacket->X, pPacket->Y + 7.0, pPacket->Z);
        drawString((const unsigned char *)strDstPort);
      }
      if (animate)
      {
        pPacket->X -= (pPacket->X - pPacket->DstHost->X) / moveSteps;
        pPacket->Y -= (pPacket->Y - pPacket->DstHost->Y) / moveSteps;
        pPacket->Z -= (pPacket->Z - pPacket->DstHost->Z) / moveSteps;
      }
      PacketsLL.Next(0);
    }
  }
}

//draw alerts
void Objects::DrawAlerts(bool animate, bool name)
{
  obj_alert *pAlert;
  AlertsLL.Start(0);
  while ((pAlert = (obj_alert *)AlertsLL.Read(0)))
  {
    if (pAlert->Frame == newFrame) break;
    if (animate && ((pAlert->Duration == 255) || (pAlert->Kind && (pAlert->Duration == 16)))) AlertsLL.Delete(0);
    else
    {
      switch (pAlert->Protocol)
      {
        case 248: glColor3ub(clrRedBright[0], clrRedBright[1], clrRedBright[2]); break;  //bright red
        case IPPROTO_ICMP: glColor3ub(clrRed[0], clrRed[1], clrRed[2]); break;  //ICMP red
        case IPPROTO_TCP: glColor3ub(clrGreen[0], clrGreen[1], clrGreen[2]); break;  //TCP green
        case IPPROTO_UDP: glColor3ub(clrBlue[0], clrBlue[1], clrBlue[2]); break;  //UDP blue
        case IPPROTO_ARP: glColor3ub(clrYellow[0], clrYellow[1], clrYellow[2]); break;  //ARP yellow
        default: glColor3ub(clrGreyBright[0], clrGreyBright[1], clrGreyBright[2]);  //other grey
      }
      if (pAlert->Kind)
      {
        glPushMatrix();
        glTranslatef(pAlert->Host->X, pAlert->Host->Y + 5, pAlert->Host->Z);
        glScalef(pAlert->Duration, pAlert->Duration, pAlert->Duration);
        obj3D.DrawAlert((pAlert->Kind == Alert_Active));
        glPopMatrix();
      }
      else
      {
        glRasterPos3i(pAlert->Host->X, pAlert->Host->Y + 11, pAlert->Host->Z);
        drawString((const unsigned char *)((*pAlert->Host->Hostname != '\0') && name ? pAlert->Host->Hostname : inet_ntoa(pAlert->Host->HostIP)));
      }
      if (animate) pAlert->Duration++;
      AlertsLL.Next(0);
    }
  }
}

//draw links
void Objects::DrawLinks(bool show)
{
  obj_link *pLink;
  LinksLL.Start(0);
  while ((pLink = (obj_link *)LinksLL.Read(0)))
  {
    if (show || ((pLink->SrcHost->Visible || pLink->SrcHost->Selected || pLink->SrcHost->AutoLink) && (pLink->DstHost->Visible || pLink->DstHost->Selected || pLink->DstHost->AutoLink)))
      obj3D.DrawLink(pLink->SrcHost->X, pLink->SrcHost->Y + 5, pLink->SrcHost->Z, pLink->DstHost->X, pLink->DstHost->Y + 5, pLink->DstHost->Z);
    LinksLL.Next(0);
  }
}

//check if a host is at a position
obj_host *Objects::CheckHost(unsigned char ptr, const obj_host *host, int x, int y, int z)
{
  obj_host *pHost;
  HostsLL.Start(ptr);
  while ((pHost = (obj_host *)HostsLL.Read(ptr)))
  {
    if ((pHost != host) && (pHost->X == x) && (pHost->Y == y) && (pHost->Z == z)) return pHost;
    HostsLL.Next(ptr);
  }
  return 0;
}

//delete hosts
void Objects::DestroyHosts()
{
  SelectedHost = 0;
  HostsLL.Start(0);
  while (HostsLL.Read(0)) HostsLL.Delete(0);
}

//destroy netpos LL
void Objects::DestroyNetPos()
{
  NetPosLL.Start(0);
  while (NetPosLL.Read(0)) NetPosLL.Delete(0);
}

//return number of packets
unsigned int Objects::Packets()
{
  return PacketsLL.Items();
}

//return number of alerts
unsigned int Objects::Alerts()
{
  return AlertsLL.Items();
}

//return pointer to host from IP address, create host
obj_host *Objects::GetHost(unsigned char ptr, in_addr ip, bool add, const obj_prefs *prefs)
{
  obj_host *pHost;
  HostsLL.End(ptr);
  while ((pHost = (obj_host *)HostsLL.Read(ptr)))
  {
    if (pHost->HostIP.s_addr == ip.s_addr) return pHost;
    HostsLL.Prev(ptr);
  }
  if (add)
  {
    obj_host oHost = {0, 0, 0, 0, prefs->AnomDetect, prefs->NewLinks, 0, 0, prefs->NewPackets, 0, 0, HOST_SPACE, 0, HOST_SPACE, 0, 0, 0, 0, ip, "", "", ""
      , {-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1}};
    if (NetHost(ptr, &oHost) != 2) BlankHost(ptr, &oHost, 1, ROW_HOSTS);
    pHost = (obj_host *)HostsLL.Write(ptr, &oHost, szHost);
    return pHost;
  }
  return 0;
}

//create packet
void Objects::CreatePacket(const packet_info *packet, obj_host *srchost, obj_host *dsthost, bool link, const obj_prefs *prefs)
{
  if ((srchost->Packets || dsthost->Packets) && (!prefs->ShowSensor || (packet->Sensor == prefs->ShowSensor)) && (!prefs->ShowProtocol || (packet->Protocol == prefs->ShowProtocol))
    && (!prefs->ShowPort || (packet->SrcPort == prefs->ShowPort) || (packet->DstPort == prefs->ShowPort)))
  {
    obj_packet *pPacket;
    PacketsLL.End(2);
    while ((pPacket = (obj_packet *)PacketsLL.Read(2)))
    {
      if ((pPacket->X == srchost->X) && (pPacket->Y == srchost->Y) && (pPacket->Z == srchost->Z) && (pPacket->DstHost == dsthost))
      {
        PacketsLL.Free(2);
        return;
      }
      PacketsLL.Prev(2);
    }
    obj_packet oPacket = {packet->Protocol, packet->DstPort, newFrame, (double)srchost->X, (double)srchost->Y, (double)srchost->Z, dsthost};
    PacketsLL.Write(2, &oPacket, szPacket);
    PacketsLL.Free(2);
    if (link && (srchost->AutoLink || dsthost->AutoLink)) CreateLink(2, srchost, dsthost, 0);
    if (prefs->HostActive == Active_Show) srchost->Active = 1;
    else if (prefs->HostActive == Active_Select) srchost->Selected = 1;
  }
}

//create link
void Objects::CreateLink(unsigned char ptr, obj_host *srchost, obj_host *dsthost, unsigned char spare)
{
  obj_link *pLink;
  LinksLL.End(ptr);
  while ((pLink = (obj_link *)LinksLL.Read(ptr)))
  {
    if (((pLink->SrcHost == srchost) && (pLink->DstHost == dsthost)) || ((pLink->SrcHost == dsthost) && (pLink->DstHost == srchost)))
    {
      LinksLL.Free(ptr);
      return;
    }
    LinksLL.Prev(ptr);
  }
  obj_link oLink = {srchost, dsthost, spare};
  LinksLL.Write(ptr, &oLink, szLink);
  LinksLL.Free(ptr);
}

//delete link to selected host
void Objects::DeleteLink(const obj_host *host)
{
  obj_link *pLink;
  LinksLL.Start(0);
  while ((pLink = (obj_link *)LinksLL.Read(0)))
  {
    if (((pLink->SrcHost == LinkHost) && (pLink->DstHost == host)) || ((pLink->SrcHost == host) && (pLink->DstHost == LinkHost)))
    {
      LinksLL.Delete(0);
      break;
    }
    LinksLL.Next(0);
  }
}

//draw all objects
void Objects::Draw(bool animate, bool second, obj_prefs *prefs)
{
  newFrame++;
  obj3D.DrawCross();
  DrawHosts((animate && second), prefs);
  if (Alerts()) DrawAlerts(animate, (prefs->LabelText != Text_IP));
  if (Packets()) DrawPackets(animate, prefs);
  if (LinksLL.Items()) DrawLinks((prefs->HostActive != Active_Show));
}

//draw hosts for picking
void Objects::DrawPick(bool single, bool visible)
{
  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
  if (SelectedHost)  //draw selected host
  {
    glPushMatrix();
    glTranslatef(SelectedHost->X, SelectedHost->Y, SelectedHost->Z);
    obj3D.DrawHost(1, 0, 0, false);
    glPopMatrix();
  }
  unsigned int cntHost = 2;
  obj_host *pHost;
  HostsLL.Start(0);
  while ((pHost = (obj_host *)HostsLL.Read(0)))
  {
    if ((pHost != SelectedHost) && (single || !pHost->Selected) && (visible || pHost->Visible || pHost->Anomaly) && pHost->Ready)  //draw host
    {
      glPushMatrix();
      glTranslatef(pHost->X, pHost->Y, pHost->Z);
      obj3D.DrawHost((unsigned char)(cntHost % 256), (unsigned char)((cntHost >> 8) % 256), (unsigned char)((cntHost >> 16) % 256), false);
      glPopMatrix();
    }
    cntHost++;
    HostsLL.Next(0);
  }
}

//find blank host position
void Objects::BlankHost(unsigned char ptr, obj_host *host, int hostspace, int rowhosts)
{
  hostspace *= HOST_SPACE;
  rowhosts *= hostspace;  //dimensions
  int posX = host->X, posY = host->Y, posZ = host->Z, startX = posX, startZ = posZ
    , spaceX = (posX >= 0 ? hostspace : -hostspace), spaceY = (posY >= 0 ? hostspace : -hostspace), spaceZ = (posZ >= 0 ? hostspace : -hostspace);
  while (CheckHost(ptr, host, posX, posY, posZ))
  {
    posX += spaceX;
    if (abs(posX - startX) == rowhosts)
    {
      posX = startX;
      posZ += spaceZ;
      if (abs(posZ - startZ) == rowhosts)
      {
        posZ = startZ;
        posY += spaceY;
      }
    }
    HostsLL.Free(ptr);
  }
  host->X = posX;
  host->Y = posY;
  host->Z = posZ;
}

//detect host collision on move
void Objects::DetectCluster(unsigned char ptr, obj_host *host)
{
  obj_host *pHost;
  if ((pHost = host->Cluster))
  {
    if (pHost->Cluster == host) pHost->Cluster = 0;
    else
    {
      while (pHost->Cluster != host) pHost = pHost->Cluster;
      pHost->Cluster = host->Cluster;
    }
    host->Cluster = 0;
  }
  if ((pHost = CheckHost(ptr, host, host->X, host->Y, host->Z)))
  {
    host->Cluster = (pHost->Cluster ? pHost->Cluster : pHost);
    pHost->Cluster = host;
    HostsLL.Free(ptr);
  }
}

//set value for all hosts
void Objects::SetHosts(int id, unsigned char val, bool show)
{
  obj_host *pHost;
  HostsLL.Start(0);
  while ((pHost = (obj_host *)HostsLL.Read(0)))
  {
    switch (id)
    {
      case 0: pHost->Anomaly = val; break;
      case 1: pHost->AutoLink = val; break;
      case 2: pHost->Label = val; break;
      case 3: pHost->Packets = val; break;
      case 4:
        if (!val && show && pHost->Selected) pHost->Visible = 10;
        pHost->Selected = val;
        break;
    }
    HostsLL.Next(0);
  }
}

//load selected host info into buffer
void Objects::InfoSelected(char *buffer)
{
  strncpy(buffer, "IP: ", 5);
  strncat(buffer, inet_ntoa(SelectedHost->HostIP), 15);
  if ((*SelectedHost->HostMAC != '\0') && strcmp(SelectedHost->HostMAC, "00:00:00:00:00:00"))
  {
    strcat(buffer, "\nMAC: ");
    strncat(buffer, SelectedHost->HostMAC, 17);
  }
  if (*SelectedHost->Hostname != '\0')
  {
    strcat(buffer, "\nName: ");
    strncat(buffer, SelectedHost->Hostname, 255);
  }
  if (*SelectedHost->Remarks != '\0')
  {
    strcat(buffer, "\nRemarks: ");
    strncat(buffer, SelectedHost->Remarks, 255);
  }
}

//generate host info
void Objects::InfoHost(char *buffer)
{
  char strPath[4096];
  FILE *fileInfo;
  if ((fileInfo = fopen(getPath("tmp_packet0", strPath), "w")))
  {
    char strBuffer[11];
    fputs(buffer, fileInfo);
    fprintf(fileInfo, "\n\nAnomaly: %s\nLast Sensor: %hhu\nLast Packet: %sShow Packets: %s\nDownloads: %s", (SelectedHost->Anomaly ? "Yes" : "No"), SelectedHost->LastSensor
      , ctime(&SelectedHost->LastPacket), (SelectedHost->Packets ? "Yes" : "No"), formatBytes(SelectedHost->Downloads, strBuffer));
    fprintf(fileInfo, "\nUploads: %s\nAuto Link Lines: %s\nLock: %s", formatBytes(SelectedHost->Uploads, strBuffer), (SelectedHost->AutoLink ? "Yes" : "No")
      , (SelectedHost->Lock ? "On" : "Off"));
    if (SelectedHost->Services[0] == -1) fprintf(fileInfo, "\n\nNO SERVICES");
    else
    {
      fprintf(fileInfo, "\n\nSERVICES\nProtocol\tPort");
      for (unsigned char cntService = 0; cntService < HOST_SERVICES; cntService++)
      {
        if (SelectedHost->Services[cntService] != -1)
          fprintf(fileInfo, "\n%s\t%d", decodeProtocol((SelectedHost->Services[cntService] % 10000) / 10, strBuffer), SelectedHost->Services[cntService] / 10000);
        else break;
      }
    }
    fclose(fileInfo);
  }
}

//generate selection info
void Objects::InfoSelection()
{
  char strPath[4096];
  FILE *fileInfo;
  if ((fileInfo = fopen(getPath("tmp_packet0", strPath), "w")))
  {
    fprintf(fileInfo, "CURRENT SELECTION\n");
    obj_host *pHost;
    HostsLL.Start(0);
    while ((pHost = (obj_host *)HostsLL.Read(0)))
    {
      if (pHost->Selected) fprintf(fileInfo, "\n%s\t%s", inet_ntoa(pHost->HostIP), pHost->Hostname);
      HostsLL.Next(0);
    }
    fclose(fileInfo);
  }
}

//generate general info
void Objects::InfoGeneral()
{
  char strPath[4096];
  FILE *fileInfo;
  if ((fileInfo = fopen(getPath("tmp_packet0", strPath), "w")))
  {
    unsigned int cntHosts = 0;
    unsigned long long cntDownloads = 0, cntUploads = 0;
    char strBuffer[11];
    obj_host *pHost;
    HostsLL.Start(0);
    while ((pHost = (obj_host *)HostsLL.Read(0)))
    {
      if (pHost->Selected)
      {
        cntDownloads += pHost->Downloads;
        cntUploads += pHost->Uploads;
        cntHosts++;
      }
      HostsLL.Next(0);
    }
    fprintf(fileInfo, "GENERAL\n\nHosts: %u\nDownloads: %s", cntHosts, formatBytes(cntDownloads, strBuffer));
    fprintf(fileInfo, "\nUploads: %s", formatBytes(cntUploads, strBuffer));
    fclose(fileInfo);
  }
}

//select next/previous host in selection
void Objects::TabHost(char *buffer, bool ctrl)
{
  obj_host *pHost;
  (ctrl ? HostsLL.End(0) : HostsLL.Start(0));
  if (SelectedHost)
  {
    while ((pHost = (obj_host *)HostsLL.Read(0)))
    {
      if (pHost == SelectedHost) break;
      (ctrl ? HostsLL.Prev(0) : HostsLL.Next(0));
    }
    (ctrl ? HostsLL.Prev(0) : HostsLL.Next(0));
  }
  for (int cntChar = 0; cntChar < 2; cntChar++)
  {
    while ((pHost = (obj_host *)HostsLL.Read(0)))
    {
      if (pHost->Selected)
      {
        SelectedHost = pHost;
        InfoSelected(buffer);
        return;
      }
      (ctrl ? HostsLL.Prev(0) : HostsLL.Next(0));
    }
    if (SelectedHost) (ctrl ? HostsLL.End(0) : HostsLL.Start(0));
    else break;
  }
}

//add service to host
void Objects::AddService(obj_host *host, int service, bool anomdetect)
{
  for (unsigned char cntService = 0; cntService < HOST_SERVICES; cntService++)
  {
    if (host->Services[cntService] == service) break;
    if (host->Services[cntService] == -1)
    {
      host->Services[cntService] = service;
      if (anomdetect) host->Anomaly = 1;
      break;
    }
  }
}

//save links
void Objects::SaveLinks(FILE *file)
{
  size_t szIP = sizeof(in_addr);
  obj_link *pLink;
  LinksLL.Start(0);
  while ((pLink = (obj_link *)LinksLL.Read(0)))
  {
    if (fwrite(&pLink->SrcHost->HostIP, szIP, 1, file) != 1) break;
    if (fwrite(&pLink->DstHost->HostIP, szIP, 1, file) != 1) break;
    if (fwrite(&pLink->Spare, 1, 1, file) != 1) break;  //spare (future use)
    LinksLL.Next(0);
  }
}

//load network layout
void Objects::LoadNet(const char *filename)
{
  FILE *fileNet;
  if ((fileNet = fopen(filename, "rb")))
  {
    char strId[5];
    if (fgets(strId, 5, fileNet))
    {
      if (!strcmp(strId, "0NL0"))
      {
        DestroyAll();
        unsigned char valSpare;
        unsigned int cntHosts;
        in_addr oIP;
        obj_host oHost, *pHost, *pDstHost;
        size_t szIP = sizeof(in_addr);
        if (fread(&cntHosts, sizeof(cntHosts), 1, fileNet) == 1)
        {
          for (; cntHosts; cntHosts--)
          {
            if (fread(&oHost, szHost, 1, fileNet) != 1)
            {
              fclose(fileNet);
              return;
            }
            oHost.Cluster = 0;
            pHost = (obj_host *)HostsLL.Write(0, &oHost, szHost);
            DetectCluster(0, pHost);
          }
          while (fread(&oIP, szIP, 1, fileNet) == 1)
          {
            pHost = GetHost(0, oIP, false, 0);
            if (fread(&oIP, szIP, 1, fileNet) != 1) break;
            pDstHost = GetHost(0, oIP, false, 0);
            if (fread(&valSpare, 1, 1, fileNet) != 1) break;
            if (pHost && pDstHost) CreateLink(0, pHost, pDstHost, valSpare);
          }
        }
      }
    }
    fclose(fileNet);
  }
}

//save network layout
void Objects::SaveNet(const char *filename)
{
  FILE *fileNet;
  if ((fileNet = fopen(filename, "wb")))
  {
    unsigned int cntHosts = HostsLL.Items();
    fputs("0NL0", fileNet);
    if (fwrite(&cntHosts, sizeof(cntHosts), 1, fileNet) == 1)
    {
      obj_host *pHost;
      HostsLL.Start(0);
      while ((pHost = (obj_host *)HostsLL.Read(0)))
      {
        if (!cntHosts--) break;
        if (fwrite(pHost, szHost, 1, fileNet) != 1)
        {
          fclose(fileNet);
          remove(filename);
          return;
        }
        HostsLL.Next(0);
      }
      SaveLinks(fileNet);
    }
    fclose(fileNet);
  }
}

//load netpos file into memory, create empty
void Objects::LoadNetPos(const char *filename)
{
  FILE *fileNetPos;
  if ((fileNetPos = fopen(filename, "r")))
  {
    DestroyNetPos();
    net_pos oNetPos;
    int chText;
    do {
      if ((chText = getc(fileNetPos)) == 'p')
      {
        if (fscanf(fileNetPos, "%*s%18s%d%d%d%*c%c", (char *)&oNetPos.Net, &oNetPos.X, &oNetPos.Y, &oNetPos.Z, &oNetPos.Color) == 5)
          NetPosLL.Write(0, &oNetPos, szNetPos);  //pos 123.123.123.123/32 10 0 -10 green
      }
      else
      {
        while ((chText != '\n') && (chText != EOF)) chText = getc(fileNetPos);
      }
    } while (chText != EOF);
    fclose(fileNetPos);
  }
  else if ((fileNetPos = fopen(filename, "w")))
  {
    fputs("#pos net x-position y-position z-position colour\n", fileNetPos);
    fclose(fileNetPos);
  }
}

//check if an IP address is a broadcast address
in_addr_t Objects::IsBroadcast(in_addr ip)
{
  in_addr_t netMask;
  char netTemp[19], *pPrefix;
  net_pos *pNetPos;
  NetPosLL.Start(2);
  while ((pNetPos = (net_pos *)NetPosLL.Read(2)))
  {
    strncpy(netTemp, pNetPos->Net, 19);
    if ((pPrefix = strchr(netTemp, '/')))
    {
      *pPrefix = '\0';
      if (atoi(++pPrefix)) netMask = htonl(0xFFFFFFFF << (32 - atoi(pPrefix)));
      else netMask = 0;
      if ((inet_addr(netTemp) | ~netMask) == ip.s_addr)
      {
        NetPosLL.Free(2);
        return netMask;
      }
    }
    NetPosLL.Next(2);
  }
  return 0;
}

//check if a host is to be positioned into a net
int Objects::NetHost(unsigned char ptr, obj_host *host)
{
  net_pos *pNetPos;
  NetPosLL.Start(ptr);
  while ((pNetPos = (net_pos *)NetPosLL.Read(ptr)))
  {
    if (inNet(pNetPos->Net, host->HostIP))
    {
      host->X = pNetPos->X * HOST_SPACE;
      host->Y = pNetPos->Y * HOST_SPACE;
      host->Z = pNetPos->Z * HOST_SPACE;
      switch (pNetPos->Color)
      {
        case 'd': host->Color = 0; break;  //grey (default) host object
        case 'o': host->Color = 1; break;  //orange host object
        case 'y': host->Color = 2; break;  //yellow host object
        case 'f': host->Color = 3; break;  //fluro host object
        case 'g': host->Color = 4; break;  //green host object
        case 'm': host->Color = 5; break;  //mint host object
        case 'a': host->Color = 6; break;  //aqua host object
        case 'b': host->Color = 7; break;  //blue host object
        case 'p': host->Color = 8; break;  //purple host object
        case 'v': host->Color = 9; break;  //violet host object
        case 'h': NetPosLL.Free(ptr); return 2;  //hold host object
      }
      NetPosLL.Free(ptr);
      return 1;
    }
    NetPosLL.Next(ptr);
  }
  return 0;
}

//destroy packets LL
void Objects::DestroyPackets(const obj_host *host)
{
  obj_packet *pPacket;
  PacketsLL.Start(0);
  while ((pPacket = (obj_packet *)PacketsLL.Read(0)))
  {
    if (!host || (pPacket->DstHost == host)) PacketsLL.Delete(0);
    else PacketsLL.Next(0);
  }
}

//destroy alerts LL
void Objects::DestroyAlerts(const obj_host *host)
{
  obj_alert *pAlert;
  AlertsLL.Start(0);
  while ((pAlert = (obj_alert *)AlertsLL.Read(0)))
  {
    if (!host || (pAlert->Host == host)) AlertsLL.Delete(0);
    else AlertsLL.Next(0);
  }
}

//destroy links LL
void Objects::DestroyLinks(const obj_host *host)
{
  LinkHost = 0;
  obj_link *pLink;
  LinksLL.Start(0);
  while ((pLink = (obj_link *)LinksLL.Read(0)))
  {
    if (!host || (pLink->SrcHost == host) || (pLink->DstHost == host)) LinksLL.Delete(0);
    else LinksLL.Next(0);
  }
}

//destroy all LL
void Objects::DestroyAll()
{
  DestroyHosts();
  DestroyPackets();
  DestroyAlerts();
  DestroyLinks();
}

Objects::~Objects()
{
  DestroyAll();
  DestroyNetPos();
}
