<?php

include "plugins/misc/sourcefire.php";
include "plugins/cred/sourcefire.cred.php";

$link = mysqli_connect($sourcefire_db_host, $sourcefire_db_user, $sourcefire_db_pass, $sourcefire_db_name);
if ($link)
{
  if ($ackn == "sourcefire")
  {
    $part = explode(";", $_GET["file_id"]);
    mysqli_query($link, "UPDATE event SET reviewed = {$part[5]} WHERE reviewed = {$part[4]} AND sig_gen = {$part[0]} AND sig_id = {$part[1]} AND ip_src = {$part[2]} AND tv_sec <= {$part[3]}");
    if (mysqli_affected_rows($link))
    {
      $part[0] .= ":{$part[1]}";
      $part[2] = long2ip($part[2]);
      file_put_contents("/var/log/logalysis/ack.log", time() . " \"{$_SESSION["las_login_user_name"]}\" " . ($part[5] == 1 ? "ACK" : ($part[5] == 2 ? "CHK" : "UCK")) . " \"SOURCEFIRE\" \"{$part[0]}\" \"{$part[2]}\" {$part[3]} {$part[6]}\n", FILE_APPEND);
    }
  }

  if (!$ackn)
  {
    include "plugins/edit/sf_auto_ack_sigs.php";

    $result = mysqli_query($link, "SELECT tv_sec, FROM_UNIXTIME(tv_sec), priority, blocked, sensor_id, protocol, ip_src, INET_NTOA(ip_src), sport_itype, INET_NTOA(ip_dst), dport_icode, sig_gen, sig_id, classification, event_id, COUNT(1), reviewed FROM event WHERE reviewed != 1 GROUP BY sig_gen, sig_id, ip_src, reviewed ORDER BY priority, sig_id LIMIT 20");
    while ($row = mysqli_fetch_row($result))
    {
      $sig = "{$row[11]}:{$row[12]}";
      if (in_array("{$sig} => any", $auto_ack) || in_array("{$sig} => {$row[7]}", $auto_ack))
      {
        mysqli_query($link, "UPDATE event SET reviewed = 1 WHERE reviewed != 1 AND sig_gen = {$row[11]} AND sig_id = {$row[12]} AND ip_src = {$row[6]}");
        continue;
      }
      $label = preg_replace("/^\"(.*)\"$/", "$1", db_result($link, "SELECT msg FROM ids_event_msg_map WHERE " . ($row[11] > 3 ? "gid = {$row[11]} AND " : "") . "local_sid = {$row[12]} ORDER BY rev DESC LIMIT 1"));
      //$row[13] = db_result($link, "SELECT description FROM ids_event_class_map WHERE local_id = {$row[13]}");
      $row[14] = db_result($link, "SELECT COUNT(1) FROM packet_log WHERE sensor_id = {$row[4]} AND event_id = {$row[14]} AND event_sec = {$row[0]}");
      $row[4] .= ":" . db_result($link, "SELECT name FROM de_cache_de_config WHERE id = {$row[4]}");
      $file_id = "{$row[11]};{$row[12]};{$row[6]};" . time() . ";{$row[16]}";
      $row[14] = ($row[14] ? "<a class='action' href='pcap_get.php?plugin=Sourcefire_RT&file_id={$file_id}'>PCAP</a> <a class='action' href='file_layout.php?job_id=1&ref_no=SCRATCHPAD&search=Sourcefire_RT;{$row[1]};{$row[1]};{$row[7]};{$row[8]};{$row[9]};{$row[10]}&file_id={$file_id}' target='frame_show'>FILE</a>" : "");
      $url = "realtime_show.php?ackn=sourcefire&file_id={$file_id}";
      $priority = sourcefire_priority($row[2], TRUE, ($row[16] == 2));
      echo "<tr onclick='txtBold(this.style);'>";
      echo "<td style='background:" . priority_color($priority) . "'><a class='action' href='javascript:void(0);' ondblclick='if (ackAlert(\"{$url};" . ($row[16] == 2 ? 0 : 2) . ";\" + cntRt)) setPriority(this);'>{$priority}</a></td>";
      echo "<td>{$row[1]}</td>";
      echo "<td" . ($row[3] != 1 ? " style='background:red'" : "") . "><a class='action' href='{$sourcefire_www_host}' target='_blank'>Sourcefire</a></td>";
      echo "<td title='Class: {$sourcefire_classification[$row[13]]}\nBlock: {$sourcefire_result[$row[3]]}\nProto: " . protocol_name($row[5]) . "\nSrc: {$row[7]}:{$row[8]}\nDst: {$row[9]}:{$row[10]}'>{$label} " . ($row[11] > 3 ? $sig : "<a class='action' href='javascript:popUp(\"{$sourcefire_www_host}/external_rule.cgi?sid={$row[12]}\");'>{$sig}</a>") . "</td>";
      echo "<td><a class='action' href='javascript:popUp(\"host_show.php?host_ip={$row[7]}\");'>{$row[7]}</a></td>";
      echo "<td>{$row[15]}</td>";
      echo "<td><a class='action' href='javascript:void(0);' ondblclick='if (ackAlert(\"{$url};1;\" + cntRt)) this.parentNode.parentNode.style.display = \"none\";'>ACK</a> {$row[14]} ";
      echo "<a class='action' href='javascript:void(0);' ondblclick='location.href = \"details_show.php?details=\" + cntRt + \"" . urlencode(";0;1;4;0;{$row[4]};Sourcefire Alert: " . strtr($label, "'", "\"") . ";GID/SID: {$sig}\nClassification: {$sourcefire_classification[$row[13]]}\nBlocked: {$sourcefire_result[$row[3]]};;;;;{$row[1]};{$row[5]};{$row[7]};{$row[8]};{$row[9]};{$row[10]}") . "\"'>JOB</a></td></tr>";
      $count++;
    }
    $total = db_result($link, "SELECT COUNT(1) FROM event WHERE reviewed = 0");
    if ($total > 50) echo "<tr><td style='background:red'>0 E</td><td></td><td>Sourcefire</td><td>SOURCEFIRE ALERTS > 50</td><td></td><td>{$total}</td><td></td></tr>";
  }

  mysqli_close($link);
}
else echo "<tr><td style='background:red'>0 E</td><td></td><td>Sourcefire</td><td>ERROR: MYSQL DB {$sourcefire_db_name} CONNECT FAILED</td><td></td><td></td><td></td></tr>";

?>
