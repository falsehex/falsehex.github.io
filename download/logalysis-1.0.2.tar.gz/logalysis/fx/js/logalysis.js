/* Copyright 2012-2016 Del Castle */

var styTr = null;

function addZero(val)
{
  return (val < 10 ? "0" + val : val);
}

function nowUTC(sec)
{
  var objDt = new Date();
  return objDt.getUTCFullYear() + "-"
       + addZero(objDt.getUTCMonth() + 1) + "-"
       + addZero(objDt.getUTCDate()) + " "
       + addZero(objDt.getUTCHours()) + ":"
       + addZero(objDt.getUTCMinutes()) + ":"
       + (sec ? addZero(objDt.getUTCSeconds()) : "00");
}

function hidFrame(url)
{
  var frmHd = document.createElement("iframe");
  frmHd.style.display = "none";
  frmHd.style.height = 0;
  frmHd.style.width = 0;
  frmHd.src = url;
  document.body.appendChild(frmHd);
}

function ackAlert(url)
{
  if ((cntRt < 120) || confirm("Confirm Spent More Than 2 Minutes"))
  {
    cntRt = 1;
    hidFrame(url);
    return true;
  }
  cntRt = 1;
  return false;
}

function popUp(url)
{
  var winPu = window.open(url, "", "height=600,left=200,menubar=no,scrollbars=yes,toolbar=no,width=800");
  if (!url) return winPu;
}

function setPriority(ancPr)
{
  var aryPr = ancPr.textContent.split("");
  switch (aryPr[0])
  {
    case "4": ancPr.parentNode.style.backgroundColor = "red"; break;
    case "5": ancPr.parentNode.style.backgroundColor = "orange"; break;
    case "6": ancPr.parentNode.style.backgroundColor = "gold"; break;
    default: ancPr.parentNode.style.backgroundColor = "limegreen";
  }
  aryPr[0] = (aryPr[0] > 3 ? aryPr[0] - 3 : parseInt(aryPr[0]) + 3);
  ancPr.textContent = aryPr.join("");
  ancPr.style.cursor = "wait";
  ancPr.ondblclick = "";
}

function txtBold(sty)
{
  if (styTr)
  {
    styTr.backgroundColor = "#DBD8BE";
    styTr.fontWeight = "normal";
  }
  sty.backgroundColor = "#BFBCA2";
  sty.fontWeight = "bold";
  styTr = sty;
}

function visState(id, val)
{
  document.getElementById(id).style.visibility = (val ? "visible" : "hidden");
}
