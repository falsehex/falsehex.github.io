<?php

include "plugins/misc/snort.php";
include "plugins/cred/snort.cred.php";

$link = mysqli_connect($snort_db_host, $snort_db_user, $snort_db_pass, $snort_db_name);
if (!$link) die("Error: mysql db {$snort_db_name} connect failed");

if (!isset($ip_or)) $ip_or = (isset($_GET["ip_or"]) ? $_GET["ip_or"] : "");

echo "<script type='text/javascript'>";
echo "function sngJob(objTr) { aryTd = objTr.getElementsByTagName(\"td\"); parent.location.href = \"details_show.php?details=\" + escape(\"0;0;1;4;{$login_user_id};\" + aryTd[3].textContent + \";Snort Alert: \" + aryTd[4].textContent.replace(/'/g, \"\\\"\") + \";GID/SID: \" + aryTd[5].textContent + \"\\nClassification: \" + aryTd[11].textContent + \";;;;;\" + aryTd[1].textContent + \";\" + aryTd[6].textContent + \";\" + aryTd[7].textContent + \";\" + aryTd[8].textContent + \";\" + aryTd[9].textContent + \";\" + aryTd[10].textContent); }";
echo "</script>";

if (empty($nohdr)) echo "<h4>SNORT</h4>";
echo "<table class='esort'>";
echo "<tr><th></th><th>Time</th><th>Priority</th><th>Sensor</th><th>Alert</th><th>GID/SID</th><th>Protocol</th><th>Source IP</th><th>Port</th><th>Target IP</th><th>Port</th><th>Classification</th><th>EID</th><th>Actions</th></tr>";
$count = 0;
$extra = ($start_time ? " WHERE timestamp >= '{$start_time}'" : "");
if ($finish_time) $extra .= ($extra ? " AND" : " WHERE") . " timestamp <= '{$finish_time}'";
if ($source_ip)
{
  if ($ip_or)
  {
    if (substr_count($source_ip, ".") == 3) $extra .= ($extra ? " AND" : " WHERE") . " ((sid, cid) IN (SELECT sid, cid FROM iphdr WHERE INET_NTOA(ip_src) = '{$source_ip}') OR (sid, cid) IN (SELECT sid, cid FROM iphdr WHERE INET_NTOA(ip_dst) = '{$source_ip}'))";
    else $extra .= ($extra ? " AND" : " WHERE") . " ((sid, cid) IN (SELECT sid, cid FROM iphdr WHERE INET_NTOA(ip_src) LIKE '{$source_ip}%') OR (sid, cid) IN (SELECT sid, cid FROM iphdr WHERE INET_NTOA(ip_dst) LIKE '{$source_ip}%'))";
  }
  else
  {
    if (substr_count($source_ip, ".") == 3) $extra .= ($extra ? " AND" : " WHERE") . " (sid, cid) IN (SELECT sid, cid FROM iphdr WHERE INET_NTOA(ip_src) = '{$source_ip}')";
    else $extra .= ($extra ? " AND" : " WHERE") . " (sid, cid) IN (SELECT sid, cid FROM iphdr WHERE INET_NTOA(ip_src) LIKE '{$source_ip}%')";
  }
}
if ($source_port) $extra .= ($extra ? " AND" : " WHERE") . " (sid, cid) IN (SELECT sid, cid FROM tcphdr WHERE tcp_sport = {$source_port} UNION SELECT sid, cid FROM udphdr WHERE udp_sport = {$source_port})";
if ($target_ip)
{
  if (substr_count($target_ip, ".") == 3) $extra .= ($extra ? " AND" : " WHERE") . " (sid, cid) IN (SELECT sid, cid FROM iphdr WHERE INET_NTOA(ip_dst) = '{$target_ip}')";
  else $extra .= ($extra ? " AND" : " WHERE") . " (sid, cid) IN (SELECT sid, cid FROM iphdr WHERE INET_NTOA(ip_dst) LIKE '{$target_ip}%')";
}
if ($target_port) $extra .= ($extra ? " AND" : " WHERE") . " (sid, cid) IN (SELECT sid, cid FROM tcphdr WHERE tcp_dport = {$target_port} UNION SELECT sid, cid FROM udphdr WHERE udp_dport = {$target_port})";
if ($num_2 || $num_3) $extra .= ($extra ? " AND" : " WHERE") . " signature = (SELECT sig_id FROM signature WHERE";
if ($num_2) $extra .= " sig_gid = {$num_2}" . ($num_3 ? " AND" : ")");
if ($num_3) $extra .= " sig_sid = {$num_3})";
if ($num_4) $extra .= ($extra ? " AND" : " WHERE") . " cid = {$num_4}";
$result = mysqli_query($link, "SELECT * FROM event{$extra} ORDER BY timestamp LIMIT {$limit}");  //sid, cid, signature, timestamp
while ($row = mysqli_fetch_row($result))
{
  $evt[0] = $row[3];
  $evt[1] = db_result($link, "SELECT sig_priority FROM signature WHERE sig_id = {$row[2]}");
  $evt[2] = "{$row[0]}:" . db_result($link, "SELECT hostname FROM sensor WHERE sid = {$row[0]}");
  $evt[3] = db_result($link, "SELECT sig_name FROM signature WHERE sig_id = {$row[2]}");
  $evt[4] = db_result($link, "SELECT sig_gid FROM signature WHERE sig_id = {$row[2]}");
  $evt[5] = db_result($link, "SELECT sig_sid FROM signature WHERE sig_id = {$row[2]}");
  $evt[6] = db_result($link, "SELECT ip_proto FROM iphdr WHERE sid = {$row[0]} AND cid = {$row[1]}");
  $evt[7] = db_result($link, "SELECT INET_NTOA(ip_src) FROM iphdr WHERE sid = {$row[0]} AND cid = {$row[1]}");
  $evt[9] = db_result($link, "SELECT INET_NTOA(ip_dst) FROM iphdr WHERE sid = {$row[0]} AND cid = {$row[1]}");
  if ($evt[6] == 6)  //TCP
  {
    $evt[8] = db_result($link, "SELECT tcp_sport FROM tcphdr WHERE sid = {$row[0]} AND cid = {$row[1]}");
    $evt[10] = db_result($link, "SELECT tcp_dport FROM tcphdr WHERE sid = {$row[0]} AND cid = {$row[1]}");
  }
  else if ($evt[6] == 17)  //UDP
  {
    $evt[8] = db_result($link, "SELECT udp_sport FROM udphdr WHERE sid = {$row[0]} AND cid = {$row[1]}");
    $evt[10] = db_result($link, "SELECT udp_dport FROM udphdr WHERE sid = {$row[0]} AND cid = {$row[1]}");
  }
  else
  {
    $evt[8] = NULL;
    $evt[10] = NULL;
  }
  $evt[11] = db_result($link, "SELECT sig_class_name FROM sig_class WHERE sig_class_id = (SELECT sig_class_id FROM signature WHERE sig_id = {$row[2]})");
  $evt[12] = $row[1];
  $data = db_result($link, "SELECT COUNT(1) FROM data WHERE sid = {$row[0]} AND cid = {$row[1]}");
  if ($action) $save[] = array($evt[0], NULL, $evt[1], $evt[4], $evt[5], $evt[12], NULL, $evt[11], NULL, $evt[2], $evt[3], NULL, NULL, $evt[6], $evt[7], $evt[8], $evt[9], $evt[10], $data);
  echo "<tr onclick='txtBold(this.style);'><td>" . ++$count . "</td>";
  $evt[1] = snort_priority($evt[1], FALSE, FALSE);
  $evt[4] = (($evt[4] == 1) || ($evt[4] == 3) ? "<a class='action' href='javascript:popUp(\"{$snort_www_host}/snort_rule.php?sid={$evt[5]}\");'>{$evt[4]}:{$evt[5]}</a>" : "{$evt[4]}:{$evt[5]}");
  unset($evt[5]);
  $file_id = "{$row[0]};{$row[1]};{$evt[6]};{$evt[8]};{$evt[10]}";
  $evt[6] = protocol_name($evt[6]);
  $evt[13] = ($data ? "<a class='action' href='pcap_get.php?plugin=Snort&file_id={$file_id}'>PCAP</a> <a class='action' href='file_layout.php?job_id={$job_id}&ref_no={$ref_no}&search=Snort;{$evt[0]};{$evt[0]};{$evt[7]};{$evt[8]};{$evt[9]};{$evt[10]}&file_id={$file_id}' target='frame_show'>FILE</a> " : "") . "<a class='action' href='javascript:void(0);' onclick='sngJob(this.parentNode.parentNode);'>JOB</a>";
  $evt[7] = "<a class='action' href='javascript:popUp(\"host_show.php?host_ip={$evt[7]}\");'>{$evt[7]}</a>";
  $evt[9] = "<a class='action' href='javascript:popUp(\"host_show.php?host_ip={$evt[9]}\");'>{$evt[9]}</a>";
  foreach ($evt as &$cell) echo "<td>{$cell}</td>";
  echo "</tr>";
}
mysqli_free_result($result);
echo "</table>";

mysqli_close($link);

?>
