/* objects.h - 26 May 16
   PacketZero - 3D Network Monitor
   Copyright 2006-2016 Del Castle  */

#include <math.h>

#include "glob.h"
#include "llist-m.h"
#include "record.h"

//SDL_Keycode
#define GL_KEY_ENTER   13
#define GL_KEY_ESC     27
#define GL_KEY_CTRL    512
#define GL_KEY_F1      1073741882
#define GL_KEY_F2      1073741883
#define GL_KEY_F3      1073741884
#define GL_KEY_F4      1073741885
#define GL_KEY_F5      1073741886
#define GL_KEY_F6      1073741887
#define GL_KEY_F7      1073741888
#define GL_KEY_F8      1073741889
#define GL_KEY_INSERT  1073741897
#define GL_KEY_HOME    1073741898
#define GL_KEY_PAGEUP  1073741899
#define GL_KEY_END     1073741901
#define GL_KEY_PAGEDN  1073741902
#define GL_KEY_DOWN    1073741905
#define GL_KEY_UP      1073741906
#define GL_KEY_LCTRL   1073742048
#define GL_KEY_LSHIFT  1073742049
#define GL_KEY_RCTRL   1073742052
#define GL_KEY_RSHIFT  1073742053

//result id
#define GUI_0NL_OPEN         0x01  //open network layout file
#define GUI_0NL_SAVE         0x02  //save network layout file
#define GUI_0PT_OPEN         0x03  //open packet traffic file
#define GUI_0PT_SAVE         0x04  //save packet traffic file
#define GUI_EDIT_HOSTNAME    0x05
#define GUI_EDIT_REMARKS     0x06  //edit host remarks
#define GUI_FIND_HOSTS       0x07
#define GUI_INFO_HOST        0x08
#define GUI_INFO_SELECTION   0x09
#define GUI_MAKE_HOST        0x0A
#define GUI_PACKET_PORT      0x0B  //show packets for port
#define GUI_PACKET_PROTOCOL  0x0C  //show packets for protocol
#define GUI_SELECT_INACTIVE  0x0D
#define GUI_SENSOR_START     0x0E  //start local sensor
#define GUI_SENSOR_STOP      0x0F  //stop local sensor
#define GUI_SET_COMMANDS     0x10
#define GUI_SET_EXPORT_CSV   0x11
#define GUI_SET_NETPOS       0x12
#define GUI_SET_PREFERENCES  0x13

const int HOST_SPACE = 32, ROW_HOSTS = 20, HOST_SERVICES = 32;  //host spacing, hosts per row, services per host
const double MOVE_SIZE = 3.0, RADIANS = M_PI / 180.0, CLIP_TOP = tan(22.5 * RADIANS), CLIP_FAR = 8192.0;  //movement size, radians in a degree, perseptive depth
const char txtText[3][8] = {"IP", "IP/Name", "Name"}, txtLabel[3][10] = {"Off", "Selection", "All"}, txtActive[5][8] = {"Off", "Alert", "IP/Name", "Host", "Select"}
  , txtColor[10][8] = {"default", "orange", "yellow", "fluro", "green", "mint", "aqua", "blue", "purple", "violet"};
const unsigned char GUI_GFX[17][8] =
{
  { 31,  31,  31,  15,  15,   7,   3,   0},  //posse body 1
  {248, 248, 248, 240, 240, 224, 192,   0},  //posse body 2
  { 15,   7,   3,   3,   7,  15,  15,  31},  //posse body 3
  {240, 224, 192, 192, 224, 240, 240, 248},  //posse body 4
  {111, 239, 239, 239, 255, 255, 127, 127},  //posse body 5
  {246, 247, 247, 247, 255, 255, 254, 254},  //posse body 6
  { 47,  47,  47,  47,  47, 111, 111, 111},  //posse body 7
  {244, 244, 244, 244, 244, 246, 246, 246},  //posse body 8
  { 32,  32,  32,  16,  16,   8,   4,   3},  //posse edge 1
  {  4,   4,   4,   8,   8,  16,  32, 192},  //posse edge 2
  {112,   8,   4,   4,   8,  16,  16,  32},  //posse edge 3
  { 14,  16,  32,  32,  16,   8,   8,   4},  //posse edge 4
  { 72, 136, 136, 136, 128, 128,  64,  64},  //posse edge 5
  { 18,  17,  17,  17,   1,   1,   2,   2},  //posse edge 6
  { 80,  80,  80,  80,  80, 144, 144, 144},  //posse edge 7
  { 10,  10,  10,  10,  10,   9,   9,   9},  //posse edge 8
  {255, 255, 255, 255, 255, 255, 255, 255}   //box
};

enum label_text { Text_IP, Text_Both, Text_Name };  //IP, IP/name, name only
enum host_label { Label_Off, Label_Selection, Label_All };  //show IP/name
enum host_active { Active_Nothing, Active_Alert, Active_Label, Active_Show, Active_Select };  //on-active
enum alert_kind { Alert_Label, Alert_Active, Alert_Anomaly };

struct obj_prefs  //packet0 preferences
{
  char Version[5];
  bool Anomaly, AnomDetect, Broadcasts, DstHosts, FastPackets  //anomaly detection, add destination hosts
    , NewLinks, NewPackets, OSD, PortText, SensorPromisc;  //new host show links/packets, show packet destination port, start sensor promiscuous mode
  unsigned char ShowSensor, ShowProtocol;  //show packets from sensor (0 for all), show packets by protocol (0 for all)
  unsigned short ShowPort, SensorPort;  //show packets by port (0 for all), visibility duration
  int WinX, WinY, WinWidth, WinHeight, Font;
  char Clipboard[256], Commands[4][256], SensorStart[256], SensorInfile[256], SensorId[4], SensorStop[256];  //start/stop local sensor
  label_text LabelText;
  host_label HostLabel;
  host_active HostActive;
  view_spot ViewSpot[5];
};

struct obj_host  //host object
{
  unsigned char Color, LastSensor, Visible  //visibility duration
    , Active:1, Anomaly:1, AutoLink:1, Label:1, Lock:1, Packets:1, Ready:1, Selected:1;  //show IP/name, show packets
  int X, Y, Z;
  unsigned long long Downloads, Uploads;
  time_t LastPacket;
  obj_host *Cluster;
  in_addr HostIP;
  char HostMAC[18], Hostname[256], Remarks[256];
  int Services[HOST_SERVICES];
};

class Objects
{
  private:
    struct obj_packet  //packet object
    {
      unsigned char Protocol;
      unsigned short DstPort, Frame;
      double X, Y, Z;  //current position
      obj_host *DstHost;
    };
    struct obj_alert  //alert object
    {
      alert_kind Kind;
      unsigned char Protocol;
      unsigned short Duration, Frame;  //size/duration
      obj_host *Host;
    };
    struct obj_link  //link object
    {
      obj_host *SrcHost, *DstHost;
      unsigned char Spare;  //spare (future use)
    };
    struct net_pos
    {
      int X, Y, Z;  //net position
      char Color, Net[19];  //CIDR net
    };
    size_t szHost, szPacket, szAlert, szLink, szNetPos;
    unsigned short newFrame;  //new objects drawing cutoff
    LinkedList PacketsLL, AlertsLL, LinksLL, NetPosLL;
    GLob obj3D;  //3D GL objects
    void CreateAlert(alert_kind kind, obj_host *host, unsigned char protocol);
    void DrawHosts(bool animate, obj_prefs *prefs);
    void DrawPackets(bool animate, obj_prefs *prefs);
    void DrawAlerts(bool animate, bool name);
    void DrawLinks(bool show);
    obj_host *CheckHost(unsigned char ptr, const obj_host *host, int x, int y, int z);
    void DestroyHosts();
    void DestroyNetPos();
  public:
    Objects();
    ~Objects();
    obj_host *SelectedHost, *LinkHost;  //link line host
    LinkedList HostsLL;
    unsigned int Packets();
    unsigned int Alerts();
    obj_host *GetHost(unsigned char ptr, in_addr ip, bool add, const obj_prefs *prefs);
    void CreatePacket(const packet_info *packet, obj_host *srchost, obj_host *dsthost, bool link, const obj_prefs *prefs);
    void CreateLink(unsigned char ptr, obj_host *srchost, obj_host *dsthost, unsigned char spare);
    void DeleteLink(const obj_host *host);
    void Draw(bool animate, bool second, obj_prefs *prefs);
    void DrawPick(bool single, bool visible);
    void BlankHost(unsigned char ptr, obj_host *host, int hostspace, int rowhosts);
    void DetectCluster(unsigned char ptr, obj_host *host);
    void SetHosts(int id, unsigned char val, bool show = false);
    void InfoSelected(char *buffer);
    void InfoHost(char *buffer);
    void InfoSelection();
    void InfoGeneral();
    void TabHost(char *buffer, bool ctrl);
    void AddService(obj_host *host, int service, bool anomdetect);
    void SaveLinks(FILE *file);
    void LoadNet(const char *filename);
    void SaveNet(const char *filename);
    void LoadNetPos(const char *filename);
    in_addr_t IsBroadcast(in_addr ip);
    int NetHost(unsigned char ptr, obj_host *host);
    void DestroyPackets(const obj_host *host = 0);
    void DestroyAlerts(const obj_host *host = 0);
    void DestroyLinks(const obj_host *host = 0);
    void DestroyAll();
};
