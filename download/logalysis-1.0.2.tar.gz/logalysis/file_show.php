<html>
<head>
<meta name='copyright' content='2012-2016 Del Castle' />
<meta charset='UTF-8' />
<meta http-equiv='content-type' content='text/html' />
<link rel='stylesheet' type='text/css' href='fx/css/logalysis.css' />

<script type='text/javascript' src='fx/js/logalysis.js'></script>

</head>
<body>

<?php

include "common.php";
session_start();
/*if (isset($_SESSION["las_last_activity"]) && ((time() - $_SESSION["las_last_activity"]) > 3600))
{
  session_unset();
  session_destroy();
} 
$_SESSION["las_last_activity"] = time();*/
if (empty($_SESSION["las_login_user_name"])) exit($login_bounce);

$job_id = $_GET["job_id"];
$ref_no = $_GET["ref_no"];
$file_name = $_GET["file_name"];
$action = (isset($_GET["action"]) ? $_GET["action"] : "");

if (strstr($file_name, "../") || strstr($action, "../")) exit(0);
echo "<div class='menu'>";
if (substr($file_name, strlen($file_name) - 5, 5) == ".pcap")  echo "<a class='menu' style='color:#FFFFFE' onmouseover='visState(\"dvsTl\", 1);'>TOOLS</a>";
echo "<a class='menu' href='{$file_name}'>DOWNLOAD</a>";
if (file_exists("{$file_name}...info"))
{
  $contents = file_get_contents("{$file_name}...info");
  $plugin = preg_replace("/[^!]+SOURCE:\s+(.+)[^!]+/", "$1", $contents, 1, $count);
  if (!$count) $plugin = "";
  $start_time = preg_replace("/[^!]+START:\s+(.+)[^!]+/", "$1", $contents, 1, $count);
  if (!$count) $start_time = preg_replace("/[^!]+EVENT:\s+(.+)[^!]+/", "$1", $contents, 1, $count);
  if (!$count) $start_time = "";
  $finish_time = preg_replace("/[^!]+FINISH:\s+(.+)[^!]+/", "$1", $contents, 1, $count);
  if (!$count) $finish_time = $start_time;
  $ip_1 = preg_replace("/[^!]+IP 1:\s+(.+)[^!]+/", "$1", $contents, 1, $count);
  if (!$count) $ip_1 = "";
  $port_1 = preg_replace("/[^!]+PORT 1:\s+(.+)[^!]+/", "$1", $contents, 1, $count);
  if (!$count) $port_1 = "";
  $ip_2 = preg_replace("/[^!]+IP 2:\s+(.+)[^!]+/", "$1", $contents, 1, $count);
  if (!$count) $ip_2 = "";
  $port_2 = preg_replace("/[^!]+PORT 2:\s+(.+)[^!]+/", "$1", $contents, 1, $count);
  if (!$count) $port_2 = "";
  echo "<a class='menu' href='file_search.php?job_id={$job_id}&ref_no={$ref_no}&search=" . urlencode("{$plugin};{$start_time};{$finish_time};{$ip_1};{$port_1};{$ip_2};{$port_2}") . "' target='frame_file_search'>REGENERATE</a>";
}
echo "<a id='ancPw' class='menu' style='color:#FF9999; visibility:hidden'>PLEASE WAIT...</a>";
echo "<a class='menu' style='color:#FFFFFE; float:right'>" . basename($file_name) . "</a>";
echo "</div><br />";

if ($action || !file_exists($file_name))
{
  if ($action)
  {
    if (file_exists("{$file_name}...lock") && ((time() - filemtime("{$file_name}...lock")) <= 600)) echo("<h5>FILE IN USE BY OTHER USER!</h5>");
    else
    {
      touch("{$file_name}...lock");
      exec("plugins/pcap/{$action}.pcap.sh \"{$file_name}\"");
      unlink("{$file_name}...lock");
    }
  }
  
  echo "<script type='text/javascript'>parent.frame_file_list.location.href = \"file_list.php?job_id={$job_id}&ref_no={$ref_no}&etr_path=" . urlencode($file_name) . "\";</script>";
}

echo "<pre>";
if (isset($contents)) echo $contents;
echo "TYPE:     " . shell_exec("file -b \"{$file_name}\"");
echo "SIZE:     " . format_bytes(filesize($file_name));
echo "\nMD5SUM:   " . md5_file($file_name);
echo "\nSHA1SUM:  " . sha1_file($file_name);
if (substr($file_name, strlen($file_name) - 5, 5) == ".pcap") echo "\nSESSIONS: " . shell_exec("tshark -r \"{$file_name}\" -nqz conv,tcp | grep -P \"^\d\" | wc -l");
else if (substr($file_name, strlen($file_name) - 5, 5) == ".dump") echo "\n\n" . shell_exec("hexdump -C \"{$file_name}\"");
echo "</pre>";

if (substr($file_name, strlen($file_name) - 5, 5) == ".pcap")
{
  echo "<div id='dvsTl' style='visibility:hidden' onmouseover='visState(\"dvsTl\", 1);' onmouseout='visState(\"dvsTl\", 0);'>";
  echo "<div class='menu' style='width:auto'><a class='menu' style='color:#FFFFFE'>TOOLS</a></div>";
  $count = 0;
  $pcap_plugins = scandir("plugins/pcap");
  foreach ($pcap_plugins as &$row)
  {
    if (strstr($row, ".pcap.sh"))
    {
      $row = preg_replace("/^(.+)\.pcap\.sh$/", "$1", $row);
      echo "<div class='menu' style='top:". (++$count * 20) . "px'><a class='menu' href='file_show.php?job_id={$job_id}&ref_no={$ref_no}&file_name=" . urlencode($file_name) . "&action={$row}' onclick='visState(\"ancPw\", 1);'>" . strtoupper($row) . "</a></div>";
    }
  }
  echo "</div>";
}

?>

</body>
</html>
