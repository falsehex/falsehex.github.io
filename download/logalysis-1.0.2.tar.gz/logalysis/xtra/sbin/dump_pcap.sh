#!/bin/bash
# Version 1.0
# Copyright 2012-2016 Del Castle

for CNT in {0..365}
do
  DATE=`date -d "${CNT} days" +"%Y/%m/%d"`
  if [ ! -d "/var/log/pcaps/${DATE}" ]; then
    mkdir -p "/var/log/pcaps/${DATE}"
  fi
done
sleep `expr 300 - \( \`date +"%s"\` % 300 \)`
while true; do
  tcpdump -i eth0 -w "/var/log/pcaps/%Y/%m/%d/%Y-%m-%d_%H:%M:00.pcap" -G `expr 300 - \( \`date +"%s"\` % 300 \)` -W 1 2> /dev/null
done
