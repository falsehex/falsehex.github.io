<html>
<head>
<meta name='copyright' content='2012-2016 Del Castle' />
<meta charset='UTF-8' />
<meta http-equiv='content-type' content='text/html' />
<link rel='stylesheet' type='text/css' href='fx/css/logalysis.css' />

<script type='text/javascript' src='fx/js/chart_gfx.js'></script>

</head>
<body>

<?php

include "common.php";
session_start();
/*if (isset($_SESSION["las_last_activity"]) && ((time() - $_SESSION["las_last_activity"]) > 3600))
{
  session_unset();
  session_destroy();
} 
$_SESSION["las_last_activity"] = time();*/
if (empty($_SESSION["las_login_user_name"])) exit($login_bounce);
date_default_timezone_set("UTC");

$limit = (isset($_POST["limit"]) && is_numeric($_POST["limit"]) ? $_POST["limit"] : 10);
$start_time = (isset($_POST["start_time"]) ? $_POST["start_time"] : "");
$finish_time = (isset($_POST["finish_time"]) ? $_POST["finish_time"] : "");

include "plugins/chart/{$_POST["plugin"]}.generate_chart.php";

?>

</body>
</html>
