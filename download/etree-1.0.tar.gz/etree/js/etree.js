/* etree.js - Version 1.0  26 Mar 14
   eTree - HTML Tree Menu
   Copyright 2012-2014 Del Castle

   Include: "<link rel='stylesheet' type='text/css' href='css/etree.css' />"
            "<script type='text/javascript' src='js/etree.js'></script>"
   Example: var atree = new eTree("atree");
            atree.add(0, -1, true, "folder", "TOP", "page1.html", "_blank");
            atree.add(1, 0, false, "folder", "SUB 1", "page2.html", "_blank");
            atree.add(2, 1, false, "user", "USER", "page3.html", "_blank");
            atree.add(3, 0, false, "folder", "SUB 2", "page4.html", "_blank");
            atree.write();
   Add format: add(id, pid, open, img, text, link, target, tip)
               id - item number
               pid - parent item number (-1 for no parent)
               open - expand folder
               img - image file (.png appended)
               text - label
               link - url to open on click
               target - where to open the link
               tip - tooltip
*/

var imgPath = "img/";

function createNode(pid, open, img, text, link, target, tip)
{
  this.pid = pid;
  this.open = open;
  this.img = img;
  this.text = text;
  this.link = link;
  this.target = target;
  this.tip = tip;
}

function addNode(id, pid, open, img, text, link, target, tip)
{
  this.nodes.push(new createNode(pid, open, img, text, link, target, tip));
}

function getNode(base)
{
  var sid = this.selected;
  if (sid == -1) return "";
  if (base || (this.nodes[sid].pid == -1)) return this.nodes[sid].text;
  var strPath = "";
  while (sid > 0)
  {
    strPath = this.nodes[sid].text + (strPath ? "/" : "") + strPath;
    sid = this.nodes[sid].pid;
  }
  return strPath;
}

function selectNode(id)
{
  if (this.selected != -1) document.getElementById("a" + this.selected).style.backgroundColor = "";
  document.getElementById("a" + id).style.backgroundColor = "lavender";
  this.selected = id;
}

function padNode(id, pad, end)
{
  if (pad.length)
  {
    pad[pad.length - 1] = (id == end ? "end" : "join");
    for (var cnt in pad) document.write("<img src='" + imgPath + pad[cnt] + ".png' />");
    if (id == end) pad[pad.length - 1] = null;
  }
}

function linkNode(id, nodes, tree)
{
  document.write("<span>");
  if (nodes[id].link)
  {
    document.write("<a id='a" + id + "' href='" + nodes[id].link + "'");
    if (nodes[id].target) document.write(" target='" + nodes[id].target + "'");
    if (nodes[id].tip) document.write(" title='" + nodes[id].tip + "'");
    document.write(" onclick='" + tree + ".select(" + id + ");'>");
  }
  document.write(nodes[id].text + (nodes[id].link ? "</a>" : "") + "</span>");
}

function lastChild(id, nodes)
{
  var last = 0;
  for (var cnt = (id + 1); cnt < nodes.length; cnt++)
  {
    if (nodes[cnt].pid == id) last = cnt;
  }
  return last;
}

function writeNode(pid, nodes, tree, pad, end, pend)
{
  if (pid != -1)
  {
    document.write("<div>");
    padNode(pid, pad, pend);
    if (pad.length) pad[pad.length - 1] = (pad[pad.length - 1] ? "line" : "blank");
    document.write("<img id='img" + pid + "' src='" + imgPath + (nodes[pid].open ? "open" : "closed") + ".png' onclick='showFolder(" + pid + ");' />");
    linkNode(pid, nodes, tree);
    document.write("</div>");
    pad.push("");
    document.write("<div id='" + pid + "' style='display:" + (nodes[pid].open ? "block" : "none") + "'>");
  }
  var last;
  for (var cnt = (pid + 1); cnt < nodes.length; cnt++)
  {
    if (nodes[cnt].pid == pid)
    {
      if ((last = lastChild(cnt, nodes))) writeNode(cnt, nodes, tree, pad, last, end);
      else
      {
        padNode(cnt, pad, end);
        document.write("<img src='" + imgPath + nodes[cnt].img + ".png' />");
        linkNode(cnt, nodes, tree);
        document.write("<br />");
      }
    }
  }
  if (pid != -1)
  {
    document.write("</div>");
    pad.pop();
  }
}

function writeTree()
{
  var pad = [];
  document.write("<div class='etree'>");
  writeNode(-1, this.nodes, this.tree, pad, 0, 0);
  document.write("</div>");
}

function eTree(tree)
{
  this.tree = tree;
  this.nodes = [];
  this.selected = -1;
  this.add = addNode;
  this.get = getNode;
  this.select = selectNode;
  this.write = writeTree;
}

function showFolder(id)
{
  var styFolder = document.getElementById(id).style;
  document.getElementById("img" + id).src = imgPath + (styFolder.display == "none" ? "open" : "closed") + ".png";
  styFolder.display = (styFolder.display == "none" ? "block" : "none");
}
