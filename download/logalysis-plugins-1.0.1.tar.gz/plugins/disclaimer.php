<?php

echo "<pre>

MOZILLA FIREFOX AND GOOGLE CHROME SUPPORT ONLY

</pre>";

?>
