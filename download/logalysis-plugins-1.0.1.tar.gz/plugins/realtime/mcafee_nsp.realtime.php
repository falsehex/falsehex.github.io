<?php

include "plugins/misc/mcafee_nsp.php";
include "plugins/cred/mcafee_nsp.cred.php";

$link = mysqli_connect($mcafee_nsp_db_host, $mcafee_nsp_db_user, $mcafee_nsp_db_pass, $mcafee_nsp_db_name);
if ($link)
{
  if ($ackn == "mcafee_nsp")
  {
    $part = explode(";", $_GET["file_id"]);
    mysqli_query($link, "UPDATE iv_alert SET state = {$part[4]}, lastModTime = UTC_TIMESTAMP(), lastModUserRef = 'user', assignedUserRef = 'user' WHERE state = {$part[3]} AND attackIdRef = '{$part[0]}'" . ($part[1] ? " AND sourceIPAddr = '{$part[1]}'" : "") . " AND UNIX_TIMESTAMP(creationTime) <= {$part[2]}");
    if (mysqli_affected_rows($link))
    {
      $part[1] = long2ip(hexdec($part[1]));
      file_put_contents("/var/log/logalysis/ack.log", time() . " \"{$_SESSION["las_login_user_name"]}\" " . ($part[4] == 10 ? "ACK" : ($part[4] == 2 ? "CHK" : "UCK")) . " \"MCAFEE NSP\" \"{$part[0]}\" \"{$part[1]}\" {$part[2]} {$part[5]}\n", FILE_APPEND);
    }
  }

  if (!$ackn)
  {
    $result = mysqli_query($link, "SELECT creationTime, severity, resultSetValue, detectionMechanism, sensorId, attackIdRef, networkProtocolId, sourceIPAddr, INET_NTOA(CONV(sourceIPAddr, 16, 10)), sourcePort, INET_NTOA(CONV(targetIPAddr, 16, 10)), targetPort, categoryId, uuid, packetLogId, direction, alertDuration, COUNT(1), state FROM iv_alert WHERE state != 10 GROUP BY alertDuration, attackIdRef, sourceIPAddr, state ORDER BY severity DESC, attackIdRef LIMIT 20");
    while ($row = mysqli_fetch_row($result))
    {
      if ($row[16] != 0)
      {
        mysqli_query($link, "UPDATE iv_alert SET state = 10, lastModTime = UTC_TIMESTAMP(), lastModUserRef = 'user', assignedUserRef = 'user' WHERE state = 1 AND alertDuration != 0 AND attackIdRef = '{$row[5]}' AND sourceIPAddr = '{$row[7]}'");
        continue;
      }
      $label = db_result($link, "SELECT name FROM iv_attack WHERE id = '{$row[5]}'");
      //$mn_rs = db_result($link, "SELECT displayableName FROM iv_result_set WHERE resultSetValue = {$row[2]}");
      //$row[3] = db_result($link, "SELECT displayableName FROM iv_detection WHERE detectionMechanism = {$row[3]}");
      $row[4] = db_result($link, "SELECT name FROM iv_sensor WHERE sensor_id = {$row[4]}");
      //$row[12] = db_result($link, "SELECT displayableName FROM iv_categories WHERE categoryId = {$row[12]}");
      $file_id = "{$row[5]};{$row[7]};" . time() . ";{$row[18]}";
      $row[14] = ($row[14] ? "<a class='action' href='pcap_get.php?plugin=McAfee_NSP_RT&file_id={$file_id}'>PCAP</a> <a class='action' href='file_layout.php?job_id=1&ref_no=SCRATCHPAD&search=McAfee_NSP_RT;{$row[0]};{$row[0]};{$row[8]};{$row[9]};{$row[10]};{$row[11]}&file_id={$file_id}' target='frame_show'>FILE</a>" : "");
      $url = "realtime_show.php?ackn=mcafee_nsp&file_id={$file_id}";
      $priority = mcafee_nsp_priority($row[1], TRUE, ($row[18] == 2));
      echo "<tr onclick='txtBold(this.style);'>";
      echo "<td style='background:" . priority_color($priority) . "'><a class='action' href='javascript:void(0);' ondblclick='if (ackAlert(\"{$url};" . ($row[18] == 2 ? 1 : 2) . ";\" + cntRt)) setPriority(this);'>{$priority}</a></td>";
      echo "<td>{$row[0]}</td>";
      echo "<td" . ($row[2] < 777 ? " style='background:red'" : "") . "><a class='action' href='{$mcafee_nsp_www_host}' target='_blank'>McAfee NSP</a></td>";
      echo "<td title='Detect: {$mcafee_nsp_detection[$row[3]]}\nCat: {$mcafee_nsp_category[$row[12]]}\nResult: {$mcafee_nsp_result[$row[2]]}\nProto: " . protocol_name($row[6]) . "\nSrc: {$row[8]}:{$row[9]}\nDst: {$row[10]}:{$row[11]}\nDir: {$mcafee_nsp_direction[$row[15]]}'>{$label} <a class='action' href='javascript:popUp(\"{$mcafee_nsp_www_host}/intruvert/attackEncyclopedia/en/docs/{$row[5]}.html\");'>{$row[5]}</a></td>";
      echo "<td><a class='action' href='javascript:popUp(\"host_show.php?host_ip={$row[8]}\");'>{$row[8]}</a></td>";
      echo "<td>{$row[17]}</td>";
      echo "<td><a class='action' href='javascript:void(0);' ondblclick='if (ackAlert(\"{$url};10;\" + cntRt)) this.parentNode.parentNode.style.display = \"none\";'>ACK</a> {$row[14]} ";
      echo "<a class='action' href='javascript:void(0);' ondblclick='location.href = \"details_show.php?details=\" + cntRt + \"" . urlencode(";0;1;4;0;{$row[4]}:{$mcafee_nsp_direction[$row[15]][0]};McAfee NSP Alert: " . strtr($label, "'", "\"") . ";Detection: {$mcafee_nsp_detection[$row[3]]}\nAID: {$row[5]}\nCategory: {$mcafee_nsp_category[$row[12]]}\nResult: {$mcafee_nsp_result[$row[2]]};;;;;{$row[0]};{$row[6]};{$row[8]};{$row[9]};{$row[10]};{$row[11]}") . "\"'>JOB</a></td></tr>";
      $count++;
    }
    $total = db_result($link, "SELECT COUNT(1) FROM iv_alert WHERE state = 1");
    if ($total > 50) echo "<tr><td style='background:red'>0 E</td><td></td><td>McAfee NSP</td><td>MCAFEE NSP ALERTS > 50</td><td></td><td>{$total}</td><td></td></tr>";
  }

  mysqli_close($link);
}
else echo "<tr><td style='background:red'>0 E</td><td></td><td>McAfee NSP</td><td>ERROR: MYSQL DB {$mcafee_nsp_db_name} CONNECT FAILED</td><td></td><td></td><td></td></tr>"; 

?>
