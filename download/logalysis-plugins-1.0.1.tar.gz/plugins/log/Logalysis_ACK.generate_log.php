<?php

if (empty($nohdr)) echo "<h4>LOGALYSIS ACK</h4>";
echo "<table class='esort'>";
echo "<tr><th></th><th>Time</th><th>User</th><th>ACU</th><th>Type</th><th>Alert</th><th>Source</th><th><=</th><th>Spent</th></tr>";
$count = 0;
$logalysis_logs = scandir("/var/log/logalysis");
natsort($logalysis_logs);
$logalysis_logs = array_reverse($logalysis_logs);
foreach ($logalysis_logs as &$file)
{
  if (preg_match("/^ack\.log/", $file))
  {
    $ack_log = gzopen("/var/log/logalysis/{$file}", "r");
    while ($line = gzgets($ack_log, 4096))
    {
      $row = preg_split("/\s\"([^\"]*)\"|\s/", $line, -1, PREG_SPLIT_NO_EMPTY | PREG_SPLIT_DELIM_CAPTURE);
      $process = TRUE;
      if ($start_time && ($row[0] < strtotime($start_time))) $process = FALSE;
      if ($process && $finish_time && ($row[0] > strtotime($finish_time))) $process = FALSE;
      if ($process && $char_1_64 && ($row[1] != $char_1_64)) $process = FALSE;
      if ($process && $char_2_64 && !stristr($row[3], $char_2_64)) $process = FALSE;
      if ($process && $char_3_255 && !stristr($row[4], $char_3_255)) $process = FALSE;
      if ($process && $char_4_255 && !stristr($row[5], $char_4_255)) $process = FALSE;
      if ($process)
      {
        $row[0] = date("Y-m-d H:i:s", $row[0]);
        $row[6] = date("Y-m-d H:i:s", $row[6]);
        $row[7] = date("z\D G\H i\M s\S", $row[7]);
        echo "<tr onclick='txtBold(this.style);'><td>" . ++$count . "</td>";
        foreach ($row as &$cell) echo "<td>{$cell}</td>";
        echo "</tr>";
        if ($count == $limit) break;
      }
    }
    gzclose($ack_log);
    if ($count == $limit) break;
  }
}
echo "</table>";

?>
