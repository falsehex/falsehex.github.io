<?php

include "plugins/cred/sourcefire.cred.php";

$link = mysqli_connect($sourcefire_db_host, $sourcefire_db_user, $sourcefire_db_pass, $sourcefire_db_name);
if (!$link) die("Error: mysql db {$sourcefire_db_name} connect failed");

if (!isset($ip_or)) $ip_or = (isset($_GET["ip_or"]) ? $_GET["ip_or"] : "");

if (empty($nohdr)) echo "<h4>SOURCEFIRE RNA</h4>";
echo "<table class='esort'>";
echo "<tr><th></th><th>First</th><th>Last</th><th>Protocol</th><th>Source IP</th><th>Port</th><th>Target IP</th><th>Port</th><th>Packets TX</th><th>Packets RX</th><th>Bytes TX</th><th>Bytes RX</th><th>Application</th><th>Version</th><th>Service</th></tr>";
$count = 0;
$extra = ($start_time ? " WHERE first_packet >= UNIX_TIMESTAMP('{$start_time}')" : "");
if ($finish_time) $extra .= ($extra ? " AND" : " WHERE") . " last_packet <= UNIX_TIMESTAMP('{$finish_time}')";
if ($source_ip)
{
  if ($ip_or)
  {
    if (substr_count($source_ip, ".") == 3) $extra .= ($extra ? " AND" : " WHERE") . " (INET_NTOA(initiator) = '{$source_ip}' OR INET_NTOA(responder) = '{$source_ip}')";
    else $extra .= ($extra ? " AND" : " WHERE") . " (INET_NTOA(initiator) LIKE '{$source_ip}%' OR INET_NTOA(responder) LIKE '{$source_ip}%')";
  }
  else
  {
    if (substr_count($source_ip, ".") == 3) $extra .= ($extra ? " AND" : " WHERE") . " INET_NTOA(initiator) = '{$source_ip}'";
    else $extra .= ($extra ? " AND" : " WHERE") . " INET_NTOA(initiator) LIKE '{$source_ip}%'";
  }
}
if ($source_port) $extra .= ($extra ? " AND" : " WHERE") . " initiator_port = {$source_port}";
if ($target_ip)
{
  if (substr_count($target_ip, ".") == 3) $extra .= ($extra ? " AND" : " WHERE") . " INET_NTOA(responder) = '{$target_ip}'";
  else $extra .= ($extra ? " AND" : " WHERE") . " INET_NTOA(responder) LIKE '{$target_ip}%'";
}
if ($target_port) $extra .= ($extra ? " AND" : " WHERE") . " responder_port = {$target_port}";
$result = mysqli_query($link, "SELECT FROM_UNIXTIME(first_packet), FROM_UNIXTIME(last_packet), protocol, INET_NTOA(initiator), initiator_port, INET_NTOA(responder), responder_port, packets_sent, packets_recv, bytes_sent, bytes_recv, clnt_app_fp_id, version, service_id FROM rna_flow_stats{$extra} ORDER BY first_packet LIMIT {$limit}");
while ($row = mysqli_fetch_row($result))
{
  $row[11] = db_result($link, "SELECT product_str FROM rna_client_application_fingerprint_str WHERE clnt_app_fp_id = {$row[11]}");
  $row[13] = db_result($link, "SELECT service_name FROM rna_service_list WHERE service_id = {$row[13]}");
  if ($action) $save[] = array($row[0], $row[1], $row[7], $row[8], $row[9], $row[10], NULL, NULL, NULL, $row[11], $row[12], $row[13], NULL, $row[2], $row[3], $row[4], $row[5], $row[6], NULL);
  echo "<tr onclick='txtBold(this.style);'><td>" . ++$count . "</td>";
  $row[2] = protocol_name($row[2]);
  $row[3] = "<a class='action' href='javascript:popUp(\"host_show.php?host_ip={$row[3]}\");'>{$row[3]}</a>";
  $row[5] = "<a class='action' href='javascript:popUp(\"host_show.php?host_ip={$row[5]}\");'>{$row[5]}</a>";
  $row[9] = format_bytes($row[9]);
  $row[10] = format_bytes($row[10]);
  foreach ($row as &$cell) echo "<td>{$cell}</td>";
  echo "</tr>";
}
mysqli_free_result($result);
echo "</table>";

mysqli_close($link);

?>
