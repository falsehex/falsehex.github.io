<html>
<head>
<meta name='copyright' content='2012-2016 Del Castle' />
<meta charset='UTF-8' />
<meta http-equiv='content-type' content='text/html' />

<?php

$job_id = $_GET["job_id"];
$ref_no = $_GET["ref_no"];

echo "<script type='text/javascript'>top.frame_menu_main.location.href = \"menu_main.php?job_id={$job_id}&ref_no={$ref_no}&action=update\";</script>";

echo "<frameset cols='380,*' border='4px'>";
echo "<frameset rows='240,*'>";
echo "<frame name='frame_file_list' src='file_list.php?job_id={$job_id}&ref_no={$ref_no}' />";
echo "<frame name='frame_file_search' src='file_search.php?job_id={$job_id}&ref_no={$ref_no}" . (isset($_GET["search"]) ? "&search={$_GET["search"]}" : "") . (isset($_GET["file_id"]) ? "&file_id={$_GET["file_id"]}" : "") . "' />";
echo "</frameset>";
echo "<frame name='frame_file_show' src='blank.html' />";
echo "</frameset>";

?>

</head>
</html>
