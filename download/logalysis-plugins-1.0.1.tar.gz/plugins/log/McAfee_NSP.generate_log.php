<?php

include "plugins/misc/mcafee_nsp.php";
include "plugins/cred/mcafee_nsp.cred.php";

$link = mysqli_connect($mcafee_nsp_db_host, $mcafee_nsp_db_user, $mcafee_nsp_db_pass, $mcafee_nsp_db_name);
if (!$link) die("Error: mysql db {$mcafee_nsp_db_name} connect failed");

if (!isset($ip_or)) $ip_or = (isset($_GET["ip_or"]) ? $_GET["ip_or"] : "");

echo "<script type='text/javascript'>";
echo "function textLog() { var aryTd, aryTr = document.getElementsByTagName(\"tr\"), winTl = popUp(\"\"); winTl.document.write(\"<pre>\"); for (var cnt = 0; cnt < aryTr.length; cnt++) { aryTd = aryTr[cnt].getElementsByTagName(\"td\"); if (aryTd[0]) winTl.document.write(aryTd[1].textContent + \"\\t\" + aryTd[6].textContent + \"\\t\" + aryTd[8].textContent + \"\\t\" + aryTd[9].textContent + \"\\t\" + aryTd[10].textContent + \"\\t\" + aryTd[11].textContent + \"\\t\" + aryTd[12].textContent + \"\\n\"); } winTl.document.write(\"</pre>\"); }";
echo "function mngJob(objTr) { aryTd = objTr.getElementsByTagName(\"td\"); parent.location.href = \"details_show.php?details=\" + escape(\"0;0;1;4;{$login_user_id};\" + aryTd[4].textContent + \";McAfee NSP Alert: \" + aryTd[6].textContent.replace(/'/g, \"\\\"\") + \";Detection: \" + aryTd[5].textContent + \"\\nAID: \" + aryTd[7].textContent + \"\\nCategory: \" + aryTd[13].textContent + \"\\nResult: \" + aryTd[3].textContent + \";;;;;\" + aryTd[1].textContent + \";\" + aryTd[8].textContent + \";\" + aryTd[9].textContent + \";\" + aryTd[10].textContent + \";\" + aryTd[11].textContent + \";\" + aryTd[12].textContent); }";
echo "</script>";

if (empty($nohdr)) echo "<h4>MCAFEE NSP</h4>";
echo "<table class='esort'>";
echo "<tr><th></th><th>Time</th><th>Priority</th><th>Result</th><th>Sensor</th><th>Detection</th><th>Alert</th><th>AID</th><th>Protocol</th><th>Source IP</th><th>Port</th><th>Target IP</th><th>Port</th><th>Category</th><th>Subcategory</th><th>EID</th><th>Actions</th></tr>";
$count = 0;
$extra = " WHERE alertDuration = 0";
if ($start_time) $extra .= " AND creationTime >= '{$start_time}'";
if ($finish_time) $extra .= " AND creationTime <= '{$finish_time}'";
if ($source_ip)
{
  if ($ip_or)
  {
    if (substr_count($source_ip, ".") == 3) $extra .= " AND (INET_NTOA(CONV(sourceIPAddr, 16, 10)) = '{$source_ip}' OR INET_NTOA(CONV(targetIPAddr, 16, 10)) = '{$source_ip}')";
    else $extra .= " AND (INET_NTOA(CONV(sourceIPAddr, 16, 10)) LIKE '{$source_ip}%' OR INET_NTOA(CONV(targetIPAddr, 16, 10)) LIKE '{$source_ip}%')";
  }
  else
  {
    if (substr_count($source_ip, ".") == 3) $extra .= " AND INET_NTOA(CONV(sourceIPAddr, 16, 10)) = '{$source_ip}'";
    else $extra .= " AND INET_NTOA(CONV(sourceIPAddr, 16, 10)) LIKE '{$source_ip}%'";
  }
}
if ($source_port) $extra .= " AND sourcePort = {$source_port}";
if ($target_ip)
{
  if (substr_count($target_ip, ".") == 3) $extra .= " AND INET_NTOA(CONV(targetIPAddr, 16, 10)) = '{$target_ip}'";
  else $extra .= " AND INET_NTOA(CONV(targetIPAddr, 16, 10)) LIKE '{$target_ip}%'";
}
if ($target_port) $extra .= " AND targetPort = {$target_port}";
if ($num_2) $extra .= " AND attackIdRef = '{$num_2}'";
if ($num_3) $extra .= " AND uuid = {$num_3}";
$result = mysqli_query($link, "SELECT creationTime, severity, resultSetValue, sensorId, detectionMechanism, direction, attackIdRef, networkProtocolId, INET_NTOA(CONV(sourceIPAddr, 16, 10)), sourcePort, INET_NTOA(CONV(targetIPAddr, 16, 10)), targetPort, categoryId, subCategoryId, uuid, packetLogId FROM iv_alert{$extra} ORDER BY creationTime LIMIT {$limit}");
while ($row = mysqli_fetch_row($result))
{
  $row[2] = $mcafee_nsp_result[$row[2]];
  //$row[2] = db_result($link, "SELECT displayableName FROM iv_result_set WHERE resultSetValue = {$row[2]}");
  $row[3] = db_result($link, "SELECT name FROM iv_sensor WHERE sensor_id = {$row[3]}") . ":{$mcafee_nsp_direction[$row[5]][0]}";
  $row[4] = $mcafee_nsp_detection[$row[4]];
  //$row[4] = db_result($link, "SELECT displayableName FROM iv_detection WHERE detectionMechanism = {$row[4]}");
  $row[5] = db_result($link, "SELECT name FROM iv_attack WHERE id = '{$row[6]}'");
  $row[6] = hexdec($row[6]);
  $row[12] = $mcafee_nsp_category[$row[12]];
  //$row[12] = db_result($link, "SELECT displayableName FROM iv_categories WHERE categoryId = {$row[12]}");
  $row[13] = ($row[13] == 39 ? "Trojan" : db_result($link, "SELECT display_name FROM iv_subcategories WHERE idnum = {$row[13]}"));
  if ($action) $save[] = array($row[0], NULL, $row[1], $row[6], $row[14], $row[15], NULL, $row[2], $row[4], $row[3], $row[5], $row[12], $row[13], $row[7], $row[8], $row[9], $row[10], $row[11], $row[15]);
  echo "<tr onclick='txtBold(this.style);'><td>" . ++$count . "</td>";
  $row[1] = mcafee_nsp_priority($row[1], FALSE, FALSE);
  $row[6] = "0x" . dechex($row[6]);
  $row[6] = "<a class='action' href='javascript:popUp(\"{$mcafee_nsp_www_host}/intruvert/attackEncyclopedia/en/docs/{$row[6]}.html\");'>{$row[6]}</a>";
  $row[7] = protocol_name($row[7]);
  $row[15] = ($row[15] ? "<a class='action' href='pcap_get.php?plugin=McAfee_NSP&file_id={$row[15]}'>PCAP</a> <a class='action' href='file_layout.php?job_id={$job_id}&ref_no={$ref_no}&search=McAfee_NSP;{$row[0]};{$row[0]};{$row[8]};{$row[9]};{$row[10]};{$row[11]}&file_id={$row[15]}' target='frame_show'>FILE</a> " : "") . "<a class='action' href='javascript:void(0);' onclick='mngJob(this.parentNode.parentNode);'>JOB</a>";
  $row[8] = "<a class='action' href='javascript:popUp(\"host_show.php?host_ip={$row[8]}\");'>{$row[8]}</a>";
  $row[10] = "<a class='action' href='javascript:popUp(\"host_show.php?host_ip={$row[10]}\");'>{$row[10]}</a>";
  foreach ($row as &$cell) echo "<td>{$cell}</td>";
  echo "</tr>";
}
mysqli_free_result($result);
echo "</table>";

mysqli_close($link);

?>
