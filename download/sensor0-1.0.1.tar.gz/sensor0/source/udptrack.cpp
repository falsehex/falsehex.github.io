/* udptrack.cpp - 01 Sep 15
   PacketZero - 3D Network Monitor
   Copyright 2006-2015 Del Castle  */

#include <string.h>
#include <time.h>

#include "udptrack.h"

const time_t UDP_TIMEOUT = 30;  //UDP stream time-out seconds

UDPTrack::UDPTrack()
{
  szTrack = sizeof(udp_track);
}

//destroy UDP packet tracking LL
void UDPTrack::DestroyTracks()
{
  TracksLL.Start();
  while (TracksLL.Read()) TracksLL.Delete();
}

//UDP packet tracking and identification
udp_kind UDPTrack::Kind(const packet_info *packet)
{
  udp_track *pTrack;
  TracksLL.Start();
  while ((pTrack = (udp_track *)TracksLL.Read()))
  {
    if ((time(0) - pTrack->Timeout) > UDP_TIMEOUT) TracksLL.Delete();
    else if (!memcmp(packet, pTrack, 12))
    {
      time(&pTrack->Timeout);
      return UDP_Stream;
    }
    else if ((packet->SrcIP.s_addr == pTrack->DstIP.s_addr) && (packet->DstIP.s_addr == pTrack->SrcIP.s_addr) && (packet->SrcPort == pTrack->DstPort) && (packet->DstPort == pTrack->SrcPort))
    {
      time(&pTrack->Timeout);
      if (pTrack->Stream) return UDP_Stream;
      pTrack->Stream = true;
      return UDP_Service;
    }
    else TracksLL.Next();
  }
  udp_track oTrack = {packet->SrcIP, packet->DstIP, packet->SrcPort, packet->DstPort, false, time(0)};
  TracksLL.Write(&oTrack, szTrack);
  return UDP_New;
}

UDPTrack::~UDPTrack()
{
  DestroyTracks();
}
