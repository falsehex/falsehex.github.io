<?php

echo "<p><select name='shape' onchange='visState(\"objSv\", (this.value == \"vbar\"));'>";
echo "<option value='vbar'>Vertical Bar</option>";
echo "<option value='pie'>Pie</option>";
echo "</select></p>";
search_time($start_time, $finish_time);
echo "<p id='objSv'><input type='checkbox' name='show_vals' />Show Value on Bar</p>";

?>
