<html>
<head>
<meta name='copyright' content='2012-2016 Del Castle' />
<meta charset='UTF-8' />
<meta http-equiv='content-type' content='text/html' />
<link rel='stylesheet' type='text/css' href='fx/css/logalysis.css' />

<link rel='stylesheet' type='text/css' href='fx/css/etree.css' />
<script type='text/javascript' src='fx/js/etree.js'></script>

<script type='text/javascript' src='fx/js/logalysis.js'></script>

</head>
<body>

<?php

include "common.php";
session_start();
/*if (isset($_SESSION["las_last_activity"]) && ((time() - $_SESSION["las_last_activity"]) > 3600))
{
  session_unset();
  session_destroy();
} 
$_SESSION["las_last_activity"] = time();*/
if (empty($_SESSION["las_login_user_name"])) exit($login_bounce);
$_SESSION["las_menu_tab"] = 3;

function dir_tree($scan_dir, $item, $job, $ref, $find, $path)
{
  global $show_files;

  if (file_exists($scan_dir))
  {
    $parent = $item;
    $files = scandir($scan_dir);
    foreach ($files as &$row)
    {
      if (($row[0] != ".") && !strstr($row, "..."))
      {
        $scan_file = "{$scan_dir}/{$row}";
        if (file_exists("{$scan_file}...lock") && ((time() - filemtime("{$scan_file}...lock")) > 600)) unlink("{$scan_file}...lock");
        if (!$find || stristr($row, $find) || trim(shell_exec("grep -Fcais \"{$find}\" \"{$scan_file}\"")))
        {
          if (in_array(substr($row, strlen($row) - 4, 4), $show_files)) $url = $scan_file;
          else $url = "file_show.php?job_id={$job}&ref_no={$ref}&file_name=" . urlencode($scan_file);
          echo "etrFl.add(" . ++$item . ", {$parent}, " . (in_array($row, $path) ? "true" : "false") . ", \"file\", \"{$row}\", \"{$url}\", \"frame_file_show\");";
        }
        if (!file_exists("{$scan_file}...lock") && file_exists("{$scan_file}...dir")) $item = dir_tree("{$scan_file}...dir", $item, $job, $ref, $find, $path);
      }
    }
  }
  return $item;
}

$job_id = $_GET["job_id"];
$ref_no = $_GET["ref_no"];
$find_file = (isset($_GET["find_file"]) ? $_GET["find_file"] : "");
$etr_path = (isset($_GET["etr_path"]) ? $_GET["etr_path"] : "");
$dest_file = (isset($_GET["dest_file"]) ? $_GET["dest_file"] : "");

if (strstr($ref_no, "../") || strstr($find_file, "../") || strstr($etr_path, "../") || strstr($dest_file, "../")) exit(0);
$root_dir = "files/{$ref_no}";
if ($dest_file)
{
  if ($dest_file == "move.stop") $_SESSION["las_move_file"] = 0;
  else if ($dest_file == "move.this") $_SESSION["las_move_file"] = "{$root_dir}/{$etr_path}";
  else
  {
    if ($dest_file == "move.here")
    {
      $file_name = $_SESSION["las_move_file"];
      $dest_file = basename($file_name);
      $dest_dir = $root_dir;
      if ($etr_path) $dest_dir .= "/{$etr_path}...dir";
      $_SESSION["las_move_file"] = 0;
    }
    else
    {
      $file_name = "{$root_dir}/{$etr_path}";
      $dest_dir = dirname($file_name);
    }
    if (file_exists("{$file_name}...lock") && ((time() - filemtime("{$file_name}...lock")) <= 600)) echo "<script type='text/javascript'>alert(\"File In Use By Other User!\");</script>";
    else
    {
      touch("{$file_name}...lock");
      if (($dest_file == "kill.me") || ($dest_file == "delete.me"))
      {
        if (file_exists("{$file_name}...kill"))
        {
          exec("kill " . file_get_contents("{$file_name}...kill"));
          unlink("{$file_name}...kill");
        }
        if ($dest_file == "delete.me")
        {
          if (file_exists("{$file_name}...dir") && exec("find \"{$file_name}...dir/\" -name \"*...kill\"")) echo "<script type='text/javascript'>alert(\"Running Task In Directory!\");</script>";
          else
          {
            exec("rm -rf \"{$file_name}\"");
            exec("rm -f \"{$file_name}...info\"");
            exec("rm -rf \"{$file_name}...dir\"");
          }
        }
      }
      else if (!file_exists("{$dest_dir}/{$dest_file}"))
      {
        if (!file_exists($dest_dir)) mkdir($dest_dir, 0755);
        rename($file_name, "{$dest_dir}/{$dest_file}");
        if (file_exists("{$file_name}...info")) rename("{$file_name}...info", "{$dest_dir}/{$dest_file}...info");
        if (file_exists("{$file_name}...dir")) rename("{$file_name}...dir", "{$dest_dir}/{$dest_file}...dir");
        $dest_dir = dirname($file_name);
        $dest_file = "delete.me";
      }
      unlink("{$file_name}...lock");
      if (($dest_file == "delete.me") && file_exists($dest_dir) && (count(scandir($dest_dir)) == 2))
      {
        exec("rm -rf \"{$dest_dir}\"");
        $dest_dir = str_replace("...dir", "", $dest_dir, $count);
        if ($count) exec("rm -rf \"{$dest_dir}\"");
      }
    }
  }

  echo "<script type='text/javascript'>parent.frame_file_show.location.href = \"blank.html\";</script>";
}

echo "<div class='menu'>";
if ($_SESSION["las_move_file"])
{
  echo "<a class='menu' href='#' onclick='location.href = \"file_list.php?job_id={$job_id}&ref_no={$ref_no}&etr_path=\" + escape(etrFl.get(false)) + \"&dest_file=move.here\";'>MOVE HERE</a>";
  echo "<a class='menu' href='file_list.php?job_id={$job_id}&ref_no={$ref_no}&dest_file=move.stop'>CANCEL MOVE</a>";
}
else
{
  echo "<a class='menu' style='color:#FFFFFE' onmouseover='if (etrFl.get(true)) visState(\"dvsAn\", 1);'>ACTIONS</a>";
  echo "<a class='menu' href='#' onclick='var strFd = prompt(\"Enter Search Text\", \"{$find_file}\"); if (strFd) location.href = \"file_list.php?job_id={$job_id}&ref_no={$ref_no}&find_file=\" + escape(strFd.toLowerCase());'>SEARCH</a>";
  echo "<a class='menu' href='file_import.php?job_id={$job_id}&ref_no={$ref_no}' target='frame_file_show'>IMPORT</a>";
}
echo "</div><br />";

echo "<script type='text/javascript'>";
echo "var etrFl = new eTree(\"etrFl\");";
echo "etrFl.add(0, -1, true, \"folder\", \"" . ($find_file ? "SEARCH: {$find_file}" : "FILES") . "\", \"blank.html\", \"frame_file_show\");";
if (!$etr_path) $etr_path = $_SESSION["las_login_user_name"];
dir_tree($root_dir, 0, $job_id, $ref_no, $find_file, preg_split("/\/|\.\.\.dir\//", $etr_path));
echo "etrFl.write();";
echo "</script>";

if (!$_SESSION["las_move_file"])
{
  echo "<div id='dvsAn' style='visibility:hidden' onmouseover='visState(\"dvsAn\", 1);' onmouseout='visState(\"dvsAn\", 0);'>";
  echo "<div class='menu' style='width:auto'><a class='menu' style='color:#FFFFFE'>ACTIONS</a></div>";
  echo "<div class='menu' style='top:20px'><a class='menu' href='#' onclick='var strRn = prompt(\"Enter New Name\", etrFl.get(true)); if (strRn) location.href = \"file_list.php?job_id={$job_id}&ref_no={$ref_no}&find_file=" . urlencode($find_file) . "&etr_path=\" + escape(etrFl.get(false)) + \"&dest_file=\" + escape(strRn);'>RENAME</a></div>";
  echo "<div class='menu' style='top:40px'><a class='menu' href='#' onclick='location.href = \"file_list.php?job_id={$job_id}&ref_no={$ref_no}&etr_path=\" + escape(etrFl.get(false)) + \"&dest_file=move.this\";'>MOVE</a></div>";
  echo "<div class='menu' style='top:60px'><a class='menu' href='#' onclick='prompt(\"File Path:\", \"{$ref_no}/\" + etrFl.get(false));'>PATH</a></div>";
  echo "<div class='menu' style='top:80px'><a class='menu' href='#' onclick='if (confirm(\"Confirm Kill Task:\\n\\n\" + etrFl.get(true))) location.href = \"file_list.php?job_id={$job_id}&ref_no={$ref_no}&find_file=" . urlencode($find_file) . "&etr_path=\" + escape(etrFl.get(false)) + \"&dest_file=kill.me\";'>KILL</a></div>";
  echo "<div class='menu' style='top:100px'><a class='menu' href='#' onclick='if (confirm(\"Confirm Delete:\\n\\n\" + etrFl.get(true))) location.href = \"file_list.php?job_id={$job_id}&ref_no={$ref_no}&find_file=" . urlencode($find_file) . "&etr_path=\" + escape(etrFl.get(false)) + \"&dest_file=delete.me\";'>DELETE</a></div>";
  echo "</div>";
}

?>

</body>
</html>
