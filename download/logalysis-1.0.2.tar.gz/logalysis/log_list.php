<html>
<head>
<meta name='copyright' content='2012-2016 Del Castle' />
<meta charset='UTF-8' />
<meta http-equiv='content-type' content='text/html' />
<link rel='stylesheet' type='text/css' href='fx/css/logalysis.css' />

<link rel='stylesheet' type='text/css' href='fx/css/etree.css' />
<script type='text/javascript' src='fx/js/etree.js'></script>

</head>
<body>

<?php

include "common.php";
session_start();
/*if (isset($_SESSION["las_last_activity"]) && ((time() - $_SESSION["las_last_activity"]) > 3600))
{
  session_unset();
  session_destroy();
} 
$_SESSION["las_last_activity"] = time();*/
if (empty($_SESSION["las_login_user_name"])) exit($login_bounce);
$_SESSION["las_menu_tab"] = 2;

$job_id = (is_numeric($_GET["job_id"]) ? $_GET["job_id"] : 0);
$ref_no = $_GET["ref_no"];

$link = logalysis_db_connect();

if (isset($_GET["action"]))
{
  if ($_GET["action"] == "move") mysqli_query($link, "UPDATE logs SET job_id = {$job_id} WHERE log_id = {$_SESSION["las_move_log"]}");
  $_SESSION["las_move_log"] = 0;
}

if ($_SESSION["las_move_log"])
{
  echo "<div class='menu'>";
  echo "<a class='menu' href='log_list.php?job_id={$job_id}&ref_no={$ref_no}&action=move'>MOVE HERE</a>";
  echo "<a class='menu' href='log_list.php?job_id={$job_id}&ref_no={$ref_no}&action=cancel'>CANCEL MOVE</a>";
  echo "</div><br />";
}

echo "<script type='text/javascript'>";
echo "var etrLl = new eTree(\"etrLl\");";
$item = 0;
$count = db_result($link, "SELECT COUNT(1) FROM logs WHERE job_id = {$job_id}");
echo "etrLl.add(0, -1, true, \"folder\", \"LOGS ({$count})\");";
$result = mysqli_query($link, "SELECT save_time, save_user_id, log_id FROM logs WHERE job_id = {$job_id} ORDER BY save_time");
while ($log = mysqli_fetch_row($result)) echo "etrLl.add(" . ++$item . ", 0, false, \"file\", \"{$log[0]} " . get_user_name($link, $log[1]) . "\", \"log_search.php?job_id={$job_id}&ref_no={$ref_no}&log_id={$log[2]}\", \"frame_log_search\");";
mysqli_free_result($result);
echo "etrLl.write();";
echo "</script>";

mysqli_close($link);

?>

</body>
</html>
