<?php

echo "<input type='hidden' name='nosave' value='true' />";
echo "<p>Limit <input type='text' name='limit' size='7' maxlength='5' value='{$limit}' /></p>";
search_time($search[1], $search[2]);
echo "<p><label id='ip_txt'>Source IP</label><br /><input type='text' name='source_ip' size='17' maxlength='15' value='{$search[15]}' />";
echo "<input type='checkbox' name='ip_or' onclick='document.getElementById(\"ip_txt\").textContent = \"Source\" + (this.checked ? \"/Target\" : \"\") + \" IP\";' />OR<br />";
echo "Target IP<br /><input type='text' name='target_ip' size='17' maxlength='15' value='{$search[17]}' /></p>";

?>
