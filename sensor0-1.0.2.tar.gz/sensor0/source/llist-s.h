/* llist-s.h - 01 Sep 15
   Linked List Single
   Copyright 2006-2015 Del Castle  */

class LinkedList
{
  private:
    struct Item
    {
      void *Data;
      Item *Next, *Prev;
      Item(void *data, size_t num, Item *prev);
      ~Item();
    } *pFront, *pBack, *pItem;
    unsigned int cntItems;
  public:
    LinkedList();
    unsigned int Items();
    void *Write(void *data, size_t num);
    void Start();
    void *Read();
    void Next();
    void Delete();
};
