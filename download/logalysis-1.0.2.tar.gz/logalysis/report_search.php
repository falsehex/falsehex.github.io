<html>
<head>
<meta name='copyright' content='2012-2016 Del Castle' />
<meta charset='UTF-8' />
<meta http-equiv='content-type' content='text/html' />
<link rel='stylesheet' type='text/css' href='fx/css/logalysis.css' />

<script type='text/javascript' src='fx/js/edate.js'></script>

<script type='text/javascript' src='fx/js/logalysis.js'></script>

</head>
<body>

<div class='menu'>
  <a class='menu' href='#' onclick='document.forms[0].submit();'>GENERATE REPORT</a>
</div><br />

<?php

include "common.php";
session_start();
/*if (isset($_SESSION["las_last_activity"]) && ((time() - $_SESSION["las_last_activity"]) > 3600))
{
  session_unset();
  session_destroy();
} 
$_SESSION["las_last_activity"] = time();*/
if (empty($_SESSION["las_login_user_name"])) exit($login_bounce);
date_default_timezone_set("UTC");

$plugin = (isset($_GET["plugin"]) ? $_GET["plugin"] : "");
$start_time = (isset($_GET["start_time"]) ? $_GET["start_time"] : date("Y-m-d 00:00:00", strtotime("-1 month")));
$finish_time = (isset($_GET["finish_time"]) ? $_GET["finish_time"] : date("Y-m-d 00:00:00", strtotime("+1 day")));

echo "<form action='report_show.php' method='POST' target='_blank'>";
echo "<select name='plugin' onchange='location.href = \"report_search.php?plugin=\" + escape(this.value) + \"&start_time=\" + escape(typeof(start_time) === \"undefined\" ? \"{$start_time}\" : start_time.value) + \"&finish_time=\" + escape(typeof(finish_time) === \"undefined\" ? \"{$finish_time}\" : finish_time.value);'>";
$report_plugins = scandir("plugins/report");
foreach ($report_plugins as &$row)
{
  if (strstr($row, ".search_report.php"))
  {
    $row = preg_replace("/^(.+)\.search_report\.php$/", "$1", $row);
    if (!$plugin) $plugin = $row;
    echo "<option value='{$row}'";
    if ($row == $plugin) echo " selected";
    echo ">" . strtr($row, "_", " ") . "</option>";
  }
}
echo "</select><br />";

include "plugins/report/{$plugin}.search_report.php";

echo "</form>";

?>

</body>
</html>
