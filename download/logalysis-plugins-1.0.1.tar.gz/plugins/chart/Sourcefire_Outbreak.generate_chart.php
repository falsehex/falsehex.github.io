<?php

include "plugins/geoip/geoip.php";
include "plugins/cred/sourcefire.cred.php";

$link = mysqli_connect($sourcefire_db_host, $sourcefire_db_user, $sourcefire_db_pass, $sourcefire_db_name);
if (!$link) die("Error: mysql db {$sourcefire_db_name} connect failed");

if (!isset($gid)) $gid = (isset($_POST["gid"]) && is_numeric($_POST["gid"]) ? $_POST["gid"] : 1);
if (!isset($sid)) $sid = (isset($_POST["sid"]) && is_numeric($_POST["sid"]) ? $_POST["sid"] : 0);
if (!isset($plot)) $plot = (isset($_POST["plot"]) ? $_POST["plot"] : "ip_src");

$table = "<table id='sourcefire_outbreak_{$plot}_{$gid}_{$sid}_table' class='chart'><tr><th class='chart'></th><th class='chart'>Country</th><th class='chart'>Events</th></tr>";
$count = 0;
$extra = " WHERE sig_gen = {$gid} AND sig_id = {$sid}";
if ($start_time) $extra .= " AND tv_sec >= UNIX_TIMESTAMP('{$start_time}')";
if ($finish_time) $extra .= " AND tv_sec <= UNIX_TIMESTAMP('{$finish_time}')";
unset($countries);
$result = mysqli_query($link, "SELECT INET_NTOA({$plot}), COUNT(1) FROM event{$extra} GROUP BY {$plot}");
while ($row = mysqli_fetch_row($result))
{
  $geo_loc = geo_lookup($row[0], TRUE);
  if (isset($countries[$geo_loc])) $countries[$geo_loc] += $row[1];
  else $countries[$geo_loc] = $row[1];
}
mysqli_free_result($result);
if (isset($countries))
{
  arsort($countries);
  foreach ($countries as $key => &$val)
  {
    $geo_loc = explode(";", $key);
    $table .= "<tr><td class='chart'>" . ++$count . "</td>";
    $table .= "<td class='chart'>{$geo_loc[1]}</td>";
    $table .= "<td class='chart'>{$val}</td>";
    $table .= "<td class='chart' style='display:none'>" . geo_coord($geo_loc[0]) . "</td></tr>";
  }
}
$table .= "</table>";
if ($count)
{
  if (empty($nohdr)) echo "<h4>SOURCEFIRE OUTBREAK SIGNATURE {$gid}:{$sid}<br />" . ($start_time ? date("d-m-Y H:i:s", strtotime($start_time)) . " -" : "") . ($finish_time ? "- " . date("d-m-Y H:i:s", strtotime($finish_time)) : "") . "</h4>";
  if (empty($nogfx)) echo "<canvas id='sourcefire_outbreak_{$plot}_{$gid}_{$sid}_canvas' width='1080' height='540' ondblclick='window.open(this.toDataURL());'></canvas>";
  echo $table;

  if (empty($nogfx)) echo "<script type='text/javascript'>mapChart(\"sourcefire_outbreak_{$plot}_{$gid}_{$sid}\", 3, 2);</script>";
}
else echo "<h5>NO EVENTS FOUND!</h5>";

mysqli_close($link);

?>
