<html>
<head>
<meta name='copyright' content='2012-2016 Del Castle' />
<meta charset='UTF-8' />
<meta http-equiv='content-type' content='text/html' />
<link rel='stylesheet' type='text/css' href='fx/css/logalysis.css' />

<link rel='icon' type='image/x-icon' href='fx/img/packet_posse16.ico' />
<title>Logalysis</title>

<?php

include "common.php";
session_start();

$user_name = (isset($_POST["user_name"]) ? $_POST["user_name"] : "");

if (!isset($_SESSION["las_login_user_id"]) && $user_name)
{
  $link = logalysis_db_connect();

/*  $ldap = ldap_connect("123.123.123.123");
  if ($ldap)
  {
    ldap_set_option($ldap, LDAP_OPT_PROTOCOL_VERSION, 3);
    $ldap_ok = ldap_bind($ldap, "uid={$user_name},ou=people,dc=domain", $_POST["password"]);
  }
  else */$ldap_ok = FALSE;

  $user = db_fetch_row($link, "SELECT user_id, is_disabled, attempts, hash, hash_time, roles, is_admin FROM users WHERE name = '" . addslashes($user_name) . "'");
  if ($user && !$user[1] && ($user[2] < 10) && ((sha1($_POST["password"] . strrev($user_name)) == $user[3]) || $ldap_ok))
  {
    mysqli_query($link, "UPDATE users SET attempts = 0 WHERE user_id = {$user[0]}");
    $_SESSION["las_login_user_id"] = $user[0];
//    if (((time() - strtotime($user[4])) < 7776000) || $ldap_ok)
//    {
      $_SESSION["las_login_user_name"] = $user_name;
      $_SESSION["las_login_user_roles"] = $user[5];
      $_SESSION["las_login_user_admin"] = $user[6];
      write_audit($link, 0, $user[0], 1, "");
      $_SESSION["las_menu_tab"] = 0;
      $_SESSION["las_move_log"] = 0;
      $_SESSION["las_move_file"] = 0;
//    }
  }
  else
  {
    if ($user) mysqli_query($link, "UPDATE users SET attempts = attempts + 1 WHERE user_id = {$user[0]}");
    write_audit($link, 0, ($user ? $user[0] : 0), 2, ($user ? "" : "username:{$user_name}"));
  }

  mysqli_close($link);
}

if (isset($_SESSION["las_login_user_name"]))
{
  echo "<frameset rows='20,*' border='4px'>";
  echo "<frame name='frame_header' src='header.php' noresize='noresize' scrolling='no' />";
  echo "<frameset cols='300,*'>";
  echo "<frameset rows='300,*'>";
  echo "<frame name='frame_queue_list' src='queue_list.php' />";
  echo "<frame name='frame_job_list' src='blank.html' />";
  echo "</frameset>";
  echo "<frameset rows='20,*'>";
  echo "<frame name='frame_menu_main' src='menu_main.php' />";
  echo "<frame name='frame_show' src='blank.html' />";
  echo "</frameset>";
  echo "</frameset>";
  echo "</frameset>";

  echo "</head>";
}
else if (isset($_SESSION["las_login_user_id"]))
{
  echo "<frameset>";
  echo "<frame src='user_show.php?user_id={$_SESSION["las_login_user_id"]}&action=expire' />";
  echo "</frameset>";

  echo "</head>";
}
else
{
  echo "</head>";
  echo "<body>";

  echo "<h1><img style='margin-right:12px' src='fx/img/packet_posse.png' />LOGALYSIS</h1>";
  echo "<p style='left:300px; position:fixed; top:16px'>&copy; 2012-2016 Del Castle</p>";

  echo "<form action='index.php' method='POST'>";
  echo "<table>";
  echo "<tr><td>Username</td><td><input type='text' name='user_name' size='42' maxlength='32' value='{$user_name}' /></td></tr>";
  echo "<tr><td>Password</td><td><input type='password' name='password' size='42' maxlength='20' /></td></tr>";
  echo "</table>";
  echo "<p style='margin-left:336px'><input type='submit' value='Login' /></p>";
  echo "</form>";

  if ($user_name) echo "<h5>INVALID USERNAME/PASSWORD!</h5>";

  include "plugins/disclaimer.php";

  echo "</body>";
}

?>

</html>
