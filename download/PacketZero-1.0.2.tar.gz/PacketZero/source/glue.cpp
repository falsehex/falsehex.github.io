/* glue.cpp - 01 Sep 15
   GL User Experience
   Copyright 2006-2015 Del Castle  */

#include <ctype.h>
#ifdef __APPLE__
#include <OpenGL/gl.h>
#else
#include <GL/gl.h>
#endif
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "glue.h"
#include "font.h"

//object kind
#define GLUE_WINDOW  0x01
#define GLUE_BITMAP  0x02
#define GLUE_BUTTON  0x03
#define GLUE_CHECK   0x04
#define GLUE_INPUT   0x05
#define GLUE_LABEL   0x06
#define GLUE_LIST    0x07
#define GLUE_VIEW    0x08
#define GLUE_MENU    0x09

const int WIN_ID = 10000, charShift[42] =
{
  96, 126,  // ` ~
  49, 33,   // 1 !
  50, 64,   // 2 @
  51, 35,   // 3 #
  52, 36,   // 4 $
  53, 37,   // 5 %
  54, 94,   // 6 ^
  55, 38,   // 7 &
  56, 42,   // 8 *
  57, 40,   // 9 (
  48, 41,   // 0 )
  45, 95,   // - _
  61, 43,   // = +
  91, 123,  // [ {
  93, 125,  // ] }
  92, 124,  // \ |
  59, 58,   // ; :
  39, 34,   // ' "
  44, 60,   // , <
  46, 62,   // . >
  47, 63    // / ?
};
const unsigned char clrBackground[3] = {  0,   0,  50},  //background colour
                    clrOutline[3] =    {  0,   0, 255},  //outline colour
                    clrFocus[3] =      {120, 120, 170},  //focused item colour
                    clrSelect[3] =     { 50,  50, 100},  //selected list item colour
                    clrText[3] =       {255, 255, 255};  //text colour

font_info GLFont[2] = {{5, 10, 1, 5, 0}, {7, 14, 2, 7, 0}}, *pFont;

//load GL compiled fonts
void initFont()
{
  glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
  GLFont[0].GLList = glGenLists(FONT_GLYPHS + 1);
  GLFont[1].GLList = glGenLists(FONT_GLYPHS + 1);
  for (unsigned char cntChar = 0; cntChar < FONT_GLYPHS; cntChar++)
  {
    glNewList(GLFont[0].GLList + cntChar, GL_COMPILE);
    glBitmap(GLFont[0].Width, GLFont[0].Height, 0.0, 0.0, GLFont[0].Width + GLFont[0].PadX, 0.0, FONT_5X10[cntChar]);
    glEndList();
    glNewList(GLFont[1].GLList + cntChar, GL_COMPILE);
    glBitmap(GLFont[1].Width, GLFont[1].Height, 0.0, 0.0, GLFont[1].Width + GLFont[1].PadX, 0.0, FONT_7X14[cntChar]);
    glEndList();
  }
  unsigned char gfxCursor[] = {128, 128, 128, 128, 128, 128, 128, 128, 128, 128, 128, 128, 128, 128, 128};  //input cursor
  glNewList(GLFont[0].GLList + FONT_GLYPHS, GL_COMPILE);
  glBitmap(1, GLFont[0].Height + 1, 0.0, 0.0, 0.0, 0.0, gfxCursor);
  glEndList();
  glNewList(GLFont[1].GLList + FONT_GLYPHS, GL_COMPILE);
  glBitmap(1, GLFont[1].Height + 1, 0.0, 0.0, 0.0, 0.0, gfxCursor);
  glEndList();
}

//set current font
void setFont(int font)
{
  pFont = &GLFont[font];
}

//return current font height
int fontHeight()
{
  return pFont->Height;
}

//draw character in OpenGL
void drawChar(unsigned char ch)
{
  ch -= 32;  //32 space
  glCallList(pFont->GLList + (ch < FONT_GLYPHS ? ch : FONT_GLYPHS - 1));  //unknown
}

//draw string in OpenGL
void drawString(const unsigned char *text)
{
  int posRaster[4] = {0, 0, 0, 0};
  glGetIntegerv(GL_CURRENT_RASTER_POSITION, posRaster);
  for (int cntChar = 0; text[cntChar] != '\0'; cntChar++)
  {
    if (text[cntChar] == '\n')
    {
      posRaster[1] -= pFont->Height + pFont->PadY;
      glRasterPos2i(posRaster[0], posRaster[1]);
    }
    else if (text[cntChar] == '\t') drawString((const unsigned char *)"   ");
    else drawChar(text[cntChar]);
  }
}

//destroy GL compiled fonts
void destroyFont()
{
  glDeleteLists(GLFont[0].GLList, FONT_GLYPHS + 1);
  glDeleteLists(GLFont[1].GLList, FONT_GLYPHS + 1);
}

//return length of string
int lenStr(const char *text)
{
  int cntChar = 0;
  for (; *text != '\0'; text++) cntChar++;
  return cntChar;
}

//convert timeval to time in milliseconds
unsigned long long milliTime(const timeval *val)
{
  if (val) return (unsigned long long)((val->tv_sec * 1000) + (val->tv_usec / 1000));
  timeval timeCurrent;
  gettimeofday(&timeCurrent, 0);  //current time
  return (unsigned long long)((timeCurrent.tv_sec * 1000) + (timeCurrent.tv_usec / 1000));
}

GLue::GLue()
{
  unsigned char gfxItems[8][7] =
  {
    {130,  68,  40,  16,  40,  68, 130},  //close cross
    {130, 132, 136, 144, 160, 192, 254},  //scroll start
    { 16,  16,  16, 146,  84,  56,  16},  //up-arrow
    { 16,  56,  84, 146,  16,  16,  16},  //down-arrow
    { 16,  32,  64, 254,  64,  32,  16},  //left-arrow
    { 16,   8,   4, 254,   4,   8,  16},  //right-arrow
    { 16,  48, 112, 240, 112,  48,  16},  //menu left-point
    {128, 192, 224, 240, 224, 192, 128}   //menu right-point
  };
  glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
  listGfx = glGenLists(8);
  glNewList(listGfx, GL_COMPILE);  //cross
  glBitmap(7, 7, 0.0, 0.0, 0.0, 0.0, gfxItems[0]);
  glEndList();
  glNewList(listGfx + 1, GL_COMPILE);  //start
  glBitmap(7, 7, 0.0, 0.0, 0.0, 0.0, gfxItems[1]);
  glEndList();
  glNewList(listGfx + 2, GL_COMPILE);  //up-arrow
  glBitmap(7, 7, 0.0, 0.0, 0.0, 0.0, gfxItems[2]);
  glEndList();
  glNewList(listGfx + 3, GL_COMPILE);  //down-arrow
  glBitmap(7, 7, 0.0, 0.0, 0.0, 0.0, gfxItems[3]);
  glEndList();
  glNewList(listGfx + 4, GL_COMPILE);  //left-arrow
  glBitmap(7, 7, 0.0, 0.0, 0.0, 0.0, gfxItems[4]);
  glEndList();
  glNewList(listGfx + 5, GL_COMPILE);  //right-arrow
  glBitmap(7, 7, 0.0, 0.0, 0.0, 0.0, gfxItems[5]);
  glEndList();
  glNewList(listGfx + 6, GL_COMPILE);  //left-point
  glBitmap(4, 7, 0.0, 0.0, 0.0, 0.0, gfxItems[6]);
  glEndList();
  glNewList(listGfx + 7, GL_COMPILE);  //right-point
  glBitmap(4, 7, 0.0, 0.0, 0.0, 0.0, gfxItems[7]);
  glEndList();
  szWindow = sizeof(glue_window);
  szBitmap = sizeof(glue_bitmap);
  szButton = sizeof(glue_button);
  szCheck = sizeof(glue_check);
  szInput = sizeof(glue_input);
  szLabel = sizeof(glue_label);
  szList = sizeof(glue_list);
  szView = sizeof(glue_view);
  szMenu = sizeof(glue_menu);
  Reset();
  winWidth = 0;
  winHeight = 0;
  mouseX = 0;
  mouseY = 0;
}

//reset values
void GLue::Reset()
{
  lastWindow = 0;
  activeInput = 0;
  activeMenu = 0;
  objId = 1;
  objSelected = 0;
  activeScroll = 0;
  stateMenu = 0;
}

//mouse over object
bool GLue::MouseOver(int left, int top, int right, int bottom)
{
  return ((mouseX >= left) && (mouseY <= top) && (mouseX <= right) && (mouseY >= bottom));
}

//draw window object
void GLue::DrawWindow(const glue_window *window)
{
  bool winFocus = (window->Id == (objSelected / WIN_ID));
  int posTop = winHeight - window->Top, posRight = window->Left + window->Width, posBottom = posTop - window->Height;
  glColor3ub(clrBackground[0], clrBackground[1], clrBackground[2]);
  glRecti(window->Left, posTop, posRight, posBottom);
  if (winFocus && MouseOver(window->Left, posTop, posRight - 20, posTop - window->Bar)) objSelected = (window->Id * WIN_ID) + GLUE_TITLE_BAR;  //title bar selectable
  glColor3ub(clrOutline[0], clrOutline[1], clrOutline[2]);
  glBegin(GL_LINE_STRIP);
    glVertex2i(posRight, posTop - window->Bar);
    glVertex2i(posRight, posBottom);
    glVertex2i(window->Left, posBottom);
    glVertex2i(window->Left, posTop);
    glVertex2i(posRight, posTop);
    glVertex2i(posRight, posTop - window->Bar);
    glVertex2i(window->Left, posTop - window->Bar);
  glEnd();
  glColor3ub(clrText[0], clrText[1], clrText[2]);
  glRasterPos2i(window->Left + pFont->Width + pFont->PadX, posTop - (pFont->Height + pFont->PadY));
  drawString((const unsigned char *)window->Text);  //title bar
  if (window->Close)  //close object
  {
    if (winFocus && MouseOver(posRight - 16, posTop - 4, posRight - 4, posTop - 16))
    {
      glColor3ub(clrFocus[0], clrFocus[1], clrFocus[2]);
      glRecti(posRight - 16, posTop - 4, posRight - 4, posTop - 16);
      objSelected = (window->Id * WIN_ID) + GLUE_CLOSE;  //close object selectable
    }
    glColor3ub(clrOutline[0], clrOutline[1], clrOutline[2]);
    glBegin(GL_LINE_LOOP);
      glVertex2i(posRight - 16, posTop - 4);
      glVertex2i(posRight - 4, posTop - 4);
      glVertex2i(posRight - 4, posTop - 16);
      glVertex2i(posRight - 16, posTop - 16);
    glEnd();
    glRasterPos2i(posRight - 13, posTop - 13);
    glCallList(listGfx);  //cross
  }
  if (window->Resize)  //resize object
  {
    if (winFocus && MouseOver(posRight - 10, posBottom + 10, posRight, posBottom)) objSelected = (window->Id * WIN_ID) + GLUE_RESIZE;  //resize object selectable
    glColor3ub(clrOutline[0], clrOutline[1], clrOutline[2]);
    glBegin(GL_LINES);
      glVertex2i(posRight - 13, posBottom);
      glVertex2i(posRight, posBottom + 13);
      glVertex2i(posRight - 10, posBottom);
      glVertex2i(posRight, posBottom + 10);
      glVertex2i(posRight - 7, posBottom);
      glVertex2i(posRight, posBottom + 7);
      glVertex2i(posRight - 4, posBottom);
      glVertex2i(posRight, posBottom + 4);
    glEnd();
    if (winFocus && MouseOver(posRight - 6, posTop - (window->Bar + 1), posRight, posBottom + 11)) objSelected = (window->Id * WIN_ID) + GLUE_RESIZE_RIGHT;  //resize right object selectable
    if (winFocus && MouseOver(window->Left, posBottom + 6, posRight - 11, posBottom)) objSelected = (window->Id * WIN_ID) + GLUE_RESIZE_BOTTOM;  //resize bottom object selectable
  }
}

//draw bitmap object
void GLue::DrawBitmap(const glue_bitmap *bitmap)
{
  glColor3ub(bitmap->Red, bitmap->Green, bitmap->Blue);
  glRasterPos2i(bitmap->Parent->Left + bitmap->Left, (winHeight - bitmap->Parent->Top) - (bitmap->Parent->Bar + bitmap->Top + 8));
  glBitmap(8, 8, 0.0, 0.0, 0.0, 0.0, bitmap->Gfx);
}

//draw button object
void GLue::DrawButton(const glue_button *button)
{
  bool winFocus = (button->Parent->Id == (objSelected / WIN_ID));
  int objWidth = (lenStr(button->Text) + 4) * (pFont->Width + pFont->PadX)  //button width
    , posLeft = button->Parent->Left + (button->Align ? button->Left : button->Parent->Width - (button->Left + objWidth))
    , posTop = (winHeight - button->Parent->Top) - (button->Align ? button->Parent->Bar + button->Top : button->Parent->Height - button->Top), posRight = posLeft + objWidth
    , posBottom = posTop - (pFont->Height + (pFont->PadY * 4));
  if (winFocus && MouseOver(posLeft + 1, posTop - 1, posRight, posBottom))
  {
    glColor3ub(clrFocus[0], clrFocus[1], clrFocus[2]);
    glRecti(posLeft, posTop, posRight, posBottom);
    objSelected = (button->Parent->Id * WIN_ID) + button->Value;  //button object selectable
  }
  glColor3ub(clrOutline[0], clrOutline[1], clrOutline[2]);
  glBegin(GL_LINE_LOOP);
    glVertex2i(posLeft, posTop);
    glVertex2i(posRight, posTop);
    glVertex2i(posRight, posBottom);
    glVertex2i(posLeft, posBottom);
  glEnd();
  if (button->Defalt)
  {
    glBegin(GL_LINES);
      glVertex2i(posLeft, posTop - 1);
      glVertex2i(posRight, posTop - 1);
      glVertex2i(posLeft, posBottom + 1);
      glVertex2i(posRight, posBottom + 1);
    glEnd();
  }
  glColor3ub(clrText[0], clrText[1], clrText[2]);
  glRasterPos2i(posLeft + (pFont->Width * 2) + (pFont->PadX * 3), posTop - (pFont->Height + (pFont->PadY * 2)));
  drawString((const unsigned char *)button->Text);
}

//draw check object
void GLue::DrawCheck(const glue_check *check)
{
  bool winFocus = (check->Parent->Id == (objSelected / WIN_ID));
  int posLeft = check->Parent->Left + check->Left, posTop = (winHeight - check->Parent->Top) - (check->Parent->Bar + check->Top), posRight = posLeft + ((pFont->Width + pFont->PadX) * 3)
    , posBottom = posTop - (pFont->Height + (pFont->PadY * 2));
  if (winFocus && MouseOver(posLeft + 1, posTop - 1, posRight, posBottom))
  {
    glColor3ub(clrFocus[0], clrFocus[1], clrFocus[2]);
    glRecti(posLeft, posTop, posRight, posBottom);
    objSelected = (check->Parent->Id * WIN_ID) + (check->Id * OBJ_ID) + GLUE_CHECK_BOX;  //check object selectable
  }
  glColor3ub(clrOutline[0], clrOutline[1], clrOutline[2]);
  glBegin(GL_LINE_LOOP);
    glVertex2i(posLeft, posTop);
    glVertex2i(posRight, posTop);
    glVertex2i(posRight, posBottom);
    glVertex2i(posLeft, posBottom);
  glEnd();
  if (check->Checked)
  {
    glColor3ub(clrText[0], clrText[1], clrText[2]);
    glRasterPos2i(posLeft + pFont->Width + (pFont->PadX * 2), posTop - (pFont->Height + pFont->PadY));
    drawString((const unsigned char *)"\x81");  //tick
  }
}

//draw input object
void GLue::DrawInput(glue_input *input)
{
  bool winFocus = (input->Parent->Id == (objSelected / WIN_ID));
  int posLeft = input->Parent->Left + input->Left, posTop = (winHeight - input->Parent->Top) - (input->Parent->Bar + input->Top)
    , posRight = posLeft + ((input->Width + 2) * (pFont->Width + pFont->PadX)), posBottom = posTop - (pFont->Height + (pFont->PadY * 2));
  if (winFocus && MouseOver(posLeft + 1, posTop - 1, posRight, posBottom))
  {
    glColor3ub(clrFocus[0], clrFocus[1], clrFocus[2]);
    glRecti(posLeft, posTop, posRight, posBottom);
    objSelected = (input->Parent->Id * WIN_ID) + (input->Id * OBJ_ID) + GLUE_INPUT_TEXT;  //input object selectable to gain focus (for keys)
  }
  glColor3ub(clrOutline[0], clrOutline[1], clrOutline[2]);
  glBegin(GL_LINE_LOOP);
    glVertex2i(posLeft, posTop);
    glVertex2i(posRight, posTop);
    glVertex2i(posRight, posBottom);
    glVertex2i(posLeft, posBottom);
  glEnd();
  glColor3ub(clrText[0], clrText[1], clrText[2]);
  glRasterPos2i(posLeft + pFont->Width + pFont->PadX, posTop - (pFont->Height + pFont->PadY));
  char *pText = input->Text + input->First;
  int cntChar = 0, posRaster[4] = {0, 0, 0, 0};
  do {
    if ((input == activeInput) && (cntChar++ == (input->Cursor - input->First)) && ((milliTime(0) % 1000) > 500)) glCallList(pFont->GLList + FONT_GLYPHS);  //cursor
    if ((*pText == '\0') || (posRaster[0] > (posRight - ((pFont->Width + pFont->PadX) * 2)))) break;
    drawChar((unsigned char)*pText);
    pText++;
    glGetIntegerv(GL_CURRENT_RASTER_POSITION, posRaster);
  } while (true);
}

//draw label object
void GLue::DrawLabel(const glue_label *label)
{
  glColor3ub(clrText[0], clrText[1], clrText[2]);
  glRasterPos2i(label->Parent->Left + label->Left, (winHeight - label->Parent->Top) - (label->Parent->Bar + label->Top + pFont->Height));
  drawString((const unsigned char *)label->Text);
}

//draw scroll objects
void GLue::DrawScroll(glue_view *view, int left, int top, int right, int bottom, bool focus)
{
  if (view->RowsBefore || view->ColsBefore)
  {
    if (focus && MouseOver(right - 11, bottom + 11, right, bottom))
    {
      glColor3ub(clrFocus[0], clrFocus[1], clrFocus[2]);
      glRecti(right - 12, bottom + 12, right, bottom);
      objSelected = (view->Parent->Id * WIN_ID) + (view->Id * OBJ_ID) + GLUE_SCROLL_START;
    }
    glColor3ub(clrOutline[0], clrOutline[1], clrOutline[2]);
    glRasterPos2i(right - 9, bottom + 3);
    glCallList(listGfx + 1);  //start
  }
  if (view->RowsBefore || view->RowsAfter)
  {
    if (view->RowsBefore)
    {
      if (focus && MouseOver(right - 11, top - 1, right, top - 12))
      {
        glColor3ub(clrFocus[0], clrFocus[1], clrFocus[2]);
        glRecti(right - 12, top, right, top - 12);
      }
      glColor3ub(clrOutline[0], clrOutline[1], clrOutline[2]);
      glRasterPos2i(right - 9, top - 9);
      glCallList(listGfx + 2);  //up-arrow
    }
    if (view->RowsAfter)
    {
      if (focus && MouseOver(right - 11, bottom + 23, right, bottom + 12))
      {
        glColor3ub(clrFocus[0], clrFocus[1], clrFocus[2]);
        glRecti(right - 12, bottom + 24, right, bottom + 12);
      }
      glColor3ub(clrOutline[0], clrOutline[1], clrOutline[2]);
      glRasterPos2i(right - 9, bottom + 15);
      glCallList(listGfx + 3);  //down-arrow
    }
    if ((view->RowsBefore + view->RowsAfter) <= ((top - bottom) - 52)) view->RowsStep = 1;  //12 + 2 + 12 + 2 + 12 + 12
    else view->RowsStep = ((view->RowsBefore + view->RowsAfter) / ((top - bottom) - 52)) + 1;
    if (focus)
    {
      if (MouseOver(right - 9, (top - 15) - (view->RowsBefore / view->RowsStep), right - 2, bottom + 26 + (view->RowsAfter / view->RowsStep)))  //2 + 12 + 12
      {
        glColor3ub(clrFocus[0], clrFocus[1], clrFocus[2]);
        glRecti(right - 10, (top - 14) - (view->RowsBefore / view->RowsStep), right - 2, bottom + 26 + (view->RowsAfter / view->RowsStep));
        objSelected = (view->Parent->Id * WIN_ID) + (view->Id * OBJ_ID) + GLUE_BAR_RIGHT;
      }
      else if (MouseOver(right - 11, top - 1, right, (top - 14) - (view->RowsBefore / view->RowsStep))) objSelected = (view->Parent->Id * WIN_ID) + (view->Id * OBJ_ID) + GLUE_SCROLL_UP;
      else if (MouseOver(right - 11, bottom + 25 + (view->RowsAfter / view->RowsStep), right, bottom + 12))
        objSelected = (view->Parent->Id * WIN_ID) + (view->Id * OBJ_ID) + GLUE_SCROLL_DOWN;
    }
    glColor3ub(clrOutline[0], clrOutline[1], clrOutline[2]);
    glBegin(GL_LINE_LOOP);
      glVertex2i(right - 10, (top - 14) - (view->RowsBefore / view->RowsStep));
      glVertex2i(right - 2, (top - 14) - (view->RowsBefore / view->RowsStep));
      glVertex2i(right - 2, bottom + 26 + (view->RowsAfter / view->RowsStep));
      glVertex2i(right - 10, bottom + 26 + (view->RowsAfter / view->RowsStep));
    glEnd();
    glBegin(GL_LINES);
      glVertex2i(right - 12, top - 12);
      glVertex2i(right, top - 12);
      glVertex2i(right - 12, bottom + 24);
      glVertex2i(right, bottom + 24);
      glVertex2i(right - 12, bottom + 12);
      glVertex2i(right, bottom + 12);
    glEnd();
  }
  glColor3ub(clrOutline[0], clrOutline[1], clrOutline[2]);
  glBegin(GL_LINES);
    glVertex2i(right - 12, top);
    glVertex2i(right - 12, bottom);
  glEnd();
  if (view->ColsBefore || view->ColsAfter)
  {
    if (view->ColsBefore)
    {
      if (focus && MouseOver(left + 1, bottom + 11, left + 12, bottom))
      {
        glColor3ub(clrFocus[0], clrFocus[1], clrFocus[2]);
        glRecti(left, bottom + 12, left + 12, bottom);
      }
      glColor3ub(clrOutline[0], clrOutline[1], clrOutline[2]);
      glRasterPos2i(left + 3, bottom + 3);
      glCallList(listGfx + 4);  //left-arrow
    }
    if (view->ColsAfter)
    {
      if (focus && MouseOver(right - 23, bottom + 11, right - 12, bottom))
      {
        glColor3ub(clrFocus[0], clrFocus[1], clrFocus[2]);
        glRecti(right - 24, bottom + 12, right - 12, bottom);
      }
      glColor3ub(clrOutline[0], clrOutline[1], clrOutline[2]);
      glRasterPos2i(right - 21, bottom + 3);
      glCallList(listGfx + 5);  //right-arrow
    }
    if ((view->ColsBefore + view->ColsAfter) <= ((right - left) - 52)) view->ColsStep = 1;  //12 + 2 + 12 + 2 + 12 + 12
    else view->ColsStep = ((view->ColsBefore + view->ColsAfter) / ((right - left) - 52)) + 1;
    if (focus)
    {
      if (MouseOver(left + 15 + (view->ColsBefore / view->ColsStep), bottom + 9, (right - 26) - (view->ColsAfter / view->ColsStep), bottom + 2))  //2 + 12 + 12
      {
        glColor3ub(clrFocus[0], clrFocus[1], clrFocus[2]);
        glRecti(left + 14 + (view->ColsBefore / view->ColsStep), bottom + 10, (right - 26) - (view->ColsAfter / view->ColsStep), bottom + 2);
        objSelected = (view->Parent->Id * WIN_ID) + (view->Id * OBJ_ID) + GLUE_BAR_BOTTOM;
      }
      else if (MouseOver(left + 1, bottom + 11, left + 14 + (view->ColsBefore / view->ColsStep), bottom)) objSelected = (view->Parent->Id * WIN_ID) + (view->Id * OBJ_ID) + GLUE_SCROLL_LEFT;
      else if (MouseOver((right - 25) - (view->ColsAfter / view->ColsStep), bottom + 11, right - 12, bottom))
        objSelected = (view->Parent->Id * WIN_ID) + (view->Id * OBJ_ID) + GLUE_SCROLL_RIGHT;
    }
    glColor3ub(clrOutline[0], clrOutline[1], clrOutline[2]);
    glBegin(GL_LINE_LOOP);
      glVertex2i(left + 14 + (view->ColsBefore / view->ColsStep), bottom + 10);
      glVertex2i((right - 26) - (view->ColsAfter / view->ColsStep), bottom + 10);
      glVertex2i((right - 26) - (view->ColsAfter / view->ColsStep), bottom + 2);
      glVertex2i(left + 14 + (view->ColsBefore / view->ColsStep), bottom + 2);
    glEnd();
    glBegin(GL_LINES);
      glVertex2i(right - 24, bottom + 12);
      glVertex2i(right - 24, bottom);
      glVertex2i(right - 12, bottom + 12);
      glVertex2i(right - 12, bottom);
      glVertex2i(left + 12, bottom + 12);
      glVertex2i(left + 12, bottom);
    glEnd();
  }
  glColor3ub(clrOutline[0], clrOutline[1], clrOutline[2]);
  glBegin(GL_LINES);
    glVertex2i(left, bottom + 12);
    glVertex2i(right, bottom + 12);
  glEnd();
}

//draw list object
void GLue::DrawList(glue_list *list)
{
  bool winFocus = (list->Parent->Id == (objSelected / WIN_ID));
  int objHeight = pFont->Height + (pFont->PadY * 2), posLeft = list->Parent->Left + list->Left  //list item height
    , posTop = (winHeight - list->Parent->Top) - (list->Parent->Bar + list->Top), posRight = (list->Parent->Left + list->Parent->Width) - list->Right
    , posBottom = ((winHeight - list->Parent->Top) - list->Parent->Height) + list->Bottom, numItems = ((posTop - posBottom) - 12) / objHeight, cntList;
  FILE *fileText;
  if ((fileText = fopen(list->Filename, "r")))
  {
    char strBuffer[256], *pText;
    int chText, posY = posTop, posRaster[4];
    for (cntList = 0; cntList < list->RowsBefore; cntList++)  //skip rows before
    {
      do {
        chText = getc(fileText);
      } while ((chText != EOF) && (chText != '\n'));
    }
    list->RowsAfter = 0;
    list->ColsAfter = 0;
    for (cntList = 0; cntList < numItems; cntList++)
    {
      if (fgets(strBuffer, 256, fileText))
      {
        if ((pText = strchr(strBuffer, '\n'))) *pText = '\0';  //remove \n
        else  //skip rest of line
        {
          do {
            chText = getc(fileText);
          } while ((chText != EOF) && (chText != '\n'));
        }
        if (winFocus && MouseOver(posLeft + 1, posY - 1, posRight - 12, posY - objHeight))
        {
          glColor3ub(clrFocus[0], clrFocus[1], clrFocus[2]);
          glRecti(posLeft, posY, posRight - 12, posY - objHeight);
          objSelected = (list->Parent->Id * WIN_ID) + (list->Id * OBJ_ID) + GLUE_LIST_ITEM;  //list item selectable
          strncpy(list->Text, strBuffer, 256);
        }
        else if (!strcmp(strBuffer, list->Input->Text))
        {
          glColor3ub(clrSelect[0], clrSelect[1], clrSelect[2]);
          glRecti(posLeft, posY, posRight - 12, posY - objHeight);
        }
        if (lenStr(strBuffer) > list->ColsBefore)
        {
          glColor3ub(clrText[0], clrText[1], clrText[2]);
          glRasterPos2i(posLeft + pFont->Width + pFont->PadX, posY - (pFont->Height + pFont->PadY));
          pText = strBuffer + list->ColsBefore;
          posRaster[0] = 0;
          while ((*pText != '\0') && (posRaster[0] <= (posRight - (((pFont->Width + pFont->PadX) * 2) + 12))))
          {
            drawChar((unsigned char)*pText);
            pText++;
            glGetIntegerv(GL_CURRENT_RASTER_POSITION, posRaster);
          }
          if (lenStr(pText) > list->ColsAfter) list->ColsAfter = lenStr(pText);  //calculate columns after
        }
        posY -= objHeight;
      }
      else break;
    }
    while ((chText = getc(fileText)) != EOF)  //calculate rows after
    {
      if (chText == '\n') list->RowsAfter++;
    }
    if ((cntList < numItems) && list->RowsBefore) list->RowsBefore--;  //don't hide when there is space
    fclose(fileText);
    DrawScroll((glue_view *)list, posLeft, posTop, posRight, posBottom, winFocus);
  }
  glColor3ub(clrOutline[0], clrOutline[1], clrOutline[2]);
  glBegin(GL_LINE_LOOP);
    glVertex2i(posLeft, posTop);
    glVertex2i(posRight, posTop);
    glVertex2i(posRight, posBottom);
    glVertex2i(posLeft, posBottom);
  glEnd();
}

//draw view object
void GLue::DrawView(glue_view *view)
{
  bool winFocus = (view->Parent->Id == (objSelected / WIN_ID));
  int posLeft = view->Parent->Left + view->Left, posTop = (winHeight - view->Parent->Top) - (view->Parent->Bar + view->Top)
    , posRight = (view->Parent->Left + view->Parent->Width) - view->Right, posBottom = ((winHeight - view->Parent->Top) - view->Parent->Height) + view->Bottom;
  FILE *fileText;
  if ((fileText = fopen(view->Filename, "r")))
  {
    int cntView, chText, posY = posTop - (pFont->Height + pFont->PadY), colsAfter = 0, posRaster[4];
    for (cntView = 0; cntView < view->RowsBefore; cntView++)  //skip rows before
    {
      do {
        chText = getc(fileText);
      } while ((chText != EOF) && (chText != '\n'));
    }
    view->RowsAfter = 0;
    view->ColsAfter = 0;
    cntView = 0;
    glColor3ub(clrText[0], clrText[1], clrText[2]);
    glRasterPos2i(posLeft + pFont->Width + pFont->PadX, posY);
    chText = getc(fileText);
    while (chText != EOF)
    {
      if (chText == '\n')
      {
        if ((chText = getc(fileText)) != EOF)
        {
          posY -= pFont->Height + pFont->PadY;
          if (posY >= (posBottom + pFont->PadY + 12))
          {
            colsAfter = 0;
            cntView = 0;
            glRasterPos2i(posLeft + pFont->Width + pFont->PadX, posY);
          }
          else
          {
            while ((chText = getc(fileText)) != EOF)  //calculate rows after
            {
              if (chText == '\n') view->RowsAfter++;
            }
          }
        }
      }
      else
      {
        if (chText == '\t')
        {
          if (view->Tab > view->ColsBefore) glRasterPos2i(posLeft + (((view->Tab - view->ColsBefore) + 1) * (pFont->Width + pFont->PadX)), posY);
          cntView = view->Tab;
        }
        else if (++cntView > view->ColsBefore)
        {
          glGetIntegerv(GL_CURRENT_RASTER_POSITION, posRaster);
          if (posRaster[0] <= (posRight - (pFont->Width + (pFont->PadX * 2) + 12))) drawChar((unsigned char)chText);
          else if (++colsAfter > view->ColsAfter) view->ColsAfter = colsAfter;  //calculate columns after
        }
        chText = getc(fileText);
      }
    }
    if (((posY - (pFont->Height + pFont->PadY)) > (posBottom + pFont->PadY + 12)) && view->RowsBefore) view->RowsBefore--;  //don't hide when there is space
    fclose(fileText);
    DrawScroll(view, posLeft, posTop, posRight, posBottom, winFocus);
  }
  glColor3ub(clrOutline[0], clrOutline[1], clrOutline[2]);
  glBegin(GL_LINE_LOOP);
    glVertex2i(posLeft, posTop);
    glVertex2i(posRight, posTop);
    glVertex2i(posRight, posBottom);
    glVertex2i(posLeft, posBottom);
  glEnd();
}

//draw menu object
void GLue::DrawMenu(glue_menu *menu)
{
  bool isVisible = false, isActive = false;
  glue_menu *pMenu;
  for (pMenu = activeMenu; pMenu; pMenu = pMenu->Parent)
  {
    if (pMenu->Parent == menu) isActive = true;
    if (pMenu->Parent == menu->Parent) isVisible = true;
  }
  if (isVisible || (menu->Parent == activeMenu))
  {
    int posOffset = (stateMenu > 0 ? 0 : menu->Width);
    for (pMenu = menu->Parent; pMenu; pMenu = pMenu->Parent) posOffset += pMenu->Width;
    int posLeft = menu->Left + (stateMenu * posOffset), posRight = posLeft + menu->Width, posBottom = menu->Top - (pFont->Height + (pFont->PadY * 2));
    if ((posLeft < 0) || (posRight > (winWidth - 1))) return;  //off screen don't draw
    if (MouseOver(posLeft + 1, menu->Top - 1, posRight - 1, posBottom) && menu->Value)
    {
      glColor3ub(clrFocus[0], clrFocus[1], clrFocus[2]);
      objSelected = (menu->Value * OBJ_ID) + GLUE_MENU_ITEM;  //menu object selectable
      activeMenu = menu;
    }
    else glColor3ub(clrBackground[0], clrBackground[1], clrBackground[2]);
    glRecti(posLeft, menu->Top, posRight, posBottom);
    glColor3ub(clrOutline[0], clrOutline[1], clrOutline[2]);
    glBegin(GL_LINE_LOOP);
      glVertex2i(posLeft, menu->Top);
      glVertex2i(posRight, menu->Top);
      glVertex2i(posRight, posBottom);
      glVertex2i(posLeft, posBottom);
    glEnd();
    if (menu->Value > 1000)
    {
      if (isActive) glColor3ub(clrText[0], clrText[1], clrText[2]);
      glRasterPos2i((stateMenu > 0 ? posRight - 10 : posLeft + pFont->Width + pFont->PadX), menu->Top - (pFont->Height + 3));
      glCallList(listGfx + (stateMenu > 0 ? 7 : 6));  //right-point, left-point
    }
    glColor3ub(clrText[0], clrText[1], clrText[2]);
    glRasterPos2i(posLeft + pFont->Width + pFont->PadX + (stateMenu > 0 ? 0 : 10), menu->Top - (pFont->Height + pFont->PadY));
    drawString((const unsigned char *)menu->Text);
  }
}

//scroll calculation with direction and opposite
void GLue::ScrollCalc(int *direction, int *opposite, int step)
{
  if (*direction)
  {
    if (*direction < step)
    {
      *opposite += *direction;
      *direction = 0;
    }
    else
    {
      *opposite += step;
      *direction -= step;
    }
  }
}

//destroy child objects for parent window, or all objects
void GLue::DestroyWindow(const glue_window *window)
{
  unsigned char *pObject;
  GLueLL.Start(0);
  while ((pObject = (unsigned char *)GLueLL.Read(0)))
  {
    switch (*pObject)
    {
      case GLUE_WINDOW:
        if (!window || ((glue_window *)pObject == window)) GLueLL.Delete(0);
        else GLueLL.Next(0);
        break;
      case GLUE_BITMAP: case GLUE_BUTTON: case GLUE_CHECK: case GLUE_INPUT: case GLUE_LABEL: case GLUE_LIST: case GLUE_VIEW:
        if (!window || (((glue_bitmap *)pObject)->Parent == window)) GLueLL.Delete(0);
        else GLueLL.Next(0);
        break;
      case GLUE_MENU:
        if (!window) GLueLL.Delete(0);
        else GLueLL.Next(0);
        break;
    }
  }
}

//2D GUI active
bool GLue::On()
{
  return (GLueLL.Items() != 0);
}

//create window object
void GLue::CreateWindow(int left, int top, int width, int height, const char *text, bool close, bool resize)
{
  glue_window oWindow = {GLUE_WINDOW, close, resize, objId++, objSelected, 0, 0, 0, 0, width * (pFont->Width + pFont->PadX), height * pFont->PadY, pFont->Height + (pFont->PadY * 2), ""};
  oWindow.Width = ((left < -1) && (oWindow.MinWidth < (winWidth - 20)) ? winWidth - 20 : oWindow.MinWidth);
  oWindow.Height = ((top < -1) && (oWindow.MinHeight < (winHeight - 20)) ? winHeight - 20 : oWindow.MinHeight);
  if (left > -1) oWindow.Left = left;
  else if (oWindow.Width < winWidth) oWindow.Left = (winWidth - oWindow.Width) / 2;
  else oWindow.Left = 0;
  if (top > -1) oWindow.Top = top;
  else if (oWindow.Height < winHeight) oWindow.Top = (winHeight - oWindow.Height) / 2;
  else oWindow.Top = 1;
  strncat(oWindow.Text, text, 63);  //title bar
  lastWindow = (glue_window *)GLueLL.Write(0, &oWindow, szWindow);
  objSelected = oWindow.Id * WIN_ID;
}

//create bitmap object
void GLue::AddBitmap(int left, int top, int offsetx, int offsety, unsigned char red, unsigned char green, unsigned char blue, const unsigned char *gfx)
{
  if (!lastWindow) return;  //check parent window object exists
  glue_bitmap oBitmap = {GLUE_BITMAP, lastWindow, gfx, red, green, blue, (left * (pFont->Width + pFont->PadX)) + offsetx, (top * pFont->PadY) + offsety};
  GLueLL.Write(0, &oBitmap, szBitmap);
}

//create button object
void GLue::AddButton(int left, int top, int value, const char *text, bool align, bool defalt)
{
  if (!lastWindow) return;  //check parent window object exists
  glue_button oButton = {GLUE_BUTTON, lastWindow, align, defalt, left * (pFont->Width + pFont->PadX), top * pFont->PadY, value, ""};
  strncat(oButton.Text, text, 31);
  GLueLL.Write(0, &oButton, szButton);
}

//create check object
int GLue::AddCheck(int left, int top, bool checked)
{
  if (!lastWindow) return -1;  //check parent window object exists
  glue_check oCheck = {GLUE_CHECK, lastWindow, checked, objId++, left * (pFont->Width + pFont->PadX), top * pFont->PadY};
  GLueLL.Write(0, &oCheck, szCheck);
  return oCheck.Id;
}

//create input object, return id of input object
int GLue::AddInput(int left, int top, int width, int max, const char *text, bool lower, bool digits)
{
  if (!lastWindow) return -1;  //check parent window object exists
  glue_input oInput = {GLUE_INPUT, lastWindow, lower, digits, objId++, left * (pFont->Width + pFont->PadX), top * pFont->PadY, width, lenStr(text)
    , (lenStr(text) > width ? lenStr(text) - width : 0), (max < 255 ? max : 255), ""};
  strncat(oInput.Text, text, 255);  //default text
  activeInput = (glue_input *)GLueLL.Write(0, &oInput, szInput);  //set input object focus (for keys)
  return oInput.Id;
}

//create label object, return id of label object
int GLue::AddLabel(int left, int top, const char *text)
{
  if (!lastWindow) return -1;  //check parent window object exists
  glue_label oLabel = {GLUE_LABEL, lastWindow, objId++, left * (pFont->Width + pFont->PadX), top * pFont->PadY, ""};
  strncat(oLabel.Text, text, 255);
  GLueLL.Write(0, &oLabel, szLabel);
  return oLabel.Id;
}

//create list object
void GLue::AddList(int left, int top, int right, int bottom, const char *filename)
{
  if (!lastWindow || !activeInput) return;  //check parent window/linked input object exists
  glue_list oList = {GLUE_LIST, lastWindow, objId++, left * (pFont->Width + pFont->PadX), top * pFont->PadY, right * (pFont->Width + pFont->PadX), bottom * pFont->PadY
    , 0, 0, 1, 0, 0, 1, activeInput, "", ""};
  strncat(oList.Filename, filename, 255);  //file to list
  GLueLL.Write(0, &oList, szList);
  activeScroll = (oList.Parent->Id * WIN_ID) + (oList.Id * OBJ_ID);  //set scroll object focus (for mouse wheel)
}

//create view object
void GLue::AddView(int left, int top, int right, int bottom, int tab, const char *filename)
{
  if (!lastWindow) return;  //check parent window object exists
  glue_view oView = {GLUE_VIEW, lastWindow, objId++, left * (pFont->Width + pFont->PadX), top * pFont->PadY, right * (pFont->Width + pFont->PadX), bottom * pFont->PadY
    , 0, 0, 1, 0, 0, 1, tab, ""};
  strncat(oView.Filename, filename, 255);  //file to view
  GLueLL.Write(0, &oView, szView);
  activeScroll = (oView.Parent->Id * WIN_ID) + (oView.Id * OBJ_ID);  //set scroll object focus (for mouse wheel)
}

//create menu object
void GLue::AddMenu(int id, const char *text, int value)
{
  if (!stateMenu) stateMenu = (mouseX < (winWidth / 2) ? 1 : -1);  //reverse menu
  glue_menu oMenu = {GLUE_MENU, 0, id, mouseX, (mouseY == winHeight ? winHeight - 1 : mouseY), ((lenStr(text) + 2) * (pFont->Width + pFont->PadX)) + 10, value, ""}, *pMenu;
  int objHeight = pFont->Height + (pFont->PadY * 2);
  unsigned char *pObject;
  GLueLL.Start(0);
  while ((pObject = (unsigned char *)GLueLL.Read(0)))
  {
    if (*pObject == GLUE_MENU)
    {
      pMenu = (glue_menu *)pObject;
      if (pMenu->Value == oMenu.Id)
      {
        oMenu.Parent = pMenu;
        oMenu.Top = pMenu->Top;  //start sub-menu at parent top
      }
      else if (pMenu->Id == oMenu.Id)
      {
        oMenu.Top = pMenu->Top - objHeight;
        if (pMenu->Width > oMenu.Width) oMenu.Width = pMenu->Width;  //same sub-menuitem width
        else if (oMenu.Width > pMenu->Width) pMenu->Width = oMenu.Width;
      }
    }
    GLueLL.Next(0);
  }
  strncat(oMenu.Text, text, 63);
  GLueLL.Write(0, &oMenu, szMenu);
  if (oMenu.Top < objHeight)  //keep menu above bottom
  {
    GLueLL.Start(0);
    while ((pObject = (unsigned char *)GLueLL.Read(0)))
    {
      if (*pObject == GLUE_MENU)
      {
        pMenu = (glue_menu *)pObject;
        if ((pMenu->Top + (objHeight - oMenu.Top)) > (winHeight - 1)) break;  //above top
        pMenu->Top += objHeight - oMenu.Top;
      }
      GLueLL.Next(0);
    }
  }
}

//draw all 2D GUI objects, return selection value
int GLue::Draw()
{
  objSelected = (objSelected / WIN_ID) * WIN_ID;
  unsigned char *pObject;
  GLueLL.Start(0);
  while ((pObject = (unsigned char *)GLueLL.Read(0)))
  {
    switch (*pObject)
    {
      case GLUE_WINDOW: DrawWindow((glue_window *)pObject); break;
      case GLUE_BITMAP: DrawBitmap((glue_bitmap *)pObject); break;
      case GLUE_BUTTON: DrawButton((glue_button *)pObject); break;
      case GLUE_CHECK: DrawCheck((glue_check *)pObject); break;
      case GLUE_INPUT: DrawInput((glue_input *)pObject); break;
      case GLUE_LABEL: DrawLabel((glue_label *)pObject); break;
      case GLUE_LIST: DrawList((glue_list *)pObject); break;
      case GLUE_VIEW: DrawView((glue_view *)pObject); break;
      case GLUE_MENU: DrawMenu((glue_menu *)pObject); break;
    }
    GLueLL.Next(0);
  }
  return (objSelected % OBJ_ID);
}

//return default button value
int GLue::DefaultButton()
{
  glue_button *pButton;
  unsigned char *pObject;
  GLueLL.Start(0);
  while ((pObject = (unsigned char *)GLueLL.Read(0)))
  {
    if (*pObject == GLUE_BUTTON)
    {
      pButton = (glue_button *)pObject;
      if ((pButton->Parent->Id == (objSelected / WIN_ID)) && pButton->Defalt) return pButton->Value;
    }
    GLueLL.Next(0);
  }
  return 0;
}

//return check object checked
bool GLue::GetChecked(int id)
{
  glue_check *pCheck;
  unsigned char *pObject;
  GLueLL.Start(0);
  while ((pObject = (unsigned char *)GLueLL.Read(0)))
  {
    if (*pObject == GLUE_CHECK)
    {
      pCheck = (glue_check *)pObject;
      if (pCheck->Id == id) return pCheck->Checked;
    }
    GLueLL.Next(0);
  }
  return false;
}

//return input object text
char *GLue::GetInputText(int id)
{
  if (!id) return (activeInput ? activeInput->Text : 0);
  glue_input *pInput;
  unsigned char *pObject;
  GLueLL.Start(0);
  while ((pObject = (unsigned char *)GLueLL.Read(0)))
  {
    if (*pObject == GLUE_INPUT)
    {
      pInput = (glue_input *)pObject;
      if (pInput->Id == id) return pInput->Text;
    }
    GLueLL.Next(0);
  }
  return 0;
}

//change input object text
void GLue::PutInputText(const char *text, int id)
{
  glue_input *pInput = 0;
  if (!id) pInput = activeInput;
  else
  {
    unsigned char *pObject;
    GLueLL.Start(0);
    while ((pObject = (unsigned char *)GLueLL.Read(0)))
    {
      if (*pObject == GLUE_INPUT)
      {
        pInput = (glue_input *)pObject;
        if (pInput->Id == id) break;
        pInput = 0;
      }
      GLueLL.Next(0);
    }
  }
  if (pInput)
  {
    strncpy(pInput->Text, text, 255);
    if (lenStr(text) >= pInput->Max) pInput->Text[pInput->Max] = '\0';
    pInput->Cursor = lenStr(pInput->Text);
    pInput->First = (pInput->Cursor > pInput->Width ? pInput->Cursor - pInput->Width : 0);
  }
}

//change label object text
void GLue::PutLabelText(const char *text, int id)
{
  glue_label *pLabel;
  unsigned char *pObject;
  GLueLL.Start(0);
  while ((pObject = (unsigned char *)GLueLL.Read(0)))
  {
    if (*pObject == GLUE_LABEL)
    {
      pLabel = (glue_label *)pObject;
      if (pLabel->Id == id)
      {
        strncpy(pLabel->Text, text, 255);
        pLabel->Text[255] = '\0';
        break;
      }
    }
    GLueLL.Next(0);
  }
}

//return selected object
int GLue::GetSelected()
{
  return ((objSelected % WIN_ID) / OBJ_ID);
}

//update screen size
void GLue::ScreenSize(int width, int height)
{
  winWidth = width;
  winHeight = height;
}

//scroll object/mouse wheel action
void GLue::Scroll(int scroll, int step)
{
  if (scroll)
  {
    if (!activeScroll) return;
    objSelected = activeScroll + scroll;
  }
  glue_view *pView;
  unsigned char *pObject;
  GLueLL.Start(0);
  while ((pObject = (unsigned char *)GLueLL.Read(0)))
  {
    if ((*pObject == GLUE_LIST) || (*pObject == GLUE_VIEW))
    {
      pView = (glue_view *)pObject;
      if (pView->Id == GetSelected())
      {
        switch (objSelected % OBJ_ID)
        {
          case GLUE_SCROLL_START:
            pView->RowsBefore = 0;
            pView->ColsBefore = 0;
            break;
          case GLUE_SCROLL_UP: ScrollCalc(&pView->RowsBefore, &pView->RowsAfter, (step ? pView->RowsStep * step : 1)); break;
          case GLUE_SCROLL_DOWN: ScrollCalc(&pView->RowsAfter, &pView->RowsBefore, (step ? pView->RowsStep * step : 1)); break;
          case GLUE_SCROLL_LEFT: ScrollCalc(&pView->ColsBefore, &pView->ColsAfter, (step ? pView->ColsStep * step : 1)); break;
          case GLUE_SCROLL_RIGHT: ScrollCalc(&pView->ColsAfter, &pView->ColsBefore, (step ? pView->ColsStep * step : 1)); break;
        }
        activeScroll = (pView->Parent->Id * WIN_ID) + (pView->Id * OBJ_ID);  //set scroll object focus (for mouse wheel)
        break;
      }
    }
    GLueLL.Next(0);
  }
}

//mouse left-click object selected
int GLue::MouseButton(bool up)
{
  int valSelected = objSelected % OBJ_ID;
  if (up)
  {
    unsigned char *pObject;
    switch (valSelected)
    {
      case 0: if (stateMenu) Close(); break;
      case GLUE_CHECK_BOX:
        glue_check *pCheck;
        GLueLL.Start(0);
        while ((pObject = (unsigned char *)GLueLL.Read(0)))
        {
          if (*pObject == GLUE_CHECK)
          {
            pCheck = (glue_check *)pObject;
            if (pCheck->Id == GetSelected())
            {
              pCheck->Checked = !pCheck->Checked;
              break;
            }
          }
          GLueLL.Next(0);
        }
        break;
      case GLUE_INPUT_TEXT:
        glue_input *pInput;
        GLueLL.Start(0);
        while ((pObject = (unsigned char *)GLueLL.Read(0)))
        {
          if (*pObject == GLUE_INPUT)
          {
            pInput = (glue_input *)pObject;
            if (pInput->Id == GetSelected())
            {
              if (mouseX < (pInput->Parent->Left + pInput->Left + ((pFont->Width + pFont->PadX) / 2)))
              {
                if (pInput->First) pInput->First--;
                pInput->Cursor = pInput->First;
              }
              else
              {
                pInput->Cursor = pInput->First + ((mouseX - (pInput->Parent->Left + pInput->Left + ((pFont->Width + pFont->PadX) / 2))) / (pFont->Width + pFont->PadX));
                if (pInput->Cursor > lenStr(pInput->Text)) pInput->Cursor = lenStr(pInput->Text);
                else if ((pInput->Cursor - pInput->First) > pInput->Width) pInput->First++;
              }
              activeInput = pInput;  //set input object focus (for keys)
              break;
            }
          }
          GLueLL.Next(0);
        }
        break;
      case GLUE_SCROLL_START: case GLUE_SCROLL_UP: case GLUE_SCROLL_DOWN: case GLUE_SCROLL_LEFT: case GLUE_SCROLL_RIGHT: Scroll(0); break;
      case GLUE_LIST_ITEM:
        glue_list *pList;
        GLueLL.Start(0);
        while ((pObject = (unsigned char *)GLueLL.Read(0)))
        {
          if (*pObject == GLUE_LIST)
          {
            pList = (glue_list *)pObject;
            if (pList->Id == GetSelected())
            {
              strncpy(pList->Input->Text, pList->Text, 256);  //set linked input object text
              pList->Input->Cursor = lenStr(pList->Input->Text);
              pList->Input->First = (pList->Input->Cursor > pList->Input->Width ? pList->Input->Cursor - pList->Input->Width : 0);
              activeScroll = (pList->Parent->Id * WIN_ID) + (pList->Id * OBJ_ID);  //set scroll object focus (for mouse wheel)
              break;
            }
          }
          GLueLL.Next(0);
        }
        break;
    }
  }
  return valSelected;
}

//update mouse position
void GLue::MouseMotion(int x, int y)
{
  mouseX = x;
  mouseY = y;
}

//mouse left-click and drag move object
void GLue::MouseMove(int val, int x, int y)
{
  if (val == GLUE_BAR_RIGHT) Scroll((y < 0 ? GLUE_SCROLL_UP : GLUE_SCROLL_DOWN), abs(y));
  else if (val == GLUE_BAR_BOTTOM) Scroll((x < 0 ? GLUE_SCROLL_LEFT : GLUE_SCROLL_RIGHT), abs(x));
  else
  {
    glue_window *pWindow;
    unsigned char *pObject;
    GLueLL.Start(0);
    while ((pObject = (unsigned char *)GLueLL.Read(0)))
    {
      if (*pObject == GLUE_WINDOW)
      {
        pWindow = (glue_window *)pObject;
        if (pWindow->Id == (objSelected / WIN_ID))
        {
          switch (val)
          {
            case GLUE_TITLE_BAR:  //move window object
              pWindow->Left += x;
              if (pWindow->Left < 0) pWindow->Left = 0;
              else if (pWindow->Left > (winWidth - 50)) pWindow->Left = winWidth - 50;
              pWindow->Top += y;
              if (pWindow->Top < 1) pWindow->Top = 1;
              else if (pWindow->Top > (winHeight - pWindow->Bar)) pWindow->Top = winHeight - pWindow->Bar;
              break;
            case GLUE_RESIZE: case GLUE_RESIZE_RIGHT: case GLUE_RESIZE_BOTTOM:  //resize window objects
              if (val != GLUE_RESIZE_BOTTOM)
              {
                pWindow->Width += x;
                if (pWindow->Width < pWindow->MinWidth) pWindow->Width = pWindow->MinWidth;
                else if (pWindow->Width > ((winWidth - 1) - pWindow->Left)) pWindow->Width = (winWidth - 1) - pWindow->Left;
                if (x > 0) Scroll(GLUE_SCROLL_LEFT);  //don't hide when there is space
              }
              if (val != GLUE_RESIZE_RIGHT)
              {
                pWindow->Height += y;
                if (pWindow->Height < pWindow->MinHeight) pWindow->Height = pWindow->MinHeight;
                else if (pWindow->Height > (winHeight - pWindow->Top)) pWindow->Height = winHeight - pWindow->Top;
              }
              break;
          }
          break;
        }
      }
      GLueLL.Next(0);
    }
  }
}

//keyboard input
void GLue::Key(int key, bool shift)
{
  if (!activeInput) return;
  int cntChar;
  switch (key)
  {
    case GL_KEY_TAB:  //make next input object activeInput
      glue_input *pInput;
      unsigned char *pObject;
      GLueLL.Start(0);
      while ((pObject = (unsigned char *)GLueLL.Read(0)))
      {
        if (*pObject == GLUE_INPUT)
        {
          pInput = (glue_input *)pObject;
          if (pInput == activeInput) break;
        }
        GLueLL.Next(0);
      }
      (shift ? GLueLL.Prev(0) : GLueLL.Next(0));
      for (cntChar = 0; cntChar < 2; cntChar++)
      {
        while ((pObject = (unsigned char *)GLueLL.Read(0)))
        {
          if (*pObject == GLUE_INPUT)
          {
            pInput = (glue_input *)pObject;
            if (pInput->Parent->Id == (objSelected / WIN_ID))
            {
              activeInput = pInput;
              return;
            }
          }
          (shift ? GLueLL.Prev(0) : GLueLL.Next(0));
        }
        (shift ? GLueLL.End(0) : GLueLL.Start(0));
      }
      break;
    case GL_KEY_BACKSP:
      if (activeInput->Cursor)
      {
        for (cntChar = activeInput->Cursor - 1; cntChar < lenStr(activeInput->Text); cntChar++) activeInput->Text[cntChar] = activeInput->Text[cntChar + 1];
        activeInput->Cursor--;
        if (activeInput->First) activeInput->First--;
      }
      break;
    case GL_KEY_LEFT:
      if (activeInput->Cursor)
      {
        activeInput->Cursor--;
        if (activeInput->Cursor < activeInput->First) activeInput->First--;
      }
      break;
    case GL_KEY_RIGHT:
      if (activeInput->Cursor < lenStr(activeInput->Text))
      {
        activeInput->Cursor++;
        if ((activeInput->Cursor - activeInput->First) > activeInput->Width) activeInput->First++;
      }
      break;
    case GL_KEY_DEL:
      if (activeInput->Cursor < lenStr(activeInput->Text))
      {
        for (cntChar = activeInput->Cursor; cntChar < lenStr(activeInput->Text); cntChar++) activeInput->Text[cntChar] = activeInput->Text[cntChar + 1];
        if (activeInput->First && ((activeInput->Cursor - activeInput->First) < activeInput->Width)) activeInput->First--;
      }
      break;
    default:
      if ((key >= GL_KEY_SPACE) && (key <= GL_KEY_TIDLE) && (lenStr(activeInput->Text) < activeInput->Max))
      {
        if (shift)
        {
          if ((key >= 'a') && (key <= 'z')) key = toupper(key);
          else
          {
            for (cntChar = 0; cntChar < 42; cntChar += 2)  //sizeof charShift
            {
              if (charShift[cntChar] == key)
              {
                key = charShift[cntChar + 1];
                break;
              }
            }
          }
        }
        if (!activeInput->Digits || ((key >= 45) && (key <= 58)))  // -./0123456789:
        {
          for (cntChar = lenStr(activeInput->Text) + 1; cntChar > activeInput->Cursor; cntChar--) activeInput->Text[cntChar] = activeInput->Text[cntChar - 1];
          activeInput->Text[activeInput->Cursor] = (char)(activeInput->Lower ? tolower(key) : key);
          activeInput->Cursor++;
          if ((activeInput->Cursor - activeInput->First) > activeInput->Width) activeInput->First++;
        }
      }
  }
}

//close window object and child objects, or all objects
void GLue::Close(bool all)
{
  if (all) DestroyWindow(0);
  else
  {
    glue_window *pWindow;
    unsigned char *pObject;
    GLueLL.Start(0);
    while ((pObject = (unsigned char *)GLueLL.Read(0)))
    {
      if (*pObject == GLUE_WINDOW)
      {
        pWindow = (glue_window *)pObject;
        if (pWindow->Id == (objSelected / WIN_ID))
        {
          lastWindow = 0;
          activeInput = 0;
          objSelected = pWindow->Parent;  //previous selected
          activeScroll = 0;
          DestroyWindow(pWindow);
          break;
        }
      }
      GLueLL.Next(0);
    }
  }
  if (!On()) Reset();
}

GLue::~GLue()
{
  DestroyWindow(0);
  glDeleteLists(listGfx, 8);
}
