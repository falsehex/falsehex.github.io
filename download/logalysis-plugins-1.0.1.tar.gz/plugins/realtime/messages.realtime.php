<?php

$dest_dir = "files/RT_Messages";

if ($ackn == "messages")
{
  $part = explode(";", $_GET["file_id"]);
  if (strstr($part[0], "../")) exit(0);
  if (file_exists("{$dest_dir}/{$part[0]}"))
  {
    if ($part[1]) exec("sed -i '1 s/^[1-6]/{$part[1]}/' \"{$dest_dir}/{$part[0]}\"");
    else exec("rm -f \"{$dest_dir}/{$part[0]}\"");
    file_put_contents("/var/log/logalysis/ack.log", time() . " \"{$_SESSION["las_login_user_name"]}\" " . (!$part[1] ? "ACK" : ($part[1] > 3 ? "CHK" : "UCK")) . " \"RT MSG\" \"{$part[0]}\" \"{$part[2]}\" {$part[3]} {$part[4]}\n", FILE_APPEND);
  }
}

if (!$ackn)
{
  $messages = scandir($dest_dir);
  foreach ($messages as &$file)
  {
    if ($file[0] != ".")
    {
      $message = fopen("{$dest_dir}/{$file}", "r");
      $line = fgets($message);
      $row = explode("*", $line);
      if (!$row[3]) $row[3] = " ";
      $url = "realtime_show.php?ackn=messages&file_id=" . urlencode($file);
      echo "<tr onclick='txtBold(this.style);'>";
      echo "<td style='background:" . priority_color($row[0]) . "'><a class='action' href='javascript:void(0);' ondblclick='if (ackAlert(\"{$url};" . ($row[0][0] > 3 ? $row[0][0] - 3 : $row[0][0] + 3) . ";" . urlencode(strip_tags($row[3])) . ";{$row[1]};\" + cntRt)) setPriority(this);'>{$row[0]}</a></td>";
      echo "<td>" . date("Y-m-d H:i:s", $row[1]) . "</td>";
      echo "<td>RT MSG</td>";
      echo "<td title='{$row[2]}'>" . strtr($file, "_", " ") . "</td>";
      echo "<td>{$row[3]}</td>";
      echo "<td>{$row[4]}</td>";
      echo "<td><a class='action' href='javascript:void(0);' ondblclick='if (ackAlert(\"{$url};0;" . urlencode(strip_tags($row[3])) . ";{$row[1]};\" + cntRt)) this.parentNode.parentNode.style.display = \"none\";'>ACK</a>";
      while ($line = fgets($message))
      {
        $row = explode("*", $line);
        echo " <a class='action' href='{$row[0]}' target='{$row[1]}'>{$row[2]}</a>";
      }
      echo "</td></tr>";
      fclose($message);
      $count++;
    }
  }
}

?>
