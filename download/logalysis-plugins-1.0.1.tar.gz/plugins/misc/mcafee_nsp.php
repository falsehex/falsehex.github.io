<?php

$mcafee_nsp_result = array(
100 => "Successful",
200 => "May be successful",
300 => "Failed",
400 => "Suspicious",
777 => "Smart Blocked",
999 => "Blocked"
);

$mcafee_nsp_direction = array("Outbound", "Inbound", "Unknown", "Bidirectional");

$mcafee_nsp_detection = array(
200 => "Signature",
201 => "Threshold",
202 => "Protocol anomaly",
203 => "Statistical anomaly",
204 => "Application anomaly",
205 => "Multi method correlation",
206 => "Flow correlation",
207 => "Multi flow correlation",
208 => "Multi sensor correlation",
209 => "Protocol discovery"
);

$mcafee_nsp_category = array(
111 => "Exploit",
112 => "Volume DOS",
113 => "Reconnaissance",
114 => "Policy Violation",
115 => "Malware"
);

function mcafee_nsp_priority($val, $short, $tick)
{
  if (!$val) $val = 3;
  switch ($val)
  {
    case 1: case 2: case 3: return ($short ? ($tick ? 6 : 3) . " L" : "Low");
    case 4: case 5: case 6: return ($short ? ($tick ? 5 : 2) . " M" : "Medium");
    case 7: case 8: case 9: return ($short ? ($tick ? 4 : 1) . " H" : "High");
    default: return $val;
  }
}

?>
