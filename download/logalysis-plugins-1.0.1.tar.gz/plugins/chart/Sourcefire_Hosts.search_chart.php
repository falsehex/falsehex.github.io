<?php

echo "<p><select name='shape' onchange='visState(\"objSv\", (this.value == \"vbar\"));'>";
echo "<option value='vbar'>Vertical Bar</option>";
echo "<option value='pie'>Pie</option>";
echo "<option value='map'>Map</option>";
echo "</select></p>";
echo "<p><select name='host'>";
echo "<option value='source'>Sources</option>";
echo "<option value='target'>Targets</option>";
echo "</select></p>";
echo "<p>Top <input type='text' name='limit' size='7' maxlength='5' value='{$limit}' /></p>";
search_time($start_time, $finish_time);
echo "<p>Blocked <select name='blocked'>";
echo "<option value='0'>N/A</option>";
echo "<option value='yes'>Yes</option>";
echo "<option value='no'>No</option>";
echo "</select></p>";
echo "<p id='objSv'><input type='checkbox' name='show_vals' />Show Value on Bar</p>";

?>
