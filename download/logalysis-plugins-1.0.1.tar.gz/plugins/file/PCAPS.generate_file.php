<?php

if ($search[3]) $filter = "ip.addr eq {$search[3]}";
if ($search[5]) $filter .= ($filter ? " and " : "") . "ip.addr eq {$search[5]}";
if ($search[4]) $filter .= ($filter ? " and " : "") . "(tcp.port eq {$search[4]} or udp.port eq {$search[4]})";
if ($search[6]) $filter .= ($filter ? " and " : "") . "(tcp.port eq {$search[6]} or udp.port eq {$search[6]})";
$file_name .= ".pcap";
exec("generate_pcap.sh \"{$file_name}\" \"{$search[1]}\" \"{$search[2]}\" \"{$filter}\"");

?>
