<?php

include "plugins/geoip/geoip.php";
include "plugins/cred/sourcefire.cred.php";

$link = mysqli_connect($sourcefire_db_host, $sourcefire_db_user, $sourcefire_db_pass, $sourcefire_db_name);
if (!$link) die("Error: mysql db {$sourcefire_db_name} connect failed");

if (!isset($shape)) $shape = (isset($_POST["shape"]) ? $_POST["shape"] : "");
if (!isset($host)) $host = (isset($_POST["host"]) ? $_POST["host"] : "");
if (!isset($blocked)) $blocked = (isset($_POST["blocked"]) ? $_POST["blocked"] : 0);
if (!isset($show_vals)) $show_vals = (isset($_POST["show_vals"]) ? $_POST["show_vals"] : "");

$table = "<table id='sourcefire_{$shape}_{$host}s_{$blocked}_table' class='chart'><tr><th class='chart'></th><th class='chart'>" . ucfirst($host) . " IP</th><th class='chart'>Events</th><th class='chart'>Country</th></tr>";
$count = 0;
$extra = ($start_time ? " WHERE tv_sec >= UNIX_TIMESTAMP('{$start_time}')" : "");
if ($finish_time) $extra .= ($extra ? " AND" : " WHERE") . " tv_sec <= UNIX_TIMESTAMP('{$finish_time}')";
if ($blocked) $extra .= ($extra ? " AND" : " WHERE") . " blocked = " . ($blocked == "yes" ? 1 : 0);
unset($countries);
$result = mysqli_query($link, "SELECT INET_NTOA(" . ($host == "source" ? "ip_src" : "ip_dst") . "), COUNT(1) FROM event{$extra} GROUP BY " . ($host == "source" ? "ip_src" : "ip_dst") . " ORDER BY COUNT(1) DESC LIMIT {$limit}");
while ($row = mysqli_fetch_row($result))
{
  $geo_loc = explode(";", geo_lookup($row[0], TRUE));
  if (isset($countries[$geo_loc[0]])) $countries[$geo_loc[0]] += $row[1];
  else $countries[$geo_loc[0]] = $row[1];
  $table .= "<tr><td class='chart'>" . ++$count . "</td>";
  foreach ($row as &$cell) $table .= "<td class='chart'>{$cell}</td>";
  $table .= "<td class='chart'>{$geo_loc[1]}</td>";
  if ($shape == "map")
  {
    $table .= "<td class='chart' style='display:none'>" . geo_coord($geo_loc[0]) . "</td>";
    $table .= "<td class='chart' style='display:none'>{$countries[$geo_loc[0]]}</td>";
  }
  $table .= "</tr>";
}
mysqli_free_result($result);
$table .= "</table>";
if ($count)
{
  if (empty($nohdr)) echo "<h4>SOURCEFIRE TOP {$limit} " . strtoupper($host) . "S<br />" . ($start_time ? date("d-m-Y H:i:s", strtotime($start_time)) . " -" : "") . ($finish_time ? "- " . date("d-m-Y H:i:s", strtotime($finish_time)) : "") . "</h4>";
  if (empty($nogfx)) echo "<canvas id='sourcefire_{$shape}_{$host}s_{$blocked}_canvas' " . ($shape == "map" ? "width='1080' height='540'" : "width='640' height='320'") . " ondblclick='window.open(this.toDataURL());'></canvas>";
  echo $table;

  if (empty($nogfx)) echo "<script type='text/javascript'>{$shape}Chart(\"sourcefire_{$shape}_{$host}s_{$blocked}\", " . ($shape == "map" ? "4, 5" : "0, 2") . ($shape == "vbar" ? ", \"{$show_vals}\"" : "") . ");</script>";
}
else echo "<h5>NO EVENTS FOUND!</h5>";

mysqli_close($link);

?>
