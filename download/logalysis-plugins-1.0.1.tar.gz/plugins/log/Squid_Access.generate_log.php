<?php

if (empty($nohdr)) echo "<h4>SQUID ACCESS</h4>";
echo "<table class='esort'>";
echo "<tr><th></th><th>Time</th><th>Duration</th><th>Client IP</th><th>Result/Status</th><th>Size</th><th>Method</th><th>URL</th><th>Ident</th><th>Hierarchy/Server</th><th>Type</th></tr>";
$count = 0;
$squid_logs = scandir("/var/log/squid");
natsort($squid_logs);
$squid_logs = array_reverse($squid_logs);
foreach ($squid_logs as &$file)
{
  if (preg_match("/^access\.log/", $file))
  {
    $squid_access = gzopen("/var/log/squid/{$file}", "r");
    while ($line = gzgets($squid_access, 4096))
    {
      $row = preg_split("/\s+/", $line);
      $row[0] = preg_replace("/^(\d+)\.\d+$/", "$1", $row[0]);
      $process = TRUE;
      if ($start_time && ($row[0] < strtotime($start_time))) $process = FALSE;
      if ($process && $finish_time && ($row[0] > strtotime($finish_time))) $process = FALSE;
      if ($process && $source_ip && !strstr($row[2], $source_ip)) $process = FALSE;
      if ($process && $char_5_255 && !stristr($row[8], $char_5_255)) $process = FALSE;
      if ($process)
      {
        $row[0] = date("Y-m-d H:i:s", $row[0]);
        if ($action) $save[] = array($row[0], NULL, $row[1], $row[4], NULL, NULL, NULL, $row[3], $row[5], $row[6], $row[7], $row[8], $row[9], NULL, $row[2], NULL, NULL, NULL, NULL);
        echo "<tr onclick='txtBold(this.style);'><td>" . ++$count . "</td>";
        $row[2] = "<a class='action' href='javascript:popUp(\"host_show.php?host_ip={$row[2]}\");'>{$row[2]}</a>";
        $row[4] = format_bytes($row[4]);
        foreach ($row as &$cell) echo "<td>{$cell}</td>";
        echo "</tr>";
        if ($count == $limit) break;
      }
    }
    gzclose($squid_access);
    if ($count == $limit) break;
  }
}
echo "</table>";

?>
