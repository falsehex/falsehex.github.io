<?php

$link = logalysis_db_connect();

if (empty($nohdr)) echo "<h4>APACHE ACCESS</h4>";
echo "<table class='esort'>";
echo "<tr><th></th><th>Time</th><th>Client IP</th><th>Ident</th><th>User</th><th>URL</th><th>Status</th><th>Size</th><th>Referer</th><th>User-Agent</th></tr>";
$count = 0;
$result = mysqli_query($link, "SELECT time_1, source_ip, char_3_255, char_1_64, char_4_255, num_1, num_2, char_5_255, char_6_255 FROM events WHERE log_id = {$log_id} ORDER BY time_1");
while ($row = mysqli_fetch_row($result))
{
  echo "<tr onclick='txtBold(this.style);'><td>" . ++$count . "</td>";
  $row[1] = "<a class='action' href='javascript:popUp(\"host_show.php?host_ip={$row[1]}\");'>{$row[1]}</a>";
  $row[6] = format_bytes($row[6]);
  foreach ($row as &$cell) echo "<td>{$cell}</td>";
  echo "</tr>";
}
mysqli_free_result($result);
echo "</table>";

mysqli_close($link);

?>
